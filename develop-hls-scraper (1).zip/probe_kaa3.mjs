import { chromium } from 'playwright';

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';

async function probeKa() {
  const browser = await chromium.launch({ args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const context = await browser.newContext({ userAgent: UA });
  const page = await ctx.newPage();
  
  console.log('=== ka.lt - Search page ===');
  await page.goto('https://kaa.lt/search?keyword=frieren', { waitUntil: 'networkidle', timeout: 30000 });
  await page.waitForTimeout(5000);
  
  const html = await page.content();
  console.log('Page length:', html.length);
  
  // Find all links
  const links = await page.evaluate(() => {
    const links = [];
    document.querySelectorAll('a[href]').forEach(a => {
      const h = a.getAttribute('href');
      if (h) links.push(h);
    });
    return [...new Set(links)];
  });
  console.log('All links:', links.slice(0, 20));
  
  // Look for anime-specific links
  const animeLinks = await page.evaluate(() => {
    const links = [];
    document.querySelectorAll('a[href]').forEach(a => {
      const h = a.getAttribute('href');
      if (h && h.includes('/anime/')) {
        links.push(h);
      }
    });
    return [...new Set(links)];
  });
  console.log('Anime links:', animeLinks.slice(0, 10));
  
  await browser.close();
}

await probeKa();

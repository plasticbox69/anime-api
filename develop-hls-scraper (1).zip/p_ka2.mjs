
import { chromium } from 'playwright';

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';

async function probe() {
  const browser = await chromium.launch({ args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const context = await browser.newContext({ userAgent: UA });
  const page = await context.newPage();
  
  const media = [];
  const api = [];
  page.on('response', async (res) => {
    const u = res.url();
    const ct = (res.headers()['content-type'] || '').toLowerCase();
    if (ct.includes('mpegurl') || /\.m3u8/i.test(u)) {
      let b = ''; try { b = (await res.text()).slice(0, 200); } catch {}
      media.push({ status: res.status(), url: u, ct, body: b });
    }
    if (/json/i.test(ct) && /api/i.test(u) && !u.includes('disqus') && !u.includes('googletag')) {
      let b = ''; try { b = (await res.text()).slice(0, 300); } catch {}
      api.push({ status: res.status(), url: u, body: b });
    }
  });
  
  await page.goto('https://kaa.lt/tensei-kizoku-kantei-skill-de-nariagaru-3rd-season-8f8b/ep-1-ed083f', { waitUntil: 'networkidle', timeout: 35000 });
  await page.waitForTimeout(8000);
  
  // Try clicking play
  try {
    const vid = await page.$('video');
    if (vid) { await vid.click(); await page.waitForTimeout(5000); }
  } catch {}
  
  console.log('=== MEDIA ===');
  for (const m of media.slice(0, 8)) {
    console.log(`${m.status} ct=${m.ct}`);
    console.log(`  ${m.url.slice(0, 150)}`);
    console.log(`  ${m.body.slice(0, 150)}`);
  }
  console.log('\n=== API ===');
  for (const a of api.slice(0, 8)) {
    console.log(`${a.status} ${a.url.slice(0, 140)}`);
    console.log(`   ${a.body.slice(0, 200)}`);
  }
  
  const vids = await page.evaluate(() => [...document.querySelectorAll('video')].map(v => v.src || v.currentSrc).filter(Boolean));
  console.log('\nvideos:', vids);
  const iframes = await page.evaluate(() => [...document.querySelectorAll('iframe')].map(f => f.src).filter(Boolean));
  console.log('iframes:', iframes.slice(0, 5));
  
  await browser.close();
}

await probe();

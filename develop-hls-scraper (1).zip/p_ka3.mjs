
import { chromium } from 'playwright';
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';

async function probe() {
  const browser = await chromium.launch({ args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const context = await browser.newContext({ userAgent: UA });
  const page = await context.newPage();
  const api = [];
  page.on('response', async (res) => {
    const u = res.url();
    const ct = (res.headers()['content-type'] || '');
    if (/json/i.test(ct) && /kaa\.lt/i.test(u) && !u.includes('disqus') && !u.includes('googletag')) {
      let b = ''; try { b = (await res.text()).slice(0, 300); } catch {}
      api.push({ status: res.status(), url: u, body: b });
    }
  });
  
  await page.goto('https://kaa.lt/search?keyword=frieren', { waitUntil: 'networkidle', timeout: 35000 });
  await page.waitForTimeout(6000);
  
  console.log('=== API on search page ===');
  for (const a of api.slice(0, 10)) {
    console.log(`${a.status} ${a.url.slice(0, 150)}`);
    console.log(`   ${a.body.slice(0, 250)}`);
  }
  
  const links = await page.evaluate(() => {
    const l = [];
    document.querySelectorAll('a[href]').forEach(a => {
      const h = a.getAttribute('href');
      if (h && /\/[a-z0-9-]{10,}/.test(h) && !h.includes('/anime?') && !h.includes('_nuxt')) l.push(h);
    });
    return [...new Set(l)].slice(0, 12);
  });
  console.log('\nResult links:', links);
  
  await browser.close();
}
await probe();

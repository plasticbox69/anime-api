import { chromium } from 'playwright';

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';

async function probeSite(name, baseUrl, searchUrl, animeSlug) {
  const browser = await chromium.launch({ args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const context = await browser.newContext({ userAgent: UA });
  const page = await context.newPage();

  console.log(`\n===== ${name} ===\n`);

  // Search page
  console.log(`--- Search page: ${searchUrl} ---`);
  try {
    await page.goto(searchUrl, { waitUntil: 'domcontentloaded', timeout: 30000 });
    await page.waitForTimeout(3000);
    const content = await page.content();
    console.log(`Status: 200, content length: ${content.length}`);

    // Look for anime links
    const links = await page.evaluate(() => {
      const links = [];
      document.querySelectorAll('a[href]').forEach(a => {
        const h = a.getAttribute('href');
        if (h && (h.includes('/anime/') || h.includes('/watch/') || h.includes('/watch/'))) {
          links.push(h);
        }
      });
      return [...new Set(links)].slice(0, 10);
    });
    console.log('  Anime links:', links);

    // Look for scripts
    const scripts = await page.evaluate(() => {
      const scripts = [];
      document.querySelectorAll('script[src]').forEach(s => scripts.push(s.src));
      return scripts;
    });
    console.log('  Scripts:', scripts.slice(0, 10));
  } catch(e) {
    console.log(`  ERROR: ${e.message}`);
  }

  // Anime page
  if (animeSlug) {
    console.log(`\n--- Anime page: ${animeSlug} ---`);
    try {
      await page.goto(`${new URL(searchUrl).origin}${animeSlug}`, { waitUntil: 'domcontentloaded', timeout: 30000 });
      await page.waitForTimeout(3000);
      const content = await page.content();
      console.log(`Status: 200, content length: ${content.length}`);

      // Look for episode links
      const episodeLinks = await page.evaluate(() => {
        const links = [];
        document.querySelectorAll('a[href]').forEach(a => {
          const h = a.getAttribute('href');
          if (h && (h.includes('/episode/') || h.includes('/watch/') || h.includes('/ep-') || h.includes('/watch/'))) {
            links.push(h);
          }
        });
        return [...new Set(links)].slice(0, 10);
      });
      console.log('  Episode links:', episodeLinks);

      // Look for player iframe or embed
      const iframes = await page.evaluate(() => {
        const iframes = [];
        document.querySelectorAll('iframe').forEach(f => iframes.push(f.src));
        return iframes;
      });
      console.log('  Iframes:', iframes);

      // Look for any API calls
      const apiUrls = await page.evaluate(() => {
        const urls = [];
        document.querySelectorAll('script[src]').forEach(s => urls.push(s.src));
        return urls;
      });
      console.log('  Scripts:', apiUrls.slice(0, 10));
    } catch(e) {
      console.log(`  ERROR: ${e.message}`);
    }
  }

  await browser.close();
}

(async () => {
  // kaa.lt
  await probeSite('ka.lt', 'https://kaa.lt', 'https://kaa.lt/search?keyword=frieren', '/anime/f91d5sxb');

  // mkissa.to - try the anime page directly
  await probeSite('mkissa.to', 'https://mkissa.to', 'https://mkissa.to/search?q=frieren', '/anime/qSyzgmuetej3MG4dA');
})();

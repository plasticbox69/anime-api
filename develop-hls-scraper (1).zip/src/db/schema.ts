import {
  bigserial,
  boolean,
  index,
  integer,
  jsonb,
  pgTable,
  real,
  text,
  timestamp,
} from "drizzle-orm/pg-core";

/**
 * Mirrors an anime entry on the source site.
 * `id` is the numeric site id (e.g. "1642" for One Piece).
 */
export const animes = pgTable(
  "animes",
  {
    id: text("id").primaryKey(),
    slug: text("slug").notNull(),
    title: text("title").notNull(),
    japaneseTitle: text("japanese_title"),
    altNames: text("alt_names"),
    poster: text("poster"),
    synopsis: text("synopsis"),
    genres: jsonb("genres").$type<string[]>().notNull().default([]),
    studios: jsonb("studios").$type<string[]>().notNull().default([]),
    type: text("type"),
    status: text("status"),
    rating: text("rating"),
    quality: text("quality"),
    score: real("score"),
    duration: text("duration"),
    aired: text("aired"),
    premiered: text("premiered"),
    subCount: integer("sub_count").notNull().default(0),
    dubCount: integer("dub_count").notNull().default(0),
    totalEpisodes: integer("total_episodes").notNull().default(0),
    /** MyAnimeList id, read from the episode list's `data-mal` attribute. */
    malId: text("mal_id"),
    /** AniList id, filled in once a mapping has been confirmed. */
    anilistId: text("anilist_id"),
    scrapedAt: timestamp("scraped_at", { withTimezone: true }).notNull().defaultNow(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    index("animes_slug_idx").on(t.slug),
    index("animes_title_idx").on(t.title),
    index("animes_mal_idx").on(t.malId),
    index("animes_anilist_idx").on(t.anilistId),
  ],
);

/** One episode row per site episode id (e.g. "30298"). */
export const episodes = pgTable(
  "episodes",
  {
    id: text("id").primaryKey(),
    animeId: text("anime_id")
      .notNull()
      .references(() => animes.id, { onDelete: "cascade" }),
    number: text("number").notNull(),
    title: text("title"),
    slug: text("slug"),
    hasSub: boolean("has_sub").notNull().default(false),
    hasDub: boolean("has_dub").notNull().default(false),
    /** Opaque server payload passed to the site's `ajax/server/list` endpoint. */
    serverIds: text("server_ids"),
    airedAt: text("aired_at"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("episodes_anime_idx").on(t.animeId)],
);

/** A resolved HLS master playlist for one episode + streaming server. */
export const sources = pgTable(
  "sources",
  {
    id: bigserial("id", { mode: "number" }).primaryKey(),
    /** Site episode id, or `ani:{anilistId}:{episode}` for the direct strategy. */
    episodeId: text("episode_id").notNull(),
    animeId: text("anime_id"),
    anilistId: text("anilist_id"),
    episodeNumber: text("episode_number"),
    /** "anikoto" | "reanime" | "aniwaves" */
    provider: text("provider").notNull().default("anikoto"),
    /** "sub" | "dub" */
    audioType: text("audio_type"),
    /** "site" | "direct" */
    strategy: text("strategy").notNull().default("site"),
    serverName: text("server_name"),
    serverId: text("server_id"),
    cmid: text("cmid"),
    linkId: text("link_id"),
    embedUrl: text("embed_url"),
    hlsUrl: text("hls_url"),
    /** Optional base64 32-byte XOR key required to decode FlixCloud `_v7` manifests. */
    manifestKey: text("manifest_key"),
    posterUrl: text("poster_url"),
    referer: text("referer"),
    introStart: integer("intro_start"),
    introEnd: integer("intro_end"),
    outroStart: integer("outro_start"),
    outroEnd: integer("outro_end"),
    tracks: jsonb("tracks").$type<unknown[]>().notNull().default([]),
    status: text("status").notNull().default("ok"),
    error: text("error"),
    resolvedAt: timestamp("resolved_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    index("sources_episode_idx").on(t.episodeId),
    index("sources_anime_idx").on(t.animeId),
    index("sources_anilist_idx").on(t.anilistId),
    index("sources_provider_idx").on(t.provider),
  ],
);

/**
 * AniList id -> site anime. The AniList metadata is cached alongside so repeat
 * lookups never touch the AniList API (which is aggressively rate limited).
 */
export const anilistMappings = pgTable(
  "anilist_mappings",
  {
    anilistId: integer("anilist_id").primaryKey(),
    malId: integer("mal_id"),
    animeId: text("anime_id"),
    slug: text("slug"),
    siteTitle: text("site_title"),
    /** mal-cache | mal-verified | title-match | unmatched */
    method: text("method").notNull().default("unmatched"),
    confidence: real("confidence").notNull().default(0),
    title: text("title"),
    meta: jsonb("meta").$type<Record<string, unknown> | null>(),
    metaFetchedAt: timestamp("meta_fetched_at", { withTimezone: true }),
    mappedAt: timestamp("mapped_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("anilist_mappings_anime_idx").on(t.animeId)],
);

/** Audit trail of every scrape performed through the app. */
export const scrapeJobs = pgTable(
  "scrape_jobs",
  {
    id: bigserial("id", { mode: "number" }).primaryKey(),
    kind: text("kind").notNull(),
    target: text("target").notNull(),
    status: text("status").notNull(),
    items: integer("items").notNull().default(0),
    durationMs: integer("duration_ms").notNull().default(0),
    error: text("error"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("scrape_jobs_created_idx").on(t.createdAt)],
);

export type AnimeRow = typeof animes.$inferSelect;
export type EpisodeRow = typeof episodes.$inferSelect;
export type SourceRow = typeof sources.$inferSelect;
export type AnilistMappingRow = typeof anilistMappings.$inferSelect;
export type ScrapeJobRow = typeof scrapeJobs.$inferSelect;

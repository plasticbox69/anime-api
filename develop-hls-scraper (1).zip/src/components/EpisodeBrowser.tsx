"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import type { EpisodeItem } from "@/lib/types";

const PAGE_SIZE = 40;

export function EpisodeBrowser({
  animeSlug,
  episodes,
}: {
  animeSlug: string;
  episodes: EpisodeItem[];
}) {
  const [filter, setFilter] = useState("");
  const [page, setPage] = useState(0);
  const [dubOnly, setDubOnly] = useState(false);

  const sorted = useMemo(
    () =>
      [...episodes].sort((a, b) => {
        const na = Number(a.number);
        const nb = Number(b.number);
        if (Number.isFinite(na) && Number.isFinite(nb)) return na - nb;
        return a.number.localeCompare(b.number, undefined, { numeric: true });
      }),
    [episodes],
  );

  const filtered = useMemo(() => {
    const needle = filter.trim().toLowerCase();
    return sorted.filter((ep) => {
      if (dubOnly && !ep.hasDub) return false;
      if (!needle) return true;
      return (
        ep.number.toLowerCase().includes(needle) ||
        (ep.title ?? "").toLowerCase().includes(needle)
      );
    });
  }, [dubOnly, filter, sorted]);

  const pageCount = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const safePage = Math.min(page, pageCount - 1);
  const slice = filtered.slice(safePage * PAGE_SIZE, safePage * PAGE_SIZE + PAGE_SIZE);

  if (!episodes.length) {
    return (
      <div className="panel p-6 text-center font-mono text-xs text-mist-500">
        no episodes were advertised for this title
      </div>
    );
  }

  return (
    <div className="panel">
      <div className="panel-header flex-wrap gap-2">
        <span className="label">
          {filtered.length} episode{filtered.length === 1 ? "" : "s"}
        </span>
        <div className="flex flex-wrap items-center gap-2">
          <input
            value={filter}
            onChange={(e) => {
              setFilter(e.target.value);
              setPage(0);
            }}
            placeholder="filter by number or title…"
            className="input !w-56 !py-1.5 !text-[11px]"
            aria-label="Filter episodes"
          />
          <button
            type="button"
            onClick={() => {
              setDubOnly((v) => !v);
              setPage(0);
            }}
            className={[
              "btn !py-1.5 !text-[10px]",
              dubOnly ? "!border-flare-400 !text-flare-400" : "",
            ].join(" ")}
          >
            {dubOnly ? "dub only ✓" : "dub only"}
          </button>
        </div>
      </div>

      <ul className="grid gap-px bg-ink-800 sm:grid-cols-2 xl:grid-cols-3">
        {slice.map((ep) => (
          <li key={ep.id} className="bg-ink-900">
            <Link
              href={`/watch/${animeSlug}/${ep.id}`}
              className="group flex h-full items-start gap-3 px-3 py-2.5 transition-colors hover:bg-ink-850"
            >
              <span className="mt-0.5 min-w-[3.2rem] shrink-0 border border-ink-600 bg-ink-950 px-1.5 py-0.5 text-center font-mono text-[11px] text-mist-300 group-hover:border-ember-500/60 group-hover:text-ember-300">
                {ep.number}
              </span>
              <span className="min-w-0 flex-1">
                <span className="line-clamp-2 block text-[12.5px] leading-snug text-mist-200 group-hover:text-mist-50">
                  {ep.title ?? `Episode ${ep.number}`}
                </span>
                <span className="mt-1 flex flex-wrap items-center gap-1">
                  <span className="font-mono text-[9.5px] text-mist-500">id {ep.id}</span>
                  {ep.hasSub && <span className="chip !px-1.5 !py-0 !text-[9px] text-signal-400">sub</span>}
                  {ep.hasDub && <span className="chip !px-1.5 !py-0 !text-[9px] text-flare-400">dub</span>}
                </span>
              </span>
              <span className="mt-1 shrink-0 font-mono text-[11px] text-ink-500 transition-colors group-hover:text-ember-500">
                ▸
              </span>
            </Link>
          </li>
        ))}
      </ul>

      {pageCount > 1 && (
        <div className="flex items-center justify-between gap-3 border-t border-ink-700 px-3 py-2.5">
          <button
            type="button"
            className="btn !py-1.5 !text-[10px]"
            disabled={safePage === 0}
            onClick={() => setPage((p) => Math.max(0, p - 1))}
          >
            ← prev
          </button>
          <span className="font-mono text-[10.5px] text-mist-500">
            page {safePage + 1} / {pageCount}
          </span>
          <button
            type="button"
            className="btn !py-1.5 !text-[10px]"
            disabled={safePage >= pageCount - 1}
            onClick={() => setPage((p) => Math.min(pageCount - 1, p + 1))}
          >
            next →
          </button>
        </div>
      )}
    </div>
  );
}

"use client";

import { useState } from "react";
import { CopyButton } from "./CopyButton";

interface BulkLink {
  anilistId: number;
  episode: number;
  title: string;
  provider: string;
  link: string;
  proxyPath: string;
  quality: string;
  audio: string;
  cached: boolean;
}

interface BulkResult {
  ok: boolean;
  data?: {
    scope: unknown;
    providers: string[];
    total: number;
    ok: number;
    failed: number;
    links: BulkLink[];
    errors: Array<{ anilistId: number; episode: number; error: string }>;
    tookMs: number;
  };
  error?: string;
}

export function BulkScrape() {
  const [mode, setMode] = useState<"ids" | "chart">("ids");
  const [ids, setIds] = useState("1-20");
  const [chart, setChart] = useState<"trending" | "popular">("trending");
  const [period, setPeriod] = useState<"day" | "week" | "month">("week");
  const [count, setCount] = useState("100");
  const [type, setType] = useState<"sub" | "dub">("sub");
  const [episodes, setEpisodes] = useState<"first" | "all">("first");
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<BulkResult | null>(null);
  const [copiedAll, setCopiedAll] = useState(false);

  async function run() {
    setBusy(true);
    setResult(null);
    try {
      const scope =
        mode === "ids"
          ? ids.trim()
          : { kind: "chart", chart, period, limit: Number(count) || 100 };
      const res = await fetch("/api/bulk", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          scope,
          type,
          episodes,
          limit: Number(count) || 100,
        }),
      });
      setResult((await res.json()) as BulkResult);
    } catch (err) {
      setResult({ ok: false, error: err instanceof Error ? err.message : String(err) });
    } finally {
      setBusy(false);
    }
  }

  const links = result?.data?.links ?? [];
  const allLinks = links.map((l) => l.link).join("\n");

  async function copyAll() {
    try {
      await navigator.clipboard.writeText(allLinks);
    } catch {
      const ta = document.createElement("textarea");
      ta.value = allLinks;
      ta.style.position = "fixed";
      ta.style.opacity = "0";
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      document.body.removeChild(ta);
    }
    setCopiedAll(true);
    setTimeout(() => setCopiedAll(false), 1500);
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="panel">
        <div className="panel-header">
          <span className="label">bulk scrape</span>
          <span className="font-mono text-[10px] text-mist-500">
            metadata from anikototv.to · links via /proxy/hls
          </span>
        </div>

        <div className="flex flex-col gap-3 p-3">
          <div className="flex flex-wrap gap-1.5">
            <button
              type="button"
              onClick={() => setMode("ids")}
              className={["btn !py-1.5 !text-[10px]", mode === "ids" ? "!border-ember-500 !text-ember-300" : ""].join(" ")}
            >
              anilist id range
            </button>
            <button
              type="button"
              onClick={() => setMode("chart")}
              className={["btn !py-1.5 !text-[10px]", mode === "chart" ? "!border-ember-500 !text-ember-300" : ""].join(" ")}
            >
              trending / popular
            </button>
          </div>

          {mode === "ids" ? (
            <label className="flex flex-col gap-1.5">
              <span className="label">id range or list — e.g. 1-1000 or 21,154587</span>
              <input value={ids} onChange={(e) => setIds(e.target.value)} className="input !py-2 !text-sm" placeholder="1-1000" />
            </label>
          ) : (
            <div className="grid gap-3 sm:grid-cols-3">
              <label className="flex flex-col gap-1.5">
                <span className="label">chart</span>
                <select value={chart} onChange={(e) => setChart(e.target.value as "trending" | "popular")} className="input !py-2 !text-sm">
                  <option value="trending">trending</option>
                  <option value="popular">all-time popular</option>
                </select>
              </label>
              {chart === "trending" && (
                <label className="flex flex-col gap-1.5">
                  <span className="label">period</span>
                  <select value={period} onChange={(e) => setPeriod(e.target.value as "day" | "week" | "month")} className="input !py-2 !text-sm">
                    <option value="day">today</option>
                    <option value="week">this week</option>
                    <option value="month">this month</option>
                  </select>
                </label>
              )}
              <label className="flex flex-col gap-1.5">
                <span className="label">top N anime</span>
                <input value={count} onChange={(e) => setCount(e.target.value.replace(/[^\d]/g, ""))} inputMode="numeric" className="input !py-2 !text-sm" placeholder="100" />
              </label>
            </div>
          )}

          <div className="flex flex-wrap items-center gap-2">
            <label className="flex items-center gap-1.5">
              <span className="label">audio</span>
              <select value={type} onChange={(e) => setType(e.target.value as "sub" | "dub")} className="rounded-[3px] border border-ink-600 bg-ink-850 px-2 py-1.5 font-mono text-[11px] text-mist-200 outline-none focus:border-ember-500">
                <option value="sub">sub</option>
                <option value="dub">dub</option>
              </select>
            </label>
            <label className="flex items-center gap-1.5">
              <span className="label">episodes</span>
              <select value={episodes} onChange={(e) => setEpisodes(e.target.value as "first" | "all")} className="rounded-[3px] border border-ink-600 bg-ink-850 px-2 py-1.5 font-mono text-[11px] text-mist-200 outline-none focus:border-ember-500">
                <option value="first">episode 1 only</option>
                <option value="all">all episodes</option>
              </select>
            </label>
            <button type="button" onClick={() => void run()} disabled={busy} className="btn btn-primary !py-2 !text-[12px]">
              {busy ? "scraping…" : "run bulk scrape"}
            </button>
          </div>

          <p className="font-mono text-[10px] leading-relaxed text-mist-500">
            provider chain: reanime → xmark → kaa → aniwaves → xanime → anizone → animegg → anikoto
            (animotvslash and ani.pm excluded)
          </p>
        </div>
      </div>

      {result && !result.ok && (
        <div className="panel border-alert-500/50 p-3 font-mono text-xs text-alert-400">{result.error}</div>
      )}

      {result?.ok && result.data && (
        <div className="panel">
          <div className="panel-header">
            <span className="label">
              {result.data.ok} links · {result.data.failed} failed · {result.data.total} titles ·{" "}
              {result.data.tookMs}ms
            </span>
            {links.length > 0 && (
              <CopyButton
                value={allLinks}
                label={copiedAll ? "copied" : "copy all links"}
                copiedLabel="copied"
              />
            )}
          </div>
          {links.length > 0 ? (
            <ul className="divide-y divide-ink-800">
              {links.slice(0, 200).map((l) => (
                <li key={`${l.anilistId}-${l.episode}`} className="flex flex-wrap items-center gap-2 px-3 py-2">
                  <span className="w-16 shrink-0 font-mono text-[10px] text-ember-400">al {l.anilistId}</span>
                  <span className="font-mono text-[10px] text-mist-500">ep {l.episode}</span>
                  <span className="chip !text-[9.5px]">{l.provider}</span>
                  <span className="min-w-0 flex-1 truncate text-[12px] text-mist-200" title={l.title}>
                    {l.title}
                  </span>
                  <span className="font-mono text-[10px] text-mist-500">
                    {l.quality} · {l.audio}
                  </span>
                  <CopyButton value={l.link} label="copy" />
                </li>
              ))}
            </ul>
          ) : (
            <p className="px-4 py-8 text-center font-mono text-xs text-mist-500">
              no links generated — every provider failed for every title
            </p>
          )}
          {result.data.errors.length > 0 && (
            <div className="border-t border-ink-800 px-3 py-2 font-mono text-[10px] text-mist-500">
              {result.data.errors.slice(0, 10).map((e) => (
                <p key={`${e.anilistId}-${e.episode}`} className="text-alert-400/80">
                  al {e.anilistId} ep {e.episode}: {e.error.slice(0, 90)}
                </p>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

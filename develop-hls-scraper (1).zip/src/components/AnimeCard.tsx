import Link from "next/link";
import type { AnimeListItem } from "@/lib/types";

export function AnimeCard({ item, index }: { item: AnimeListItem; index?: number }) {
  return (
    <Link
      href={`/anime/${item.slug}`}
      className="panel group relative flex flex-col overflow-hidden transition-colors hover:border-ember-500/70"
    >
      <div className="relative aspect-[2/3] w-full overflow-hidden bg-ink-850">
        {item.poster ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={item.poster}
            alt={item.title}
            referrerPolicy="no-referrer"
            loading="lazy"
            className="size-full object-cover opacity-90 transition duration-500 group-hover:scale-[1.04] group-hover:opacity-100"
          />
        ) : (
          <div className="grid size-full place-items-center font-mono text-[10px] text-mist-500">
            no poster
          </div>
        )}
        <div className="absolute inset-x-0 bottom-0 h-24 bg-gradient-to-t from-ink-950 via-ink-950/70 to-transparent" />

        {typeof index === "number" && (
          <span className="absolute top-0 left-0 bg-ember-500 px-1.5 py-0.5 font-mono text-[10px] font-semibold text-ink-950">
            {String(index + 1).padStart(2, "0")}
          </span>
        )}

        <div className="absolute right-2 bottom-2 left-2 flex flex-wrap items-center gap-1">
          {item.subCount ? <span className="chip border-signal-500/40 text-signal-400">SUB {item.subCount}</span> : null}
          {item.dubCount ? <span className="chip border-flare-400/40 text-flare-400">DUB {item.dubCount}</span> : null}
          {item.type ? <span className="chip">{item.type}</span> : null}
          {item.score ? <span className="chip border-ember-500/40 text-ember-300">★ {item.score}</span> : null}
        </div>
      </div>

      <div className="flex flex-1 flex-col gap-1.5 p-3">
        <h3 className="line-clamp-2 font-display text-[13.5px] leading-snug font-semibold text-mist-100 group-hover:text-ember-300">
          {item.title}
        </h3>
        <p className="truncate font-mono text-[10px] tracking-[0.06em] text-mist-500">
          {item.id} · {item.slug}
        </p>
        {item.genres.length > 0 && (
          <p className="line-clamp-1 text-[11px] text-mist-400">{item.genres.slice(0, 3).join(" · ")}</p>
        )}
      </div>
    </Link>
  );
}

"use client";

import { useState } from "react";

export function CopyButton({
  value,
  label = "copy",
  copiedLabel = "copied",
  className = "",
}: {
  value: string;
  label?: string;
  copiedLabel?: string;
  className?: string;
}) {
  const [done, setDone] = useState(false);

  async function copy() {
    try {
      await navigator.clipboard.writeText(value);
    } catch {
      const ta = document.createElement("textarea");
      ta.value = value;
      ta.style.position = "fixed";
      ta.style.opacity = "0";
      document.body.appendChild(ta);
      ta.select();
      try {
        document.execCommand("copy");
      } catch {
        /* ignore */
      }
      document.body.removeChild(ta);
    }
    setDone(true);
    setTimeout(() => setDone(false), 1400);
  }

  return (
    <button type="button" onClick={copy} className={`btn ${className}`} title={value}>
      <svg viewBox="0 0 24 24" className="size-3.5" aria-hidden>
        {done ? (
          <path d="M4 12.5 L9.5 18 L20 6.5" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="square" />
        ) : (
          <>
            <rect x="8.5" y="8.5" width="11" height="11" fill="none" stroke="currentColor" strokeWidth="1.8" />
            <path d="M15.5 5.5 H4.5 V16.5" fill="none" stroke="currentColor" strokeWidth="1.8" />
          </>
        )}
      </svg>
      {done ? copiedLabel : label}
    </button>
  );
}

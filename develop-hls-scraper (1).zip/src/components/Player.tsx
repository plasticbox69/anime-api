"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { CopyButton } from "./CopyButton";

type HlsType = import("hls.js").default;

export interface PlayerTrack {
  file: string;
  proxied?: string;
  label?: string;
  kind?: string;
  default?: boolean;
}

export interface PlayerProps {
  proxiedUrl: string;
  directUrl: string | null;
  /** True when the upstream manifest is XOR-encrypted / IP-bound and requires `/proxy/hls`. */
  requiresProxy?: boolean;
  posterUrl?: string | null;
  tracks?: PlayerTrack[];
  intro?: { start?: number | null; end?: number | null } | null;
  outro?: { start?: number | null; end?: number | null } | null;
  title: string;
  meta?: string;
  serverName?: string;
}

interface HlsAudioOption {
  id: number;
  name: string;
  lang: string | null;
}

interface QualityLevel {
  /** Exact index in `hls.levels` (or the native variant list). */
  index: number;
  width: number | null;
  height: number | null;
  bitrate: number;
  name: string | null;
  url?: string;
}

function relay(file: string) {
  return `/api/relay?url=${encodeURIComponent(file)}`;
}

function formatBitrate(bps: number): string {
  if (!bps || bps <= 0) return "";
  if (bps >= 1_000_000) return `${(bps / 1_000_000).toFixed(1)} Mbps`;
  return `${Math.round(bps / 1000)} kbps`;
}

function levelShortLabel(level: QualityLevel, all: QualityLevel[]): string {
  const base = level.height
    ? `${level.height}p`
    : level.name && /\d+p/i.test(level.name)
      ? level.name
      : level.bitrate > 0
        ? formatBitrate(level.bitrate)
        : `L${level.index + 1}`;
  // Disambiguate when two renditions share the same vertical resolution.
  const sameHeight =
    level.height != null && all.filter((other) => other.height === level.height).length > 1;
  if (sameHeight && level.bitrate > 0) {
    return `${base} (${formatBitrate(level.bitrate)})`;
  }
  return base;
}

function levelDetailTitle(level: QualityLevel): string {
  const parts: string[] = [];
  if (level.width && level.height) parts.push(`${level.width}×${level.height}`);
  else if (level.height) parts.push(`${level.height}p`);
  if (level.bitrate > 0) parts.push(formatBitrate(level.bitrate));
  return parts.join(" · ") || `Level ${level.index + 1}`;
}

/** Parses `#EXT-X-STREAM-INF` variants for browsers using native HLS without MSE. */
function parseMasterVariants(playlist: string, baseUrl: string): QualityLevel[] {
  const lines = playlist.split(/\r?\n/);
  const out: QualityLevel[] = [];
  for (let i = 0; i < lines.length; i += 1) {
    const line = lines[i].trim();
    if (!line.startsWith("#EXT-X-STREAM-INF:")) continue;
    const attrs = line.slice("#EXT-X-STREAM-INF:".length);
    let nextUri = "";
    for (let j = i + 1; j < lines.length; j += 1) {
      const candidate = lines[j].trim();
      if (!candidate) continue;
      if (!candidate.startsWith("#")) nextUri = candidate;
      i = j;
      break;
    }
    if (!nextUri) continue;

    const resMatch = attrs.match(/RESOLUTION=(\d+)x(\d+)/i);
    const bwMatch = attrs.match(/(?:AVERAGE-)?BANDWIDTH=(\d+)/i);
    const nameMatch = attrs.match(/NAME="([^"]+)"/i);
    let resolvedUrl = nextUri;
    try {
      resolvedUrl = new URL(nextUri, new URL(baseUrl, window.location.origin)).toString();
    } catch {
      /* keep raw */
    }
    out.push({
      index: out.length,
      width: resMatch ? Number(resMatch[1]) : null,
      height: resMatch ? Number(resMatch[2]) : null,
      bitrate: bwMatch ? Number(bwMatch[1]) : 0,
      name: nameMatch ? nameMatch[1] : null,
      url: resolvedUrl,
    });
  }
  return out;
}

export function Player({
  proxiedUrl,
  directUrl,
  requiresProxy = false,
  posterUrl,
  tracks = [],
  intro,
  outro,
  title,
  meta,
  serverName,
}: PlayerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const hlsRef = useRef<HlsType | null>(null);
  const engineRef = useRef<"hls" | "native" | null>(null);

  const [mode, setMode] = useState<"relay" | "direct">("relay");
  const [status, setStatus] = useState<"idle" | "loading" | "ready" | "error">("loading");
  const [fatal, setFatal] = useState<string | null>(null);

  const [levels, setLevels] = useState<QualityLevel[]>([]);
  /** User's explicit selection (`"auto"` vs a `QualityLevel.index`). */
  const [selectedQuality, setSelectedQuality] = useState<"auto" | number>("auto");
  /** Index in `levels` currently being rendered/buffered. */
  const [playingLevel, setPlayingLevel] = useState<number>(-1);
  /** Target index while a manual quality switch is fetching/flushing. */
  const [switchingLevel, setSwitchingLevel] = useState<number | null>(null);
  /** Alternate HLS audio tracks (`#EXT-X-MEDIA:TYPE=AUDIO`, e.g. Native vs English on reanime). */
  const [audioTracks, setAudioTracks] = useState<HlsAudioOption[]>([]);
  const [activeAudioTrack, setActiveAudioTrack] = useState<number>(-1);

  const [currentTime, setCurrentTime] = useState(0);
  const [stats, setStats] = useState({
    dropped: 0,
    buffered: 0,
    videoWidth: 0,
    videoHeight: 0,
  });

  const captionTracks = useMemo(
    () => tracks.filter((t) => (t.kind ?? "captions") !== "thumbnails"),
    [tracks],
  );

  // Present qualities highest -> lowest while preserving each item's `hls.levels` index.
  const sortedLevels = useMemo(
    () =>
      [...levels].sort((a, b) => {
        const dh = (b.height ?? 0) - (a.height ?? 0);
        if (dh !== 0) return dh;
        return (b.bitrate ?? 0) - (a.bitrate ?? 0);
      }),
    [levels],
  );

  const isDirectVideoFile = Boolean(
    directUrl && /\.(?:mp4|webm|mkv)(?:$|[?#])/i.test(directUrl),
  );
  const activeUrl = mode === "relay" || requiresProxy ? proxiedUrl : (directUrl ?? proxiedUrl);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    let cancelled = false;
    let hls: HlsType | null = null;
    engineRef.current = null;
    setStatus("loading");
    setFatal(null);
    setLevels([]);
    setSelectedQuality("auto");
    setPlayingLevel(-1);
    setSwitchingLevel(null);
    setAudioTracks([]);
    setActiveAudioTrack(-1);

    (async () => {
      if (isDirectVideoFile) {
        engineRef.current = "native";
        video.src = activeUrl;
        video.addEventListener(
          "loadedmetadata",
          () => {
            if (!cancelled) setStatus("ready");
            video.play().catch(() => undefined);
          },
          { once: true },
        );
        video.addEventListener(
          "error",
          () => {
            if (!cancelled) {
              setStatus("error");
              setFatal("failed to load MP4 stream");
            }
          },
          { once: true },
        );
        return;
      }

      const mod = await import("hls.js");
      if (cancelled) return;
      const Hls = mod.default;

      if (Hls.isSupported()) {
        engineRef.current = "hls";
        hls = new Hls({
          enableWorker: true,
          lowLatencyMode: false,
          backBufferLength: 60,
          manifestLoadingTimeOut: 20000,
          manifestLoadingMaxRetry: 3,
          levelLoadingMaxRetry: 4,
          fragLoadingMaxRetry: 6,
        });
        hlsRef.current = hls;

        hls.on(Hls.Events.MANIFEST_PARSED, (_evt, data) => {
          if (cancelled) return;
          const parsed: QualityLevel[] = data.levels.map((l, idx) => ({
            index: idx,
            width: l.width || null,
            height: l.height || null,
            bitrate: l.bitrate || 0,
            name: l.name || null,
          }));
          setLevels(parsed);
          if (typeof data.firstLevel === "number" && data.firstLevel >= 0) {
            setPlayingLevel(data.firstLevel);
          }
          if (hls && hls.audioTracks.length > 1) {
            setAudioTracks(
              hls.audioTracks.map((t, idx) => ({
                id: idx,
                name: t.name || t.lang || `Audio ${idx + 1}`,
                lang: t.lang ?? null,
              })),
            );
            setActiveAudioTrack(hls.audioTrack);
          }
          setStatus("ready");
          video.play().catch(() => undefined);
        });

        hls.on(Hls.Events.AUDIO_TRACKS_UPDATED, (_evt, data) => {
          if (cancelled || !hls) return;
          if (data.audioTracks.length > 1) {
            setAudioTracks(
              data.audioTracks.map((t, idx) => ({
                id: idx,
                name: t.name || t.lang || `Audio ${idx + 1}`,
                lang: t.lang ?? null,
              })),
            );
            setActiveAudioTrack(hls.audioTrack);
          }
        });

        hls.on(Hls.Events.AUDIO_TRACK_SWITCHED, (_evt, data) => {
          if (!cancelled) setActiveAudioTrack(data.id);
        });

        hls.on(Hls.Events.LEVEL_SWITCHING, (_evt, data) => {
          if (cancelled) return;
          if (hls && !hls.autoLevelEnabled) {
            setSwitchingLevel((prev) => (data.level !== prev ? data.level : prev));
          }
        });

        hls.on(Hls.Events.LEVEL_SWITCHED, (_evt, data) => {
          if (cancelled) return;
          setPlayingLevel(data.level);
          setSwitchingLevel((target) => (target === null || target === data.level ? null : target));
        });

        hls.on(Hls.Events.FRAG_CHANGED, (_evt, data) => {
          if (cancelled) return;
          const lvl = data.frag?.level;
          if (typeof lvl === "number" && lvl >= 0) {
            setPlayingLevel(lvl);
            setSwitchingLevel((target) => (target === null || target === lvl ? null : target));
          }
        });

        // When paused, FRAG_CHANGED/LEVEL_SWITCHED wait for playhead movement;
        // FRAG_BUFFERED fires as soon as the new quality segment is ready.
        hls.on(Hls.Events.FRAG_BUFFERED, (_evt, data) => {
          if (cancelled) return;
          const lvl = data.frag?.level;
          if (typeof lvl === "number" && lvl >= 0) {
            setSwitchingLevel((target) => {
              if (target === lvl) {
                setPlayingLevel(lvl);
                return null;
              }
              return target;
            });
          }
        });

        hls.on(Hls.Events.ERROR, (_evt, data) => {
          if (cancelled) return;
          if (!data.fatal) return;
          setStatus("error");
          if (data.type === Hls.ErrorTypes.NETWORK_ERROR) {
            setFatal(`network: ${data.details} — the relay could not reach the CDN`);
            hls?.startLoad();
          } else if (data.type === Hls.ErrorTypes.MEDIA_ERROR) {
            setFatal(`media: ${data.details} — attempting recovery`);
            hls?.recoverMediaError();
          } else {
            setFatal(`unrecoverable: ${data.details}`);
            hls?.destroy();
          }
        });

        hls.loadSource(activeUrl);
        hls.attachMedia(video);
      } else if (video.canPlayType("application/vnd.apple.mpegurl")) {
        engineRef.current = "native";
        video.src = activeUrl;
        video.addEventListener(
          "loadedmetadata",
          () => {
            if (!cancelled) setStatus("ready");
            video.play().catch(() => undefined);
          },
          { once: true },
        );
        // Inspect the master playlist so native-HLS browsers can switch variants too.
        try {
          const res = await fetch(activeUrl);
          if (res.ok) {
            const text = await res.text();
            if (!cancelled && text.trimStart().startsWith("#EXTM3U")) {
              const variants = parseMasterVariants(text, activeUrl);
              if (variants.length > 0) {
                setLevels(variants);
                setPlayingLevel(0);
              }
            }
          }
        } catch {
          /* native playback still proceeds */
        }
      } else {
        setStatus("error");
        setFatal("this browser supports neither MSE nor native HLS");
      }
    })();

    return () => {
      cancelled = true;
      try {
        hlsRef.current?.destroy();
      } catch {
        /* noop */
      }
      hlsRef.current = null;
      engineRef.current = null;
    };
  }, [activeUrl, isDirectVideoFile]);

  const syncVideoDimensions = useCallback(() => {
    const video = videoRef.current;
    if (!video) return;
    setStats((prev) =>
      prev.videoWidth === video.videoWidth && prev.videoHeight === video.videoHeight
        ? prev
        : { ...prev, videoWidth: video.videoWidth, videoHeight: video.videoHeight },
    );
  }, []);

  useEffect(() => {
    const id = setInterval(() => {
      const video = videoRef.current;
      if (!video) return;
      const q = video.getVideoPlaybackQuality?.();
      setStats({
        dropped: q?.droppedVideoFrames ?? 0,
        buffered: video.buffered.length
          ? Math.max(0, video.buffered.end(video.buffered.length - 1) - video.currentTime)
          : 0,
        videoWidth: video.videoWidth,
        videoHeight: video.videoHeight,
      });
    }, 1000);
    return () => clearInterval(id);
  }, []);

  const skipHint = useMemo(() => {
    if (intro?.start != null && intro.end != null && currentTime >= intro.start && currentTime < intro.end) {
      return { label: `skip intro → ${intro.end}s`, to: intro.end };
    }
    if (outro?.start != null && outro.end != null && currentTime >= outro.start && currentTime < outro.end) {
      return { label: `skip outro → ${outro.end}s`, to: outro.end };
    }
    return null;
  }, [currentTime, intro, outro]);

  const jump = useCallback((to: number) => {
    const video = videoRef.current;
    if (video) {
      video.currentTime = to;
      video.play().catch(() => undefined);
    }
  }, []);

  const changeLevel = useCallback(
    (value: "auto" | number) => {
      const engine = engineRef.current;
      const video = videoRef.current;

      if (engine === "hls") {
        const hls = hlsRef.current;
        if (!hls) return;

        if (value === "auto") {
          setSelectedQuality("auto");
          setSwitchingLevel(null);
          // Re-enable ABR smoothly without flushing the currently playing buffer.
          hls.nextLevel = -1;
          return;
        }

        if (value < 0 || value >= levels.length) return;
        setSelectedQuality(value);
        if (value !== playingLevel) {
          setSwitchingLevel(value);
        } else {
          setSwitchingLevel(null);
        }
        // Immediate switch: aborts in-flight load, flushes old rendition buffer,
        // and reloads the chosen level at the current playhead.
        hls.currentLevel = value;
        return;
      }

      if (engine === "native" && video) {
        const resumeAt = video.currentTime;
        const wasPaused = video.paused;
        if (value === "auto") {
          setSelectedQuality("auto");
          setSwitchingLevel(null);
          video.src = activeUrl;
        } else {
          const target = levels.find((l) => l.index === value);
          if (!target?.url) return;
          setSelectedQuality(value);
          setSwitchingLevel(value);
          video.src = target.url;
        }
        video.addEventListener(
          "loadedmetadata",
          () => {
            if (resumeAt > 0) video.currentTime = resumeAt;
            if (typeof value === "number") setPlayingLevel(value);
            setSwitchingLevel(null);
            if (!wasPaused) video.play().catch(() => undefined);
          },
          { once: true },
        );
      }
    },
    [activeUrl, levels, playingLevel],
  );

  const activeLevel = useMemo(
    () => (playingLevel >= 0 ? levels.find((l) => l.index === playingLevel) ?? null : null),
    [levels, playingLevel],
  );

  const pendingLevel = useMemo(
    () => (switchingLevel !== null ? levels.find((l) => l.index === switchingLevel) ?? null : null),
    [levels, switchingLevel],
  );

  return (
    <div className="flex flex-col gap-3">
      <div className="panel w-full max-w-full overflow-hidden">
        <div className="relative w-full overflow-hidden bg-black">
          {/* eslint-disable-next-line jsx-a11y/media-has-caption */}
          <video
            ref={videoRef}
            controls
            playsInline
            poster={posterUrl ?? undefined}
            crossOrigin="anonymous"
            className="block h-auto max-h-[62svh] w-full bg-black object-contain sm:max-h-[70svh]"
            onTimeUpdate={(e) => setCurrentTime(e.currentTarget.currentTime)}
            onLoadedMetadata={syncVideoDimensions}
            onResize={syncVideoDimensions}
          >
            {captionTracks.map((t) => (
              <track
                key={t.file}
                src={t.proxied ?? relay(t.file)}
                kind="subtitles"
                label={t.label ?? "subtitles"}
                srcLang={(t.label ?? "en").slice(0, 2).toLowerCase()}
                default={t.default ?? false}
              />
            ))}
          </video>

          {status === "loading" && (
            <div className="pointer-events-none absolute inset-0 grid place-items-center bg-ink-950/70">
              <div className="flex flex-col items-center gap-2">
                <div className="relative h-0.5 w-40 overflow-hidden bg-ink-700 sweep" />
                <span className="font-mono text-[10px] tracking-[0.18em] text-mist-400 uppercase">
                  negotiating hls…
                </span>
              </div>
            </div>
          )}

          {skipHint && (
            <button
              type="button"
              onClick={() => jump(skipHint.to)}
              className="btn btn-primary absolute right-4 bottom-16 shadow-lg"
            >
              {skipHint.label}
            </button>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-2 border-t border-ink-700 bg-ink-900 px-3 py-2.5">
          <span className="label">transport</span>
          <div className="flex overflow-hidden rounded-[3px] border border-ink-600">
            {(["relay", "direct"] as const).map((m) => {
              const disabled = m === "direct" && (!directUrl || requiresProxy);
              return (
                <button
                  key={m}
                  type="button"
                  onClick={() => !disabled && setMode(m)}
                  disabled={disabled}
                  title={
                    m === "direct" && requiresProxy
                      ? "FlixCloud _v7 manifests are XOR-encrypted and IP-bound — /proxy/hls is required"
                      : undefined
                  }
                  className={[
                    "px-3 py-1 font-mono text-[10.5px] tracking-[0.12em] uppercase transition-colors",
                    (requiresProxy ? m === "relay" : mode === m)
                      ? "bg-ember-500 text-ink-950"
                      : "bg-ink-850 text-mist-400 hover:text-mist-100",
                    disabled ? "cursor-not-allowed opacity-40" : "",
                  ].join(" ")}
                >
                  {m === "relay" ? "proxy" : m}
                </button>
              );
            })}
          </div>

          {audioTracks.length > 1 && (
            <>
              <span className="label ml-1">track</span>
              <div className="flex overflow-hidden rounded-[3px] border border-ink-600" role="group" aria-label="HLS audio track">
                {audioTracks.map((tr, idx) => (
                  <button
                    key={tr.id}
                    type="button"
                    onClick={() => {
                      const hls = hlsRef.current;
                      if (!hls) return;
                      hls.audioTrack = tr.id;
                      setActiveAudioTrack(tr.id);
                    }}
                    className={[
                      idx > 0 ? "border-l border-ink-600" : "",
                      "px-2.5 py-1 font-mono text-[10.5px] tracking-[0.06em] transition-colors",
                      activeAudioTrack === tr.id
                        ? "bg-ember-500 text-ink-950 font-semibold"
                        : "bg-ink-850 text-mist-400 hover:text-mist-100",
                    ].join(" ")}
                  >
                    {tr.name}
                  </button>
                ))}
              </div>
            </>
          )}

          <span className="label ml-1">quality</span>
          {sortedLevels.length === 0 ? (
            <span className="rounded-[3px] border border-ink-700 bg-ink-850 px-2.5 py-1 font-mono text-[10.5px] text-mist-500">
              {status === "loading" ? "loading…" : "auto"}
            </span>
          ) : sortedLevels.length === 1 ? (
            <span
              className="rounded-[3px] border border-ink-700 bg-ink-850 px-2.5 py-1 font-mono text-[10.5px] text-mist-300"
              title="Upstream master.m3u8 only provides a single video rendition for this episode"
            >
              {levelShortLabel(sortedLevels[0], sortedLevels)}
              <span className="ml-1.5 text-mist-500">· 1 source</span>
            </span>
          ) : sortedLevels.length <= 5 ? (
            <div className="flex flex-wrap overflow-hidden rounded-[3px] border border-ink-600" role="group" aria-label="Stream quality">
              <button
                type="button"
                onClick={() => changeLevel("auto")}
                title="Adaptive bitrate"
                className={[
                  "px-2.5 py-1 font-mono text-[10.5px] tracking-[0.1em] uppercase transition-colors",
                  selectedQuality === "auto"
                    ? "bg-ember-500 text-ink-950 font-semibold"
                    : "bg-ink-850 text-mist-400 hover:text-mist-100",
                ].join(" ")}
              >
                auto
                {selectedQuality === "auto" && activeLevel
                  ? ` · ${levelShortLabel(activeLevel, sortedLevels)}`
                  : ""}
              </button>
              {sortedLevels.map((lvl) => {
                const isSelected = selectedQuality === lvl.index;
                const isPending = switchingLevel === lvl.index;
                return (
                  <button
                    key={lvl.index}
                    type="button"
                    onClick={() => changeLevel(lvl.index)}
                    title={levelDetailTitle(lvl)}
                    className={[
                      "border-l border-ink-600 px-2.5 py-1 font-mono text-[10.5px] tracking-[0.06em] transition-colors",
                      isSelected
                        ? "bg-ember-500 text-ink-950 font-semibold"
                        : "bg-ink-850 text-mist-400 hover:text-mist-100",
                      isPending ? "animate-pulse" : "",
                    ].join(" ")}
                  >
                    {levelShortLabel(lvl, sortedLevels)}
                  </button>
                );
              })}
            </div>
          ) : (
            <select
              aria-label="Stream quality"
              value={selectedQuality === "auto" ? "auto" : String(selectedQuality)}
              onChange={(e) =>
                changeLevel(e.target.value === "auto" ? "auto" : Number(e.target.value))
              }
              className="rounded-[3px] border border-ink-600 bg-ink-850 px-2 py-1 font-mono text-[11px] text-mist-200 outline-none focus:border-ember-500"
            >
              <option value="auto">
                {activeLevel && selectedQuality === "auto"
                  ? `auto (${levelShortLabel(activeLevel, sortedLevels)})`
                  : "auto"}
              </option>
              {sortedLevels.map((lvl) => (
                <option key={lvl.index} value={String(lvl.index)}>
                  {levelShortLabel(lvl, sortedLevels)}
                  {lvl.bitrate > 0 ? ` · ${formatBitrate(lvl.bitrate)}` : ""}
                </option>
              ))}
            </select>
          )}

          <div className="ml-auto flex flex-wrap items-center gap-2 font-mono text-[10px] text-mist-500">
            <span
              className={
                status === "ready"
                  ? "text-signal-400"
                  : status === "error"
                    ? "text-alert-400"
                    : "text-ember-400"
              }
            >
              ● {status}
            </span>
            {pendingLevel ? (
              <span className="text-ember-300">
                switching → {levelShortLabel(pendingLevel, sortedLevels)}…
              </span>
            ) : stats.videoHeight > 0 ? (
              <span className="text-mist-300">
                {stats.videoWidth}×{stats.videoHeight}
              </span>
            ) : activeLevel?.height ? (
              <span className="text-mist-300">{activeLevel.height}p</span>
            ) : null}
            {activeLevel?.bitrate ? (
              <span>{(activeLevel.bitrate / 1_000_000).toFixed(2)} mb/s</span>
            ) : null}
            <span>buf {stats.buffered.toFixed(1)}s</span>
            {stats.dropped > 0 && <span className="text-alert-400">drop {stats.dropped}</span>}
            {serverName && <span className="chip">{serverName}</span>}
          </div>
        </div>

        {fatal && (
          <div className="border-t border-alert-500/40 bg-alert-500/8 px-3 py-2 font-mono text-[11px] text-alert-400">
            {fatal}
          </div>
        )}
      </div>

      <div className="panel p-3">
        <div className="flex flex-wrap items-baseline gap-x-3 gap-y-1">
          <h1 className="font-display text-lg font-bold text-mist-50">{title}</h1>
          {meta && <span className="font-mono text-[11px] text-mist-500">{meta}</span>}
        </div>

        <div className="mt-3 flex flex-col gap-2">
          <div className="flex flex-col gap-1.5 sm:flex-row sm:items-center">
            <span className="label w-24 shrink-0">relay url</span>
            <code className="min-w-0 flex-1 truncate rounded-[3px] border border-ink-700 bg-ink-950 px-2 py-1.5 font-mono text-[11px] text-signal-400">
              {proxiedUrl}
            </code>
            <CopyButton value={proxiedUrl} label="copy" />
          </div>
          {directUrl && (
            <div className="flex flex-col gap-1.5 sm:flex-row sm:items-center">
              <span className="label w-24 shrink-0">master m3u8</span>
              <code className="min-w-0 flex-1 truncate rounded-[3px] border border-ink-700 bg-ink-950 px-2 py-1.5 font-mono text-[11px] text-ember-300">
                {directUrl}
              </code>
              <CopyButton value={directUrl} label="copy" />
            </div>
          )}
        </div>

        {(intro?.start != null || outro?.start != null) && (
          <p className="mt-3 font-mono text-[10.5px] text-mist-500">
            skip markers · intro {intro?.start ?? "–"}–{intro?.end ?? "–"}s · outro {outro?.start ?? "–"}–
            {outro?.end ?? "–"}s
          </p>
        )}
        {captionTracks.length > 0 && (
          <p className="mt-1 font-mono text-[10.5px] text-mist-500">
            {captionTracks.length} subtitle track(s):{" "}
            {captionTracks.map((t) => t.label ?? "unlabelled").join(", ")}
          </p>
        )}
      </div>
    </div>
  );
}

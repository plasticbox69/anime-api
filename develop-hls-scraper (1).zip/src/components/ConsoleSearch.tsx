"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import Link from "next/link";
import { AnimeCard } from "./AnimeCard";
import type { AnimeListItem, PageMeta } from "@/lib/types";

const PIPELINE = ["query", "filter page", "parse cards", "upsert pg", "respond"];

interface SearchResponse {
  ok: boolean;
  cached?: boolean;
  data?: { query: string; items: AnimeListItem[]; pagination: PageMeta };
  error?: string;
}

export function ConsoleSearch() {
  const [query, setQuery] = useState("");
  const [page, setPage] = useState(1);
  const [busy, setBusy] = useState(false);
  const [step, setStep] = useState(-1);
  const [result, setResult] = useState<SearchResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [elapsed, setElapsed] = useState<number | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const resultsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (e.key === "/" && document.activeElement !== inputRef.current) {
        const tag = (document.activeElement?.tagName ?? "").toLowerCase();
        if (tag !== "input" && tag !== "textarea") {
          e.preventDefault();
          inputRef.current?.focus();
        }
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const run = useCallback(
    async (nextPage: number) => {
      const q = query.trim();
      if (!q || busy) return;
      setBusy(true);
      setError(null);
      setStep(0);
      const started = performance.now();

      const timer = setInterval(() => {
        setStep((s) => (s < PIPELINE.length - 1 ? s + 1 : s));
      }, 190);

      try {
        const res = await fetch(`/api/search?q=${encodeURIComponent(q)}&page=${nextPage}`);
        const json = (await res.json()) as SearchResponse;
        setResult(json);
        if (!json.ok) setError(json.error ?? `upstream responded ${res.status}`);
        setPage(nextPage);
        setElapsed(Math.round(performance.now() - started));
        if (json.ok && resultsRef.current) {
          resultsRef.current.scrollIntoView({ behavior: "smooth", block: "start" });
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : String(err));
      } finally {
        clearInterval(timer);
        setStep(PIPELINE.length - 1);
        setBusy(false);
      }
    },
    [busy, query],
  );

  const items = result?.data?.items ?? [];
  const pagination = result?.data?.pagination;

  return (
    <div className="flex flex-col gap-5">
      <form
        onSubmit={(e) => {
          e.preventDefault();
          void run(1);
        }}
        className="panel overflow-hidden"
      >
        <div className="flex items-center gap-2 border-b border-ink-700 bg-ink-850/60 px-3 py-2">
          <span className="font-mono text-[10px] tracking-[0.18em] text-mist-500 uppercase">
            scrape://anikototv.to/filter
          </span>
          <span className="ml-auto flex items-center gap-2 font-mono text-[10px] text-mist-500">
            {elapsed !== null && !busy ? <span className="text-signal-400">{elapsed}ms</span> : null}
            <span className="hidden sm:inline">press</span>
            <kbd className="hidden border border-ink-600 bg-ink-900 px-1.5 py-0.5 text-[10px] text-mist-300 sm:inline">
              /
            </kbd>
          </span>
        </div>

        <div className="flex flex-col gap-3 p-3 sm:flex-row sm:items-center">
          <div className="flex flex-1 items-center gap-2 border border-ink-600 bg-ink-950 px-3 focus-within:border-ember-500">
            <span className="font-mono text-sm text-ember-500">›</span>
            <input
              ref={inputRef}
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="one piece, solo leveling, frieren…"
              className="w-full bg-transparent py-3 font-mono text-sm text-mist-100 outline-none placeholder:text-mist-500"
              aria-label="Search keyword"
            />
            {busy && <span className="caret font-mono text-xs text-mist-500">scraping</span>}
          </div>
          <button type="submit" className="btn btn-primary whitespace-nowrap" disabled={busy || !query.trim()}>
            {busy ? "running…" : "run scrape"}
          </button>
        </div>

        <div className="relative flex flex-wrap items-center gap-x-4 gap-y-2 border-t border-ink-700 bg-ink-900/60 px-3 py-2.5">
          {PIPELINE.map((label, i) => {
            const active = busy && step === i;
            const done = step > i || (!busy && step >= i && result !== null);
            return (
              <span key={label} className="flex items-center gap-1.5 font-mono text-[10px] tracking-[0.1em] uppercase">
                <span
                  className={[
                    "size-1.5 rounded-full transition-colors",
                    active ? "bg-ember-500 pulse-dot" : done ? "bg-signal-500" : "bg-ink-600",
                  ].join(" ")}
                />
                <span className={active ? "text-ember-300" : done ? "text-mist-300" : "text-mist-500"}>{label}</span>
                {i < PIPELINE.length - 1 && <span className="ml-2 text-ink-500">→</span>}
              </span>
            );
          })}
        </div>
      </form>

      {error && (
        <div className="panel border-alert-500/50 p-3 font-mono text-xs text-alert-400">
          <span className="mr-2 text-mist-500">error:</span>
          {error}
        </div>
      )}

      <div ref={resultsRef}>
        {items.length > 0 && (
          <div className="rise-in flex flex-col gap-4">
            <div className="flex flex-wrap items-baseline gap-3">
              <h2 className="font-display text-lg font-bold text-mist-50">
                {items.length} titles
              </h2>
              <span className="font-mono text-[11px] text-mist-500">
                for “{result?.data?.query}” · page {pagination?.page ?? 1}/{pagination?.totalPages ?? 1}
              </span>
              {pagination && pagination.totalPages > 1 && (
                <div className="ml-auto flex gap-2">
                  <button
                    className="btn"
                    disabled={busy || (pagination.page ?? 1) <= 1}
                    onClick={() => void run((pagination.page ?? 1) - 1)}
                  >
                    ← prev
                  </button>
                  <button
                    className="btn"
                    disabled={busy || !pagination.hasNext}
                    onClick={() => void run((pagination.page ?? 1) + 1)}
                  >
                    next →
                  </button>
                </div>
              )}
            </div>

            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5 xl:grid-cols-6">
              {items.map((item) => (
                <AnimeCard key={item.id} item={item} />
              ))}
            </div>
          </div>
        )}

        {result && !error && items.length === 0 && (
          <div className="panel p-6 text-center font-mono text-xs text-mist-500">
            no titles matched “{result.data?.query}”
          </div>
        )}
      </div>

      <p className="font-mono text-[10.5px] leading-relaxed text-mist-500">
        results are cached in postgres · open a title to index its episodes, then resolve a
        playlist. See <Link href="/docs" className="text-ember-400 underline decoration-dotted">/docs</Link> for the raw endpoints.
      </p>
    </div>
  );
}

"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { Player } from "./Player";
import type { ResolvedSource, ServerItem } from "@/lib/types";

interface ServersResponse {
  ok: boolean;
  data?: { episodeId: string; servers: ServerItem[] };
  error?: string;
}

interface SourceResponse {
  ok: boolean;
  cached?: boolean;
  data?: {
    episodeId: string;
    animeId: string | null;
    server: ServerItem;
    resolved: ResolvedSource;
    proxiedUrl: string;
    cached: boolean;
  };
  error?: string;
  hint?: string;
}

export function WatchPanel({
  episodeId,
  animeSlug,
  animeTitle,
  episodeNumber,
  episodeTitle,
}: {
  episodeId: string;
  animeSlug: string;
  animeTitle: string;
  episodeNumber: string;
  episodeTitle?: string | null;
}) {
  const [servers, setServers] = useState<ServerItem[]>([]);
  const [selected, setSelected] = useState<string | null>(null);
  const [source, setSource] = useState<SourceResponse["data"] | null>(null);
  const [phase, setPhase] = useState<"servers" | "resolving" | "ready" | "error">("servers");
  const [error, setError] = useState<string | null>(null);
  const [log, setLog] = useState<string[]>([]);

  const append = useCallback((line: string) => {
    setLog((prev) => [...prev.slice(-40), `${new Date().toLocaleTimeString()}  ${line}`]);
  }, []);

  const resolve = useCallback(
    async (key: string | null, force = false) => {
      setPhase("resolving");
      setError(null);
      append(`ajax/server/list → episode ${episodeId}`);
      try {
        // Keys are "type:serverId" — sub and dub share server ids.
        const [audio, serverId] = key ? key.split(":") : [null, null];
        const params = new URLSearchParams();
        if (serverId) params.set("server", serverId);
        if (audio) params.set("type", audio);
        if (force) params.set("force", "1");
        const res = await fetch(`/api/episodes/${episodeId}/source?${params.toString()}`);
        const json = (await res.json()) as SourceResponse;
        if (!json.ok || !json.data) {
          setPhase("error");
          setError(json.error ?? `upstream responded ${res.status}`);
          append(`✗ ${json.error ?? res.status}`);
          return;
        }
        append(`✓ ajax/server?get → ${json.data.resolved.embedUrl}`);
        append(`✓ getSourcesNew → aes-256-cbc decrypt → ${json.data.resolved.hlsUrl}`);
        setSource(json.data);
        setSelected(`${json.data.server.type}:${json.data.server.serverId}`);
        setPhase("ready");
      } catch (err) {
        setPhase("error");
        const message = err instanceof Error ? err.message : String(err);
        setError(message);
        append(`✗ ${message}`);
      }
    },
    [append, episodeId, selected],
  );

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch(`/api/episodes/${episodeId}/servers`);
        const json = (await res.json()) as ServersResponse;
        if (cancelled) return;
        if (json.ok && json.data) {
          setServers(json.data.servers);
          append(`✓ ${json.data.servers.length} server(s) advertised`);
          const first = json.data.servers[0];
          if (first) {
            const key = `${first.type}:${first.serverId}`;
            setSelected(key);
            await resolve(key);
          }
        } else {
          setPhase("error");
          setError(json.error ?? "could not list servers");
        }
      } catch (err) {
        if (cancelled) return;
        setPhase("error");
        setError(err instanceof Error ? err.message : String(err));
      }
    })();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [episodeId]);

  const byType = (type: string) => servers.filter((s) => s.type === type);
  const types = Array.from(new Set(servers.map((s) => s.type)));

  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-wrap items-center gap-3">
        <Link
          href={`/anime/${animeSlug}`}
          className="font-mono text-[11px] text-mist-500 transition-colors hover:text-ember-400"
        >
          ← {animeTitle}
        </Link>
        <span className="font-mono text-[11px] text-ink-500">/</span>
        <span className="font-mono text-[11px] text-mist-300">ep {episodeNumber}</span>
        <span className="chip ml-auto">episode id {episodeId}</span>
      </div>

      {phase === "ready" && source ? (
        <Player
          proxiedUrl={source.proxiedUrl}
          directUrl={source.resolved.hlsUrl}
          posterUrl={source.resolved.posterUrl}
          tracks={source.resolved.tracks}
          intro={source.resolved.intro}
          outro={source.resolved.outro}
          title={episodeTitle ?? `${animeTitle} — Episode ${episodeNumber}`}
          meta={`${animeTitle} · ep ${episodeNumber}${source.cached ? " · served from cache" : ""}`}
          serverName={source.server.name}
        />
      ) : (
        <div className="panel grid aspect-video place-items-center">
          {phase === "error" ? (
            <div className="max-w-md px-6 text-center">
              <p className="font-display text-lg font-bold text-alert-400">extraction failed</p>
              <p className="mt-2 font-mono text-[11.5px] leading-relaxed break-words text-mist-400">
                {error}
              </p>
              <button type="button" className="btn btn-primary mt-4" onClick={() => void resolve(selected, true)}>
                retry chain
              </button>
            </div>
          ) : (
            <div className="flex flex-col items-center gap-3">
              <div className="relative h-0.5 w-52 overflow-hidden bg-ink-700 sweep" />
              <p className="font-mono text-[11px] tracking-[0.16em] text-mist-400 uppercase">
                {phase === "servers" ? "listing servers…" : "decrypting playlist…"}
              </p>
            </div>
          )}
        </div>
      )}

      <div className="grid gap-4 lg:grid-cols-12">
        <div className="panel lg:col-span-5">
          <div className="panel-header">
            <span className="label">servers</span>
            <span className="font-mono text-[10px] text-mist-500">{servers.length} available</span>
          </div>
          {servers.length === 0 ? (
            <p className="px-3 py-6 text-center font-mono text-[11px] text-mist-500">
              waiting for ajax/server/list…
            </p>
          ) : (
            <div className="divide-y divide-ink-800">
              {types.map((type) => (
                <div key={type} className="px-3 py-2">
                  <p className="label mb-1.5">{type}</p>
                  <div className="flex flex-wrap gap-1.5">
                    {byType(type).map((s) => (
                      <button
                        key={`${s.type}-${s.serverId}-${s.name}`}
                        type="button"
                        disabled={phase === "resolving"}
                        onClick={() => {
                          setSelected(`${s.type}:${s.serverId}`);
                          void resolve(`${s.type}:${s.serverId}`);
                        }}
                        className={[
                          "border px-2.5 py-1 font-mono text-[10.5px] tracking-[0.06em] transition-colors disabled:opacity-50",
                          selected === `${s.type}:${s.serverId}`
                            ? "border-ember-500 bg-ember-500/12 text-ember-300"
                            : "border-ink-600 bg-ink-850 text-mist-400 hover:border-ink-500 hover:text-mist-100",
                        ].join(" ")}
                      >
                        {s.name}
                        <span className="ml-1.5 text-mist-500">{s.serverId}</span>
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
          {source && (
            <div className="border-t border-ink-700 px-3 py-2.5">
              <button
                type="button"
                className="btn w-full !py-1.5 !text-[10px]"
                disabled={phase === "resolving"}
                onClick={() => void resolve(selected, true)}
              >
                force re-resolve
              </button>
            </div>
          )}
        </div>

        <div className="panel lg:col-span-7">
          <div className="panel-header">
            <span className="label">scrape log</span>
            <span className="font-mono text-[10px] text-mist-500">client trace</span>
          </div>
          <pre className="max-h-64 overflow-auto px-3 py-2.5 font-mono text-[10.5px] leading-relaxed break-all text-mist-400">
            {log.length ? log.join("\n") : "awaiting first hop…"}
          </pre>
        </div>
      </div>
    </div>
  );
}

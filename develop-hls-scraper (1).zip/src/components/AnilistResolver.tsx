"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import Link from "next/link";
import { Player } from "./Player";
import { CopyButton } from "./CopyButton";

type AudioType = "sub" | "dub";
type Strategy = "auto" | "site" | "direct";
export type ProviderChoice =
  | "anikoto"
  | "reanime"
  | "aniwaves"
  | "anipm"
  | "anizone"
  | "xanime"
  | "animegg"
  | "animotvslash"
  | "auto"
  | (string & {});

interface Attempt {
  step: string;
  ok: boolean;
  detail?: string;
}

interface Skip {
  start?: number | null;
  end?: number | null;
}

interface StreamData {
  anilistId: number;
  episode: number;
  requestedProvider: ProviderChoice;
  provider:
    | "anikoto"
    | "reanime"
    | "aniwaves"
    | "anipm"
    | "anizone"
    | "xanime"
    | "animegg"
    | "animotvslash"
  | "xmark"
  | "kaa"
  | "atv";
  requestedType: string;
  type: string;
  typeFallback: boolean;
  strategy: "site" | "direct";
  stream: {
    m3u8: string;
    proxied: string;
    probe: string;
    proxyCtx: string;
    proxyExp: number;
    manifestKey: string | null;
    legacyRelay: string;
    referer: string;
    headers: Record<string, string>;
    subtitles: Array<{
      file: string;
      label: string | null;
      format?: string | null;
      default: boolean;
      proxied: string;
    }>;
    thumbnails: string | null;
    intro: Skip | null;
    outro: Skip | null;
    poster: string | null;
    server: { name: string; id: string } | null;
    embed: string;
  };
  anilist: {
    id: number;
    idMal: number | null;
    title: string;
    romaji: string | null;
    english: string | null;
    native: string | null;
    format: string | null;
    status: string | null;
    episodes: number | null;
    seasonYear: number | null;
    season: string | null;
    cover: string | null;
    banner: string | null;
    color: string | null;
    genres: string[];
    averageScore: number | null;
    nextAiringEpisode: { episode: number; airingAt: number } | null;
    url: string;
  } | null;
  match: {
    animeId: string;
    slug: string;
    title: string;
    method: string;
    confidence: number;
    malId: string | null;
    siteUrl: string;
    cached: boolean;
    episodeId: string;
    episodeTitle: string | null;
    availableEpisodes: number;
    firstEpisode: string | null;
    lastEpisode: string | null;
  } | null;
  attempts: Attempt[];
  cached: boolean;
  tookMs: number;
  links: {
    json: string;
    playlist: string;
    proxy: string;
    probe: string;
    relay: string;
    page: string;
  };
}

interface ApiResponse {
  ok: boolean;
  data?: StreamData;
  error?: string;
  details?: unknown;
}

const PROVIDERS: Array<{ id: ProviderChoice; label: string; badge: string }> = [
  { id: "anipm", label: "ani.pm", badge: "settlar hls" },
  { id: "reanime", label: "reanime.to", badge: "flixcloud" },
  { id: "anizone", label: "anizone.to", badge: "vid-cdn" },
  { id: "xanime", label: "xanime.me", badge: "xanivsrc" },
  { id: "anikoto", label: "anikototv.to", badge: "megaplay" },
  { id: "kaa", label: "kaa.lt", badge: "krussdomi hls" },
  { id: "atv", label: "animetvplus.xyz", badge: "uqload hls" },
  { id: "aniwaves", label: "aniwaves.ru", badge: "echovideo" },
  { id: "animegg", label: "animegg.org", badge: "vidcache" },
  { id: "animotvslash", label: "animotvslash.org", badge: "real" },
  { id: "xmark", label: "xmark", badge: "watermark-free" },
  { id: "auto", label: "auto", badge: "multi-failover" },
];

/** Experimental or Cloudflare/Turnstile-guarded sites. */
const EXTRA_SITES: Array<{
  id: string;
  label: string;
  mode: "browser" | "manga" | "blocked";
  reason: string;
}> = [
  {
    id: "senshi",
    label: "senshi.to",
    mode: "blocked",
    reason: "artplayer.org embed is guarded by Cloudflare Turnstile",
  },
  {
    id: "2dhive",
    label: "2dhive.com",
    mode: "blocked",
    reason: "babastream.top embed is guarded by Cloudflare Turnstile",
  },
  {
    id: "gotaku",
    label: "gotaku.to",
    mode: "blocked",
    reason: "gotakudl.top embed links currently return upstream 404",
  },
  {
    id: "mmani",
    label: "mmani.com",
    mode: "blocked",
    reason: "content links redirect to external social/FB embeds",
  },
  {
    id: "anisnatch",
    label: "anisnatch.to",
    mode: "blocked",
    reason: "uses client-side pako binary compression",
  },
  {
    id: "mkissa",
    label: "mkissa.to",
    mode: "manga",
    reason: "manga reader — no video streams available",
  },
];

const PROVIDER_DISPLAY: Record<
  | "anikoto"
  | "reanime"
  | "aniwaves"
  | "anipm"
  | "anizone"
  | "xanime"
  | "animegg"
  | "animotvslash"
  | "xmark"
  | "kaa"
  | "atv",
  { host: string; engine: string; cls: string }
> = {
  anipm: {
    host: "ani.pm",
    engine: "Settlar HLS",
    cls: "border-signal-500/40 text-signal-400",
  },
  reanime: {
    host: "reanime.to",
    engine: "FlixCloud WASM + _v7 XOR",
    cls: "border-ember-500/50 text-ember-300",
  },
  anizone: {
    host: "anizone.to",
    engine: "Seiryuu Vid-CDN (1080p)",
    cls: "border-flare-400/40 text-flare-400",
  },
  xanime: {
    host: "xanime.me",
    engine: "Qwik State / XaniVSrc HLS",
    cls: "border-signal-500/40 text-signal-400",
  },
  anikoto: {
    host: "anikototv.to",
    engine: "MegaPlay AES-256",
    cls: "border-signal-500/40 text-signal-400",
  },
  aniwaves: {
    host: "aniwaves.ru",
    engine: "EchoVideo / VhsCDN",
    cls: "border-flare-400/40 text-flare-400",
  },
  animegg: {
    host: "animegg.org",
    engine: "Vidcache (360p-1080p)",
    cls: "border-ember-500/50 text-ember-300",
  },
  animotvslash: {
    host: "animotvslash.org",
    engine: "Real mirrors / stream API",
    cls: "border-flare-400/40 text-flare-400",
  },
  xmark: {
    host: "xmark (watermark-free source)",
    engine: "No-watermark HLS",
    cls: "border-signal-500/40 text-signal-400",
  },
  kaa: {
    host: "kaa.lt",
    engine: "Krussdomi HLS + multi-audio",
    cls: "border-ember-500/50 text-ember-300",
  },
  atv: {
    host: "animetvplus.xyz",
    engine: "uqload HLS via embed resolve",
    cls: "border-flare-400/40 text-flare-400",
  },
};

const EXAMPLES = [
  { id: 21, label: "One Piece" },
  { id: 154587, label: "Frieren" },
  { id: 151807, label: "Solo Leveling" },
  { id: 21459, label: "My Hero Academia" },
  { id: 113415, label: "Jujutsu Kaisen" },
  { id: 127230, label: "Chainsaw Man" },
];

const STEPS = ["anilist", "map / lookup", "episode", "servers", "decrypt / seal ctx"];

const METHOD_STYLE: Record<string, { label: string; cls: string; note: string }> = {
  "mal-verified": {
    label: "MAL verified",
    cls: "border-signal-500/50 text-signal-400",
    note: "site episode list carries the same MAL id",
  },
  "mal-cache": {
    label: "MAL verified · cached",
    cls: "border-signal-500/50 text-signal-400",
    note: "previously indexed with the same MAL id",
  },
  "anilist-id": {
    label: "AniList ID direct",
    cls: "border-signal-500/50 text-signal-400",
    note: "resolved directly by AniList ID via reanime.to /api/flix",
  },
  "title+year": {
    label: "title + year verified",
    cls: "border-signal-500/50 text-signal-400",
    note: "matched on title/native aliases and aired year via tooltip",
  },
  "title-match": {
    label: "title match",
    cls: "border-ember-500/50 text-ember-300",
    note: "matched on fuzzy title similarity",
  },
  cached: {
    label: "cached",
    cls: "border-signal-500/50 text-signal-400",
    note: "served from local Postgres cache",
  },
};

function slugify(value: string) {
  return value.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 48) || "episode";
}

export function AnilistResolver({
  initialId,
  initialEpisode,
  initialType,
  initialProvider,
  autoRun = false,
}: {
  initialId?: string;
  initialEpisode?: string;
  initialType?: AudioType;
  initialProvider?: ProviderChoice;
  autoRun?: boolean;
}) {
  const [anilistId, setAnilistId] = useState(initialId ?? "");
  const [episode, setEpisode] = useState(initialEpisode ?? "1");
  const [type, setType] = useState<AudioType>(initialType ?? "sub");
  const [provider, setProvider] = useState<ProviderChoice>(initialProvider ?? "anikoto");
  const [strategy, setStrategy] = useState<Strategy>("auto");
  const [force, setForce] = useState(false);
  const [busy, setBusy] = useState(false);
  const [step, setStep] = useState(0);
  const [elapsed, setElapsed] = useState(0);
  const [data, setData] = useState<StreamData | null>(null);
  const [error, setError] = useState<{ message: string; attempts: Attempt[] } | null>(null);
  const autoRan = useRef(false);
  const resultRef = useRef<HTMLDivElement>(null);

  const run = useCallback(
    async (override?: {
      id?: string;
      ep?: string;
      type?: AudioType;
      provider?: ProviderChoice;
    }) => {
      const id = (override?.id ?? anilistId).trim();
      const ep = (override?.ep ?? episode).trim();
      const audio = override?.type ?? type;
      const srcProvider = override?.provider ?? provider;

      if (!/^\d+$/.test(id) || Number(id) <= 0) {
        setError({ message: "Enter a numeric AniList id — e.g. 21 for One Piece.", attempts: [] });
        return;
      }
      if (!/^\d+$/.test(ep) || Number(ep) <= 0) {
        setError({ message: "Episode must be a positive whole number.", attempts: [] });
        return;
      }

      setBusy(true);
      setError(null);
      setStep(0);
      const started = performance.now();
      const ticker = setInterval(() => {
        const ms = performance.now() - started;
        setElapsed(Math.round(ms));
        setStep(Math.min(STEPS.length - 1, Math.floor(ms / 450)));
      }, 90);

      try {
        const qs = new URLSearchParams({ type: audio, provider: srcProvider });
        if (strategy !== "auto" && (srcProvider === "anikoto" || srcProvider === "auto")) {
          qs.set("strategy", strategy);
        }
        if (force) qs.set("force", "1");
        const res = await fetch(`/api/stream/${id}/${ep}?${qs.toString()}`);
        const json = (await res.json()) as ApiResponse;

        if (!json.ok || !json.data) {
          setData(null);
          setError({
            message: json.error ?? `request failed with HTTP ${res.status}`,
            attempts: Array.isArray(json.details) ? (json.details as Attempt[]) : [],
          });
        } else {
          setData(json.data);
          window.history.replaceState(
            null,
            "",
            `/?anilist=${id}&ep=${ep}&type=${audio}&provider=${srcProvider}`,
          );
          requestAnimationFrame(() =>
            resultRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }),
          );
        }
      } catch (err) {
        setError({ message: err instanceof Error ? err.message : String(err), attempts: [] });
      } finally {
        clearInterval(ticker);
        setElapsed(Math.round(performance.now() - started));
        setBusy(false);
      }
    },
    [anilistId, episode, type, provider, strategy, force],
  );

  useEffect(() => {
    if (autoRun && initialId && !autoRan.current) {
      autoRan.current = true;
      void run();
    }
  }, [autoRun, initialId, run]);

  const shiftEpisode = (delta: number, execute: boolean) => {
    const next = String(Math.max(1, (Number(episode) || 1) + delta));
    setEpisode(next);
    if (execute) void run({ ep: next });
  };

  const activeHostLabel =
    PROVIDERS.find((p) => p.id === provider)?.label ?? "anikototv.to";

  return (
    <div className="flex flex-col gap-5">
      <form
        onSubmit={(e) => {
          e.preventDefault();
          void run();
        }}
        className="panel overflow-hidden"
      >
        <div className="flex flex-wrap items-center gap-2 border-b border-ink-700 bg-ink-850/60 px-3 py-2">
          <span className="font-mono text-[10px] tracking-[0.18em] text-mist-500 uppercase">
            anilist → {activeHostLabel} → /proxy/hls (master.m3u8)
          </span>
          <span className="ml-auto font-mono text-[10px] text-mist-500 tabular-nums">
            {busy ? (
              <span className="text-ember-400">{elapsed}ms</span>
            ) : data ? (
              <span className="text-signal-400">
                {data.tookMs}ms server{data.cached ? " · cached" : ""}
              </span>
            ) : null}
          </span>
        </div>

        {/* Scraper / Provider Selector */}
        <div className="flex flex-wrap items-center gap-2 border-b border-ink-800 bg-ink-900/50 px-3 py-2.5">
          <span className="label mr-1">scraper</span>
          <div className="flex flex-wrap gap-1.5" role="radiogroup" aria-label="Stream scraper provider">
            {PROVIDERS.map((p) => {
              const active = provider === p.id;
              return (
                <button
                  key={p.id}
                  type="button"
                  disabled={busy}
                  onClick={() => {
                    setProvider(p.id);
                    if (anilistId.trim() && data) {
                      void run({ provider: p.id });
                    }
                  }}
                  className={[
                    "flex items-center gap-2 rounded-[3px] border px-3 py-1.5 font-mono text-[11px] tracking-[0.06em] transition-colors disabled:opacity-50",
                    active
                      ? "border-ember-500 bg-ember-500/15 text-ember-300 font-semibold"
                      : "border-ink-600 bg-ink-850 text-mist-300 hover:border-ink-500 hover:text-mist-100",
                  ].join(" ")}
                >
                  <span>{p.label}</span>
                  <span
                    className={[
                      "rounded px-1.5 py-0.5 text-[9px] uppercase",
                      active ? "bg-ember-500/25 text-ember-200" : "bg-ink-900 text-mist-500",
                    ].join(" ")}
                  >
                    {p.badge}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-1.5 border-b border-ink-800 bg-ink-900/30 px-3 py-2">
          <span className="label mr-1">more sites</span>
          {EXTRA_SITES.map((site) => {
            const active = provider === site.id;
            const badge = site.mode;
            return (
              <button
                key={site.id}
                type="button"
                disabled={busy}
                title={`${site.label}: ${site.reason}`}
                onClick={() => {
                  setProvider(site.id as ProviderChoice);
                  if (anilistId.trim() && data) void run({ provider: site.id as ProviderChoice });
                }}
                className={[
                  "rounded-[3px] border px-2 py-1 font-mono text-[10px] tracking-[0.05em] transition-colors disabled:opacity-40",
                  active
                    ? "border-ember-500 bg-ember-500/15 text-ember-300"
                    : site.mode === "blocked"
                      ? "border-ink-700 bg-ink-900 text-alert-400/70 hover:border-alert-500/50 hover:text-alert-400"
                      : site.mode === "manga"
                        ? "border-ink-700 bg-ink-900 text-mist-500"
                        : "border-ink-600 bg-ink-850 text-mist-300 hover:border-ink-500 hover:text-mist-100",
                ].join(" ")}
              >
                {site.label}
                <span className="ml-1 text-mist-500">·{badge}</span>
              </button>
            );
          })}
        </div>

        <div className="grid gap-3 p-3 md:grid-cols-[minmax(0,1.3fr)_minmax(0,1fr)_auto_auto] md:items-end">
          <label className="flex flex-col gap-1.5">
            <span className="label">AniList id</span>
            <input
              value={anilistId}
              onChange={(e) => setAnilistId(e.target.value.replace(/[^\d]/g, ""))}
              inputMode="numeric"
              placeholder="e.g. 21"
              className="input !py-2.5 !text-lg !tracking-wide"
              aria-label="AniList id"
              autoFocus={!initialId}
            />
          </label>

          <div className="flex flex-col gap-1.5">
            <span className="label">episode</span>
            <div className="flex">
              <button
                type="button"
                onClick={() => shiftEpisode(-1, false)}
                className="border border-r-0 border-ink-600 bg-ink-850 px-3 font-mono text-mist-300 hover:text-ember-300"
                aria-label="Previous episode"
              >
                −
              </button>
              <input
                value={episode}
                onChange={(e) => setEpisode(e.target.value.replace(/[^\d]/g, ""))}
                inputMode="numeric"
                className="input !rounded-none !py-2.5 text-center !text-lg"
                aria-label="Episode number"
              />
              <button
                type="button"
                onClick={() => shiftEpisode(1, false)}
                className="border border-l-0 border-ink-600 bg-ink-850 px-3 font-mono text-mist-300 hover:text-ember-300"
                aria-label="Next episode"
              >
                +
              </button>
            </div>
          </div>

          <div className="flex flex-col gap-1.5">
            <span className="label">audio</span>
            <div className="flex h-[46px] overflow-hidden rounded-[3px] border border-ink-600">
              {(["sub", "dub"] as const).map((t) => (
                <button
                  key={t}
                  type="button"
                  onClick={() => setType(t)}
                  className={[
                    "px-4 font-mono text-[12px] tracking-[0.14em] uppercase transition-colors",
                    type === t ? "bg-ember-500 text-ink-950" : "bg-ink-850 text-mist-400 hover:text-mist-100",
                  ].join(" ")}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>

          <button type="submit" className="btn btn-primary h-[46px] !px-6 !text-[13px]" disabled={busy}>
            {busy ? "resolving…" : "get stream →"}
          </button>
        </div>

        <div className="flex flex-wrap items-center gap-2 border-t border-ink-700 bg-ink-900/60 px-3 py-2.5">
          <span className="label mr-1">try</span>
          {EXAMPLES.map((ex) => (
            <button
              key={ex.id}
              type="button"
              disabled={busy}
              onClick={() => {
                setAnilistId(String(ex.id));
                setEpisode("1");
                void run({ id: String(ex.id), ep: "1" });
              }}
              className="chip transition-colors hover:border-ember-500/60 hover:text-ember-300 disabled:opacity-50"
            >
              {ex.label}
              <span className="text-mist-500">{ex.id}</span>
            </button>
          ))}

          <div className="ml-auto flex flex-wrap items-center gap-3">
            {(provider === "anikoto" || provider === "auto") && (
              <label className="flex items-center gap-1.5">
                <span className="label">path</span>
                <select
                  value={strategy}
                  onChange={(e) => setStrategy(e.target.value as Strategy)}
                  className="rounded-[3px] border border-ink-600 bg-ink-850 px-2 py-1 font-mono text-[11px] text-mist-200 outline-none focus:border-ember-500"
                >
                  <option value="auto">auto</option>
                  <option value="site">site only</option>
                  <option value="direct">direct only</option>
                </select>
              </label>
            )}
            <label className="flex cursor-pointer items-center gap-1.5 font-mono text-[10.5px] text-mist-400">
              <input
                type="checkbox"
                checked={force}
                onChange={(e) => setForce(e.target.checked)}
                className="accent-[#ff6b35]"
              />
              bypass cache
            </label>
          </div>
        </div>

        {busy && (
          <div className="flex flex-wrap items-center gap-x-4 gap-y-2 border-t border-ink-700 px-3 py-2.5">
            {STEPS.map((label, i) => (
              <span key={label} className="flex items-center gap-1.5 font-mono text-[10px] tracking-[0.1em] uppercase">
                <span
                  className={[
                    "size-1.5 rounded-full",
                    i === step ? "pulse-dot bg-ember-500" : i < step ? "bg-signal-500" : "bg-ink-600",
                  ].join(" ")}
                />
                <span className={i === step ? "text-ember-300" : i < step ? "text-mist-300" : "text-mist-500"}>
                  {label}
                </span>
              </span>
            ))}
          </div>
        )}
      </form>

      {error && (
        <div className="panel rise-in border-alert-500/50 p-4">
          <p className="label text-alert-400">no stream</p>
          <p className="mt-1.5 font-mono text-[12.5px] leading-relaxed text-alert-400">{error.message}</p>
          {error.attempts.length > 0 && <AttemptList attempts={error.attempts} />}
        </div>
      )}

      <div ref={resultRef} className="scroll-mt-20">
        {data && <StreamResult data={data} busy={busy} onEpisode={(d) => shiftEpisode(d, true)} />}
      </div>
    </div>
  );
}

function AttemptList({ attempts }: { attempts: Attempt[] }) {
  return (
    <ol className="mt-3 flex flex-col gap-1.5">
      {attempts.map((a, i) => (
        <li key={`${a.step}-${i}`} className="flex items-start gap-2 font-mono text-[11px]">
          <span className={a.ok ? "text-signal-400" : "text-alert-400"}>{a.ok ? "✓" : "✗"}</span>
          <span className="w-16 shrink-0 text-mist-400 uppercase">{a.step}</span>
          <span className="min-w-0 break-words text-mist-500">{a.detail}</span>
        </li>
      ))}
    </ol>
  );
}

function OutputRow({ label, value, hint, tone }: { label: string; value: string; hint: string; tone: string }) {
  return (
    <div className="flex flex-col gap-1.5 border-b border-ink-800 px-4 py-3 last:border-b-0 md:flex-row md:items-center md:gap-4">
      <div className="w-36 shrink-0">
        <p className="label">{label}</p>
        <p className="mt-0.5 text-[11px] leading-snug text-mist-500">{hint}</p>
      </div>
      <code
        className={`min-w-0 flex-1 truncate rounded-[3px] border border-ink-700 bg-ink-950 px-2.5 py-2 font-mono text-[11.5px] ${tone}`}
        title={value}
      >
        {value}
      </code>
      <div className="flex shrink-0 gap-1.5">
        <CopyButton value={value} label="copy" />
        <a href={value} target="_blank" rel="noreferrer noopener" className="btn">
          open
        </a>
      </div>
    </div>
  );
}

function StreamResult({
  data,
  busy,
  onEpisode,
}: {
  data: StreamData;
  busy: boolean;
  onEpisode: (delta: number) => void;
}) {
  const [tab, setTab] = useState<"mpv" | "ffmpeg" | "curl">("mpv");
  const title = data.anilist?.title ?? data.match?.title ?? `AniList ${data.anilistId}`;
  const file = `${slugify(title)}-ep${data.episode}-${data.provider}-${data.type}.mp4`;
  const requiresProxy = Boolean(data.stream.manifestKey);
  const proxyOrDirect = requiresProxy ? data.links.playlist : data.stream.m3u8;
  const commands = {
    mpv: `mpv "${data.links.playlist}"`,
    ffmpeg: requiresProxy
      ? `ffmpeg -i "${data.links.playlist}" -c copy "${file}"`
      : `ffmpeg -referer "${data.stream.referer}" -user_agent "${data.stream.headers["User-Agent"]}" \\\n  -i "${proxyOrDirect}" -c copy "${file}"`,
    curl: `curl -s "${data.links.json}"`,
  } as const;
  const method = data.match ? METHOD_STYLE[data.match.method] : null;
  const providerMeta = PROVIDER_DISPLAY[data.provider] ?? PROVIDER_DISPLAY.anikoto;
  const total = data.anilist?.episodes ?? null;

  return (
    <div className="rise-in flex flex-col gap-4">
      {/* ── the stream ─────────────────────────────────────────────────── */}
      <section className="panel overflow-hidden">
        <div className="panel-header flex-wrap">
          <div className="flex min-w-0 flex-wrap items-center gap-2">
            <span className="pulse-dot size-2 rounded-full bg-signal-500" />
            <span className="truncate font-display text-[15px] font-bold text-mist-50">
              {title} · Episode {data.episode}
            </span>
            <span className="chip uppercase">{data.type}</span>
            {data.stream.server && <span className="chip">{data.stream.server.name}</span>}
            <span className={`chip uppercase ${providerMeta.cls}`}>
              via {data.strategy === "direct" ? "direct megaplay" : providerMeta.host} · {providerMeta.engine}
            </span>
            {data.cached && <span className="chip">cached</span>}
          </div>
          <div className="flex gap-1.5">
            <button
              type="button"
              className="btn !py-1.5"
              disabled={busy || data.episode <= 1}
              onClick={() => onEpisode(-1)}
            >
              ← ep {data.episode - 1 || "–"}
            </button>
            <button
              type="button"
              className="btn !py-1.5"
              disabled={busy || (total !== null && data.anilist?.status === "FINISHED" && data.episode >= total)}
              onClick={() => onEpisode(1)}
            >
              ep {data.episode + 1} →
            </button>
          </div>
        </div>

        {data.typeFallback && (
          <div className="border-b border-ember-500/40 bg-ember-500/8 px-4 py-2 font-mono text-[11px] text-ember-300">
            no {data.requestedType} track exists for this episode — serving {data.type} instead
          </div>
        )}

        <OutputRow
          label="/proxy/hls"
          value={data.links.proxy}
          hint="Stateless sealed-context HLS proxy (?url=&exp=&sig=&ref=&ctx=c1…&purpose=playback)."
          tone="text-signal-400"
        />
        <OutputRow
          label="probe url"
          value={data.links.probe}
          hint="Same signed /proxy/hls URL with &purpose=probe for manifest verification."
          tone="text-flare-400"
        />
        <OutputRow
          label="playlist .m3u8"
          value={data.links.playlist}
          hint="Self-contained .m3u8 — paste straight into VLC, mpv, IINA. No headers needed."
          tone="text-mist-100"
        />
        <OutputRow
          label="upstream m3u8"
          value={data.stream.m3u8}
          hint={
            requiresProxy
              ? `FlixCloud _v7 XOR-encrypted & IP-bound manifest (decoded on the fly by /proxy/hls).`
              : `Upstream CDN. Needs Referer: ${data.stream.referer}`
          }
          tone="text-ember-300"
        />
        <OutputRow label="json" value={data.links.json} hint="This exact lookup as an API call." tone="text-mist-300" />

        <div className="border-t border-ink-700">
          <div className="flex items-center gap-1 border-b border-ink-800 px-4 pt-2.5">
            {(["mpv", "ffmpeg", "curl"] as const).map((t) => (
              <button
                key={t}
                type="button"
                onClick={() => setTab(t)}
                className={[
                  "border-b-2 px-3 pb-2 font-mono text-[10.5px] tracking-[0.14em] uppercase transition-colors",
                  tab === t ? "border-ember-500 text-ember-300" : "border-transparent text-mist-500 hover:text-mist-200",
                ].join(" ")}
              >
                {t === "ffmpeg" ? "ffmpeg · download" : t}
              </button>
            ))}
            <div className="ml-auto pb-2">
              <CopyButton value={commands[tab]} label="copy command" />
            </div>
          </div>
          <pre className="overflow-x-auto bg-ink-950 px-4 py-3 font-mono text-[11.5px] leading-relaxed text-mist-200">
            {commands[tab]}
          </pre>
        </div>

        {data.stream.subtitles.length > 0 && (
          <div className="flex flex-wrap items-center gap-1.5 border-t border-ink-700 px-4 py-3">
            <span className="label mr-1">subtitles</span>
            {data.stream.subtitles.map((s) => (
              <a
                key={s.file}
                href={s.proxied}
                target="_blank"
                rel="noreferrer noopener"
                className="chip transition-colors hover:border-ember-500/60 hover:text-ember-300"
                title={s.file}
              >
                {s.label ?? "untitled"}
                {s.default && <span className="text-signal-400">default</span>}
                <span className="text-mist-500">
                  {s.format && s.format !== "vtt" ? `.${s.format}→vtt` : ".vtt"}
                </span>
              </a>
            ))}
          </div>
        )}
      </section>

      {/* ── player + provenance ───────────────────────────────────────── */}
      <div className="grid gap-4 xl:grid-cols-12">
        <div className="xl:col-span-8">
          <Player
            key={`${data.provider}-${data.stream.m3u8}-${data.type}`}
            proxiedUrl={data.stream.proxied}
            directUrl={data.stream.m3u8}
            requiresProxy={requiresProxy}
            posterUrl={data.stream.poster}
            tracks={data.stream.subtitles.map((s) => ({
              file: s.file,
              proxied: s.proxied,
              label: s.label ?? undefined,
              kind: "captions",
              default: s.default,
            }))}
            intro={data.stream.intro}
            outro={data.stream.outro}
            title={data.match?.episodeTitle ?? `${title} — Episode ${data.episode}`}
            meta={`${title} · ep ${data.episode} · ${data.type} · ${providerMeta.host}`}
            serverName={data.stream.server?.name}
          />
        </div>

        <aside className="flex flex-col gap-4 xl:col-span-4">
          {data.anilist && (
            <div className="panel overflow-hidden">
              <div
                className="relative h-20 bg-ink-850 bg-cover bg-center"
                style={{
                  backgroundImage: data.anilist.banner ? `url(${data.anilist.banner})` : undefined,
                  backgroundColor: data.anilist.color ?? undefined,
                }}
              >
                <div className="absolute inset-0 bg-gradient-to-b from-transparent to-ink-900" />
              </div>
              <div className="-mt-10 flex gap-3 px-3 pb-3">
                {data.anilist.cover && (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img
                    src={data.anilist.cover}
                    alt={data.anilist.title}
                    referrerPolicy="no-referrer"
                    className="relative h-28 w-20 shrink-0 border border-ink-600 object-cover"
                  />
                )}
                <div className="relative min-w-0 pt-11">
                  <p className="label">AniList #{data.anilist.id}</p>
                  <a
                    href={data.anilist.url}
                    target="_blank"
                    rel="noreferrer noopener"
                    className="mt-0.5 line-clamp-2 font-display text-[14px] leading-snug font-bold text-mist-50 hover:text-ember-300"
                  >
                    {data.anilist.title}
                  </a>
                  {data.anilist.romaji && data.anilist.romaji !== data.anilist.title && (
                    <p className="truncate text-[11px] text-mist-500">{data.anilist.romaji}</p>
                  )}
                </div>
              </div>
              <dl className="grid grid-cols-2 gap-x-3 gap-y-1 border-t border-ink-800 px-3 py-2.5 font-mono text-[10.5px]">
                <dt className="text-mist-500">format</dt>
                <dd className="text-mist-200">{data.anilist.format ?? "—"}</dd>
                <dt className="text-mist-500">episodes</dt>
                <dd className="text-mist-200">{data.anilist.episodes ?? "airing"}</dd>
                <dt className="text-mist-500">season</dt>
                <dd className="text-mist-200 capitalize">
                  {[data.anilist.season?.toLowerCase(), data.anilist.seasonYear].filter(Boolean).join(" ") || "—"}
                </dd>
                <dt className="text-mist-500">MAL id</dt>
                <dd className="text-mist-200">{data.anilist.idMal ?? "—"}</dd>
                <dt className="text-mist-500">score</dt>
                <dd className="text-mist-200">{data.anilist.averageScore ? `${data.anilist.averageScore}%` : "—"}</dd>
              </dl>
            </div>
          )}

          <div className="panel">
            <div className="panel-header">
              <span className="label">{providerMeta.host} match</span>
              {method && <span className={`chip ${method.cls}`}>{method.label}</span>}
            </div>
            {data.match ? (
              <div className="flex flex-col gap-2 px-3 py-3">
                {data.provider === "anikoto" ? (
                  <Link
                    href={`/anime/${data.match.slug}`}
                    className="font-display text-[14px] leading-snug font-bold text-mist-100 hover:text-ember-300"
                  >
                    {data.match.title}
                  </Link>
                ) : (
                  <a
                    href={data.match.siteUrl}
                    target="_blank"
                    rel="noreferrer noopener"
                    className="font-display text-[14px] leading-snug font-bold text-mist-100 hover:text-ember-300"
                  >
                    {data.match.title}
                  </a>
                )}
                <p className="font-mono text-[10.5px] text-mist-500">
                  site id {data.match.animeId} · MAL {data.match.malId ?? "—"} · confidence{" "}
                  {Math.round(data.match.confidence * 100)}%
                </p>
                {method && <p className="text-[11.5px] text-mist-500">{method.note}</p>}
                <p className="font-mono text-[10.5px] text-mist-400">
                  episode {data.match.episodeId} · {data.match.availableEpisodes} on site (
                  {data.match.firstEpisode}–{data.match.lastEpisode})
                </p>
                <div className="mt-1 flex flex-wrap gap-1.5">
                  {data.provider === "anikoto" && (
                    <Link
                      href={`/watch/${data.match.slug}/${data.match.episodeId}`}
                      className="btn !py-1.5 !text-[10px]"
                    >
                      server picker
                    </Link>
                  )}
                  <a
                    href={
                      data.provider === "reanime"
                        ? `${data.match.siteUrl}?ep=${data.episode}`
                        : data.provider === "anikoto" || data.provider === "aniwaves"
                          ? `${data.match.siteUrl}/ep-${data.episode}`
                          : data.match.siteUrl
                    }
                    target="_blank"
                    rel="noreferrer noopener"
                    className="btn !py-1.5 !text-[10px]"
                  >
                    open on {providerMeta.host} ↗
                  </a>
                </div>
              </div>
            ) : (
              <p className="px-3 py-3 text-[12px] leading-relaxed text-mist-500">
                Served by looking the episode up on the embed player by AniList id — the title could not be
                matched in the site catalogue.
              </p>
            )}
          </div>

          <div className="panel">
            <div className="panel-header">
              <span className="label">resolution trace</span>
              <span className="font-mono text-[10px] text-mist-500">{data.tookMs}ms</span>
            </div>
            <div className="px-3 pb-3">
              <AttemptList attempts={data.attempts} />
              {(data.stream.intro?.start != null || data.stream.outro?.start != null) && (
                <p className="mt-3 font-mono text-[10.5px] text-mist-500">
                  intro {data.stream.intro?.start ?? "–"}–{data.stream.intro?.end ?? "–"}s · outro{" "}
                  {data.stream.outro?.start ?? "–"}–{data.stream.outro?.end ?? "–"}s
                </p>
              )}
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}

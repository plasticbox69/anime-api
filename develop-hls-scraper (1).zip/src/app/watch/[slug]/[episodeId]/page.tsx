import Link from "next/link";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { episodes as episodesTable } from "@/db/schema";
import { getAnime } from "@/lib/scraper";
import { WatchPanel } from "@/components/WatchPanel";

export const dynamic = "force-dynamic";

export default async function WatchPage({
  params,
}: {
  params: Promise<{ slug: string; episodeId: string }>;
}) {
  const { slug, episodeId } = await params;
  const cleanSlug = decodeURIComponent(slug);

  let animeTitle = cleanSlug;
  let episodeNumber = episodeId;
  let episodeTitle: string | null = null;
  let notFound = false;

  // The episode table is the source of truth for the server payload the site
  // needs, so make sure the title is indexed before handing over to the client.
  try {
    const rows = await db
      .select()
      .from(episodesTable)
      .where(eq(episodesTable.id, episodeId))
      .limit(1);

    let row = rows[0];
    if (!row) {
      const outcome = await getAnime(cleanSlug);
      const refreshed = await db
        .select()
        .from(episodesTable)
        .where(eq(episodesTable.id, episodeId))
        .limit(1);
      row = refreshed[0];
      animeTitle = outcome.detail.title;
    }

    if (!row) {
      notFound = true;
    } else {
      animeTitle = row.animeId ? animeTitle : cleanSlug;
      episodeNumber = row.number;
      episodeTitle = row.title;
      const detail = await getAnime(cleanSlug);
      animeTitle = detail.detail.title;
    }
  } catch {
    // Fall through: the client panel will surface the real error.
  }

  if (notFound) {
    return (
      <div className="mx-auto w-full max-w-[1400px] px-5 py-16">
        <div className="panel mx-auto max-w-xl p-8 text-center">
          <p className="label">unknown episode</p>
          <h1 className="mt-3 font-display text-2xl font-bold text-mist-50">
            episode {episodeId} is not indexed
          </h1>
          <p className="mt-3 font-mono text-[11.5px] text-mist-400">
            Open the title first so its episode table can be scraped.
          </p>
          <div className="mt-6 flex justify-center gap-2">
            <Link href={`/anime/${cleanSlug}`} className="btn btn-primary">
              index {cleanSlug}
            </Link>
            <Link href="/" className="btn">
              ← console
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto w-full max-w-[1400px] px-5 py-7">
      <WatchPanel
        episodeId={episodeId}
        animeSlug={cleanSlug}
        animeTitle={animeTitle}
        episodeNumber={episodeNumber}
        episodeTitle={episodeTitle}
      />
    </div>
  );
}

import Link from "next/link";
import { desc, ne } from "drizzle-orm";
import { db } from "@/db";
import { anilistMappings, scrapeJobs, sources } from "@/db/schema";
import { AnilistResolver } from "@/components/AnilistResolver";
import { BulkScrape } from "@/components/BulkScrape";
import { ConsoleSearch } from "@/components/ConsoleSearch";
import { AnimeCard } from "@/components/AnimeCard";
import { CopyButton } from "@/components/CopyButton";
import { getStats, getTrending } from "@/lib/scraper";
import { hostOf, timeAgo, truncate } from "@/lib/format";
import type { AnimeListItem } from "@/lib/types";

export const dynamic = "force-dynamic";

const CHAIN = [
  {
    step: "01",
    method: "GQL",
    endpoint: "graphql.anilist.co · Media(id)",
    note: "MAL id + title aliases + year (cached 24h)",
  },
  {
    step: "02",
    method: "API",
    endpoint: "ani.pm · /api/anime/playback-bootstrap → settlar session",
    note: "native REST API → media.settlar.io HLS directly",
  },
  {
    step: "03",
    method: "WASM",
    endpoint: "reanime.to · FlixCloud WASM + PBKDF2 + _v7 XOR",
    note: "/api/flix/{id}/{ep} → inline WASM + AES-256-CBC + __pk XOR key",
  },
  {
    step: "04",
    method: "HTML",
    endpoint: "anizone.to · Alpine x-data JSON · seiryuu vid-cdn 1080p",
    note: "search?search= → /anime/{slug} → /anime/{slug}/{ep}",
  },
  {
    step: "05",
    method: "QWIK",
    endpoint: "xanime.me · /search?q= → /title/{id}/{epId} → qwik/json",
    note: "episode m3u8 embedded in Qwik state on watch page",
  },
  {
    step: "06",
    method: "AJAX",
    endpoint: "anikototv.to / aniwaves.ru · MegaPlay / EchoVideo",
    note: "filter → episode list → server list → decrypt sources",
  },
  {
    step: "07",
    method: "HTML",
    endpoint: "animegg.org / animotvslash.org · Vidcache / Multi-mirror",
    note: "search/auto → series → episode → embed → videoSources",
  },
  {
    step: "08",
    method: "SEAL",
    endpoint: "/proxy/hls?url=&exp=&sig=&ref=&ctx=c1…&purpose=",
    note: "AES-256-GCM sealed ctx + HMAC-SHA256 sig + on-the-fly _v7 XOR & ASS→VTT",
  },
];

async function loadHome() {
  const [trending, stats, jobs, playlists, lookups] = await Promise.allSettled([
    getTrending(),
    getStats(),
    db.select().from(scrapeJobs).orderBy(desc(scrapeJobs.id)).limit(10),
    db.select().from(sources).orderBy(desc(sources.resolvedAt)).limit(8),
    db
      .select()
      .from(anilistMappings)
      .where(ne(anilistMappings.method, "unmatched"))
      .orderBy(desc(anilistMappings.updatedAt))
      .limit(8),
  ]);

  return {
    trending: trending.status === "fulfilled" ? trending.value : ([] as AnimeListItem[]),
    trendingError: trending.status === "rejected" ? String(trending.reason?.message ?? trending.reason) : null,
    stats:
      stats.status === "fulfilled"
        ? stats.value
        : { animes: 0, episodes: 0, sources: 0, resolvedSources: 0, jobs: 0, avgJobMs: 0, mappings: 0 },
    jobs: jobs.status === "fulfilled" ? jobs.value : [],
    playlists: playlists.status === "fulfilled" ? playlists.value : [],
    lookups: lookups.status === "fulfilled" ? lookups.value : [],
  };
}

export default async function HomePage({
  searchParams,
}: {
  searchParams: Promise<{ anilist?: string; ep?: string; type?: string; provider?: string }>;
}) {
  const sp = await searchParams;
  const initialId = sp.anilist && /^\d+$/.test(sp.anilist) ? sp.anilist : undefined;
  const initialEpisode = sp.ep && /^\d+$/.test(sp.ep) ? sp.ep : undefined;
  const initialType = sp.type === "dub" ? "dub" : "sub";
  const initialProvider =
    sp.provider === "reanime" ||
    sp.provider === "aniwaves" ||
    sp.provider === "auto" ||
    sp.provider === "anikoto"
      ? sp.provider
      : undefined;

  const { trending, trendingError, stats, jobs, playlists, lookups } = await loadHome();

  const counters = [
    { label: "anilist mapped", value: stats.mappings },
    { label: "titles indexed", value: stats.animes },
    { label: "playlists resolved", value: stats.resolvedSources },
    { label: "scrape jobs", value: stats.jobs },
  ];

  return (
    <div className="mx-auto w-full max-w-[1400px] px-5 py-8">
      {/* ── resolver ─────────────────────────────────────────────────── */}
      <section>
        <p className="label flex items-center gap-2">
          <span className="pulse-dot size-1.5 rounded-full bg-ember-500" />
          targets · 8 scrapers · /proxy/hls relay
        </p>
        <div className="mt-3 flex flex-wrap items-end justify-between gap-x-10 gap-y-3">
          <h1 className="font-display text-[clamp(2rem,5vw,3.4rem)] leading-[0.98] font-extrabold tracking-[-0.02em] text-mist-50 text-balance-tight">
            AniList id + episode
            <span className="text-ember-500"> → stream.</span>
          </h1>
          <p className="max-w-md pb-1 text-[14px] leading-relaxed text-mist-400">
            Pick a scraper — anikototv.to, reanime.to, aniwaves.ru, or auto failover — enter an
            AniList id and episode, and get a decrypted HLS stream served through the sealed
            /proxy/hls relay.
          </p>
        </div>

        <div className="mt-6">
          <AnilistResolver
            initialId={initialId}
            initialEpisode={initialEpisode}
            initialType={initialType}
            initialProvider={initialProvider}
            autoRun={Boolean(initialId)}
          />
        </div>
      </section>

      {/* ── how + cache + recent ─────────────────────────────────────── */}
      <section className="mt-12 grid gap-6 lg:grid-cols-12">
        <div className="panel lg:col-span-5">
          <div className="panel-header">
            <span className="label">resolution chain</span>
            <span className="font-mono text-[10px] text-mist-500">verified live</span>
          </div>
          <ol className="divide-y divide-ink-800">
            {CHAIN.map((c) => (
              <li key={c.step} className="flex gap-3 px-3 py-2.5">
                <span className="mt-0.5 font-mono text-[10px] text-ember-500">{c.step}</span>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span
                      className={[
                        "w-11 shrink-0 border px-1 py-px text-center font-mono text-[9px] tracking-[0.1em]",
                        c.method === "AES"
                          ? "border-ember-500/50 bg-ember-500/10 text-ember-300"
                          : c.method === "ALT"
                            ? "border-flare-400/40 text-flare-400"
                            : c.method === "GQL"
                              ? "border-signal-500/40 text-signal-400"
                              : "border-ink-600 bg-ink-850 text-mist-400",
                      ].join(" ")}
                    >
                      {c.method}
                    </span>
                    <code className="truncate font-mono text-[11px] text-mist-100">{c.endpoint}</code>
                  </div>
                  <p className="mt-1 text-[11.5px] leading-snug text-mist-500">{c.note}</p>
                </div>
              </li>
            ))}
          </ol>
        </div>

        <div className="flex flex-col gap-6 lg:col-span-7">
          <div className="panel">
            <div className="panel-header">
              <span className="label">local cache</span>
              <Link href="/library" className="font-mono text-[10.5px] text-ember-400 hover:text-ember-300">
                open library →
              </Link>
            </div>
            <dl className="grid grid-cols-2 sm:grid-cols-4">
              {counters.map((c, i) => (
                <div
                  key={c.label}
                  className={["px-4 py-3.5", i < counters.length - 1 ? "sm:border-r sm:border-ink-700" : ""].join(" ")}
                >
                  <dt className="label">{c.label}</dt>
                  <dd className="mt-1 font-mono text-2xl font-semibold text-mist-50 tabular-nums">
                    {c.value.toLocaleString()}
                  </dd>
                </div>
              ))}
            </dl>
            <div className="border-t border-ink-700 px-4 py-2.5 font-mono text-[10.5px] text-mist-500">
              mean job {stats.avgJobMs} ms · {stats.episodes.toLocaleString()} episodes mapped ·{" "}
              {stats.sources - stats.resolvedSources} failed attempt(s) retained
            </div>
          </div>

          <div className="panel flex-1">
            <div className="panel-header">
              <span className="label">recent anilist lookups</span>
              <span className="font-mono text-[10px] text-mist-500">anilist_mappings</span>
            </div>
            {lookups.length === 0 ? (
              <p className="px-4 py-8 text-center font-mono text-xs text-mist-500">
                no lookups yet — try one of the examples above
              </p>
            ) : (
              <ul className="divide-y divide-ink-800">
                {lookups.map((m) => (
                  <li key={m.anilistId}>
                    <Link
                      href={`/?anilist=${m.anilistId}&ep=1`}
                      className="group flex items-center gap-3 px-3 py-2 transition-colors hover:bg-ink-850"
                    >
                      <span className="w-16 shrink-0 font-mono text-[11px] text-ember-400">{m.anilistId}</span>
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-[12.5px] text-mist-100 group-hover:text-ember-300">
                          {m.title ?? "—"}
                        </span>
                        <span className="block truncate font-mono text-[10px] text-mist-500">
                          → {m.siteTitle ?? m.slug} · site {m.animeId}
                        </span>
                      </span>
                      <span
                        className={[
                          "chip shrink-0 !text-[9.5px]",
                          m.method === "title-match" ? "text-ember-300" : "text-signal-400",
                        ].join(" ")}
                      >
                        {m.method}
                      </span>
                    </Link>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      </section>

      {/* ── bulk scrape ─────────────────────────────────────────────── */}
      <section className="mt-12">
        <div className="mb-4 flex flex-wrap items-end gap-3 border-b border-ink-700 pb-3">
          <h2 className="font-display text-xl font-bold text-mist-50">Bulk scrape</h2>
          <span className="font-mono text-[10.5px] text-mist-500">
            POST /api/bulk — id ranges or trending/popular charts → annotated /proxy/hls links
          </span>
        </div>
        <BulkScrape />
      </section>

      {/* ── browse ───────────────────────────────────────────────────── */}
      <section className="mt-12">
        <div className="mb-4 flex flex-wrap items-end gap-3 border-b border-ink-700 pb-3">
          <h2 className="font-display text-xl font-bold text-mist-50">Browse by keyword</h2>
          <span className="font-mono text-[10.5px] text-mist-500">
            don&apos;t know the AniList id? search the site directly
          </span>
        </div>
        <ConsoleSearch />
      </section>

      <section className="mt-12">
        <div className="flex flex-wrap items-end gap-3 border-b border-ink-700 pb-3">
          <h2 className="font-display text-xl font-bold text-mist-50">Trending on the source</h2>
          <span className="font-mono text-[10.5px] text-mist-500">GET /ajax/home/widget/trending</span>
          <span className="ml-auto font-mono text-[10.5px] text-mist-500">{trending.length} card(s)</span>
        </div>

        {trendingError ? (
          <div className="panel mt-4 border-alert-500/40 p-4 font-mono text-xs text-alert-400">
            {truncate(trendingError, 220)}
          </div>
        ) : trending.length === 0 ? (
          <div className="panel mt-4 p-6 text-center font-mono text-xs text-mist-500">
            the trending widget returned nothing
          </div>
        ) : (
          <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5 xl:grid-cols-6">
            {trending.slice(0, 12).map((item, i) => (
              <AnimeCard key={item.id} item={item} index={i} />
            ))}
          </div>
        )}
      </section>

      {/* ── playlists + jobs ─────────────────────────────────────────── */}
      <section className="mt-12 grid gap-6 lg:grid-cols-12">
        <div className="panel lg:col-span-7">
          <div className="panel-header">
            <span className="label">resolved playlists</span>
            <span className="font-mono text-[10px] text-mist-500">sources table</span>
          </div>
          {playlists.length === 0 ? (
            <p className="px-4 py-8 text-center font-mono text-xs text-mist-500">nothing resolved yet</p>
          ) : (
            <ul className="divide-y divide-ink-800">
              {playlists.map((row) => (
                <li key={row.id} className="flex flex-wrap items-center gap-2 px-3 py-2.5">
                  <span
                    className={[
                      "size-1.5 shrink-0 rounded-full",
                      row.status === "ok" ? "bg-signal-500" : "bg-alert-500",
                    ].join(" ")}
                  />
                  <span className="font-mono text-[10px] text-mist-500">
                    {row.anilistId ? `ani ${row.anilistId} · ` : ""}ep {row.episodeNumber ?? row.episodeId}
                  </span>
                  <span className="chip">
                    {row.provider ?? "anikoto"} · {row.audioType ?? "?"} · {row.serverName ?? "?"}
                  </span>
                  <code className="min-w-0 flex-1 truncate font-mono text-[11px]" title={row.hlsUrl ?? row.error ?? undefined}>
                    {row.hlsUrl ? (
                      <span className="text-signal-400">{truncate(row.hlsUrl, 58)}</span>
                    ) : (
                      <span className="text-alert-400">{truncate(row.error, 58)}</span>
                    )}
                  </code>
                  <span className="font-mono text-[10px] text-mist-500">{hostOf(row.embedUrl)}</span>
                  {row.hlsUrl && <CopyButton value={row.hlsUrl} label="copy" />}
                  <span className="w-full text-right font-mono text-[9.5px] text-mist-500 sm:w-auto">
                    {timeAgo(row.resolvedAt)}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </div>

        <div className="panel lg:col-span-5">
          <div className="panel-header">
            <span className="label">audit trail</span>
            <Link href="/jobs" className="font-mono text-[10.5px] text-ember-400 hover:text-ember-300">
              all jobs →
            </Link>
          </div>
          {jobs.length === 0 ? (
            <p className="px-4 py-8 text-center font-mono text-xs text-mist-500">no jobs recorded</p>
          ) : (
            <ul className="divide-y divide-ink-800">
              {jobs.map((job) => (
                <li key={job.id} className="flex items-center gap-2 px-3 py-2">
                  <span
                    className={[
                      "w-16 shrink-0 border px-1 py-px text-center font-mono text-[9px] tracking-[0.08em] uppercase",
                      job.status === "ok"
                        ? "border-signal-500/40 text-signal-400"
                        : "border-alert-500/40 text-alert-400",
                    ].join(" ")}
                  >
                    {job.kind}
                  </span>
                  <span className="min-w-0 flex-1 truncate font-mono text-[11px] text-mist-300">{job.target}</span>
                  <span className="shrink-0 font-mono text-[10px] text-mist-500 tabular-nums">{job.durationMs}ms</span>
                  <span className="w-14 shrink-0 text-right font-mono text-[9.5px] text-mist-500">
                    {timeAgo(job.createdAt)}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </div>
      </section>
    </div>
  );
}

import { fetchRaw } from "@/lib/http";
import { rewriteVtt, unwrapTransportStream } from "@/lib/hls";
import {
  buildHlsProxyUrl,
  convertSubtitleToVtt,
  rewritePlaylistForHlsProxy,
  tryDecodeHlsManifest,
  verifyHlsProxyRequest,
} from "@/lib/hls-proxy";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const CORS: Record<string, string> = {
  "access-control-allow-origin": "*",
  "access-control-allow-methods": "GET, HEAD, OPTIONS",
  "access-control-allow-headers": "*",
  "access-control-expose-headers":
    "content-length, content-type, content-range, accept-ranges, x-proxy-purpose, x-proxy-provider, x-hls-variants",
};

function proxyError(error: string, status: number, extra?: Record<string, unknown>) {
  return new Response(JSON.stringify({ error, ...extra }), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store",
      ...CORS,
    },
  });
}

async function handle(request: Request, headOnly: boolean): Promise<Response> {
  const reqUrl = new URL(request.url);
  const check = verifyHlsProxyRequest(reqUrl.searchParams);
  if (!check.ok) {
    return proxyError(check.error, check.error === "invalid_target_url" ? 400 : 403);
  }

  const { url: target, exp, ref, ctx, context, purpose } = check;
  const effectiveReferer = ref || context?.ref || "";
  let effectiveOrigin = context?.org || "";
  if (!effectiveOrigin && effectiveReferer) {
    try {
      effectiveOrigin = new URL(effectiveReferer).origin;
    } catch {
      effectiveOrigin = "";
    }
  }

  const forwardHeaders: Record<string, string> = { Accept: "*/*" };
  if (effectiveOrigin) forwardHeaders.Origin = effectiveOrigin;
  const range = request.headers.get("range");
  if (range) forwardHeaders.Range = range;

  const isProbe = purpose === "probe";

  try {
    const upstream = await fetchRaw(target, {
      referer: effectiveReferer || undefined,
      headers: forwardHeaders,
      timeoutMs: isProbe ? 12000 : undefined,
      retries: isProbe ? 1 : 2,
    });

    if (!upstream.ok && upstream.status !== 206) {
      return proxyError("upstream_error", 502, { status: upstream.status });
    }

    const contentType = upstream.headers.get("content-type") ?? "";
    const buffer = Buffer.from(await upstream.arrayBuffer());
    if (buffer.length === 0) {
      return proxyError("empty_upstream_body", 502);
    }

    const providerHeader = context?.p ?? "unknown";
    const metaHeaders: Record<string, string> = {
      ...(purpose ? { "x-proxy-purpose": purpose } : {}),
      "x-proxy-provider": providerHeader,
    };

    // 1. Subtitle conversion / relay (.vtt, .srt, .ass, .ssa)
    const lowerPath = new URL(target).pathname.toLowerCase();
    const headUtf8 = buffer.subarray(0, 24).toString("utf8").replace(/^\uFEFF/, "");
    const isSubtitle =
      context?.sub === "vtt" ||
      headUtf8.startsWith("WEBVTT") ||
      /\.(?:vtt|srt|ass|ssa)$/i.test(lowerPath);

    if (isSubtitle) {
      const rawText = buffer.toString("utf8");
      let vtt = convertSubtitleToVtt(rawText, target);
      // Rewrite any embedded thumbnail sprite URLs inside WebVTT cues.
      vtt = vtt.replace(/(https?:\/\/[^\s)]+\.(?:jpg|jpeg|png|webp))/gi, (match) => {
        try {
          return buildHlsProxyUrl(new URL(match, target).toString(), { ref, ctx, exp });
        } catch {
          return rewriteVtt(match, target);
        }
      });
      const encoded = Buffer.from(vtt, "utf8");
      return new Response(headOnly ? null : new Uint8Array(encoded), {
        status: 200,
        headers: {
          "content-type": "text/vtt; charset=utf-8",
          "content-length": String(encoded.length),
          "cache-control": "public, max-age=600",
          ...metaHeaders,
          ...CORS,
        },
      });
    }

    // 2. HLS playlist (plain `#EXTM3U` or FlixCloud `_v7` XOR-encoded manifest)
    const decodedManifest = tryDecodeHlsManifest(buffer, context?.pk);
    if (decodedManifest !== null) {
      const rewritten = rewritePlaylistForHlsProxy(decodedManifest, target, {
        ref,
        ctx,
        exp,
        audio: context?.aud,
      });
      const variants = (decodedManifest.match(/#EXT-X-STREAM-INF:/gi) ?? []).length;
      const encoded = Buffer.from(rewritten, "utf8");
      return new Response(headOnly ? null : new Uint8Array(encoded), {
        status: 200,
        headers: {
          "content-type": "application/vnd.apple.mpegurl",
          "content-length": String(encoded.length),
          "cache-control": "no-store, max-age=0",
          "x-hls-variants": String(variants),
          ...metaHeaders,
          ...CORS,
        },
      });
    }

    // 3. Binary payload: AES-128 `key.bin`, MPEG-TS (plain or PNG-disguised), fMP4, images
    const { data, isTs } = unwrapTransportStream(buffer);
    const outContentType = isTs
      ? "video/mp2t"
      : lowerPath.endsWith(".bin") || lowerPath.endsWith(".key")
        ? "application/octet-stream"
        : contentType || "application/octet-stream";

    const responseHeaders: Record<string, string> = {
      "content-type": outContentType,
      "content-length": String(data.length),
      "cache-control": "public, max-age=3600",
      ...metaHeaders,
      ...CORS,
    };
    const contentRange = upstream.headers.get("content-range");
    if (contentRange && !isTs) responseHeaders["content-range"] = contentRange;

    return new Response(headOnly ? null : new Uint8Array(data), {
      status: upstream.status === 206 && !isTs ? 206 : 200,
      headers: responseHeaders,
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    return proxyError("upstream_fetch_failed", 502, { detail: message });
  }
}

export async function GET(request: Request) {
  return handle(request, false);
}

export async function HEAD(request: Request) {
  return handle(request, true);
}

export async function OPTIONS() {
  return new Response(null, { status: 204, headers: CORS });
}

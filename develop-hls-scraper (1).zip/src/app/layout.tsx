import type { Metadata } from "next";
import type { ReactNode } from "react";
import Link from "next/link";
import "./globals.css";

export const metadata: Metadata = {
  title: "Anikoto HLS Scraper — stream extractor console",
  description:
    "Server-side scraper for anikototv.to that walks search → episodes → servers → embed and decrypts the AES-protected HLS master playlist.",
};

const NAV = [
  { href: "/", label: "Stream" },
  { href: "/library", label: "Library" },
  { href: "/jobs", label: "Jobs" },
  { href: "/docs", label: "API" },
];

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,500;12..96,700;12..96,800&family=IBM+Plex+Mono:wght@400;500;600&family=IBM+Plex+Sans:wght@400;500;600&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="min-h-screen">
        <div className="relative z-10 flex min-h-screen flex-col">
          <header className="sticky top-0 z-40 border-b border-ink-700/80 bg-ink-950/88 backdrop-blur-md">
            <div className="mx-auto flex w-full max-w-[1400px] items-center gap-6 px-5 py-3">
              <Link href="/" className="group flex items-center gap-3">
                <span className="relative grid size-8 place-items-center border border-ember-500/60 bg-ember-500/10">
                  <svg viewBox="0 0 24 24" className="size-4 text-ember-500" aria-hidden>
                    <path
                      d="M4 18 L9 6 L14 18 M6.4 13.6 H11.6"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="1.9"
                      strokeLinecap="square"
                    />
                    <path d="M17 6 L17 18 L21 6" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="square" />
                  </svg>
                </span>
                <span className="leading-none">
                  <span className="block font-display text-[15px] font-extrabold tracking-tight text-mist-50">
                    ANIKOTO<span className="text-ember-500">/</span>HLS
                  </span>
                  <span className="label mt-0.5 block text-[9px]">stream extractor</span>
                </span>
              </Link>

              <nav className="ml-auto flex items-center gap-1">
                {NAV.map((item) => (
                  <Link
                    key={item.href}
                    href={item.href}
                    className="rounded-[3px] px-3 py-1.5 font-mono text-[11px] tracking-[0.14em] text-mist-400 uppercase transition-colors hover:bg-ink-800 hover:text-ember-300"
                  >
                    {item.label}
                  </Link>
                ))}
              </nav>

              <span className="hidden items-center gap-2 border border-ink-700 bg-ink-900 px-2.5 py-1.5 font-mono text-[10px] tracking-[0.1em] text-mist-400 lg:inline-flex">
                <span className="pulse-dot size-1.5 rounded-full bg-signal-500" />
                anikoto · reanime · aniwaves
              </span>
            </div>
          </header>

          <main className="flex-1">{children}</main>

          <footer className="border-t border-ink-800 bg-ink-950/70">
            <div className="mx-auto flex w-full max-w-[1400px] flex-col gap-2 px-5 py-5 font-mono text-[10.5px] tracking-[0.09em] text-mist-500 sm:flex-row sm:items-center sm:justify-between">
              <span>
                anikoto/hls · scraper console · postgres cache · no keys stored on the client
              </span>
              <span className="text-mist-500/70">
                all extraction happens server-side · relay adds the referer the CDN requires
              </span>
            </div>
          </footer>
        </div>
      </body>
    </html>
  );
}

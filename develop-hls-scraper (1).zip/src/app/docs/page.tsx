import { CopyButton } from "@/components/CopyButton";
import { SITE, PLAYER, CACHE } from "@/lib/config";

export const dynamic = "force-dynamic";

interface Endpoint {
  method: "GET" | "POST";
  path: string;
  summary: string;
  params?: Array<{ name: string; type: string; note: string }>;
  example?: string;
  response?: string;
}

const ENDPOINTS: Endpoint[] = [
  {
    method: "GET",
    path: "/api/stream/[anilistId]/[episode]",
    summary:
      "The main endpoint: AniList id + episode number → playable HLS across 9 working streaming providers — ani.pm (Settlar HLS), kaa.lt (Krussdomi HLS), reanime.to (FlixCloud WASM + _v7 XOR), anizone.to (Seiryuu Vid-CDN 1080p), xanime.me (XaniVSrc HLS), anikototv.to (MegaPlay AES-256), aniwaves.ru (EchoVideo / VhsCDN), animegg.org (Vidcache 360p–1080p), animotvslash.org (Multi-Mirror / MegaPlay). Append .m3u8 to the episode for a self-contained playlist. Also available as /api/stream?anilist=&ep=&provider=.",
    params: [
      { name: "provider", type: "anipm|reanime|anizone|xanime|anikoto|aniwaves|animegg|animotvslash|auto", note: "scraper target (auto fails over across providers in priority order)" },
      { name: "type", type: "sub|dub", note: "audio track, defaults to sub (falls back if missing)" },
      { name: "strategy", type: "auto|site|direct", note: "anikoto path: site first, then direct MegaPlay" },
      { name: "format", type: "json|m3u8|redirect", note: "json default; m3u8 = playlist body; redirect = 302 to /proxy/hls" },
      { name: "force", type: "bool", note: "1 bypasses every cache layer" },
    ],
    example: `curl 'http://localhost:3000/api/stream/154587/1?provider=anipm&type=sub'
curl 'http://localhost:3000/api/stream/154587/1?provider=kaa&type=sub'
curl 'http://localhost:3000/api/stream/154587/1?provider=anizone&type=sub'
curl 'http://localhost:3000/api/stream/154587/1?provider=xanime&type=sub'
curl 'http://localhost:3000/api/stream/154587/1?provider=reanime&type=sub'
curl 'http://localhost:3000/api/stream/154587/1?provider=animegg&type=sub'
curl 'http://localhost:3000/api/stream/154587/1?provider=animotvslash&type=sub'
curl 'http://localhost:3000/api/stream/154587/1?provider=aniwaves&type=sub'
curl 'http://localhost:3000/api/stream/21/1?provider=anikoto&type=sub'

# straight into a player — no headers needed
mpv 'http://localhost:3000/api/stream/154587/1.m3u8?provider=anipm&type=sub'`,
    response: `{
  "ok": true,
  "data": {
    "anilistId": 21, "episode": 1,
    "requestedType": "sub", "type": "sub", "typeFallback": false,
    "strategy": "site",
    "stream": {
      "m3u8": "https://megap.shiora.top/f899…/61b8…/master.m3u8",
      "proxied": "/api/relay?url=https%3A%2F%2Fmegap.shiora.top%2F…&t=…",
      "referer": "https://megaplay.buzz/",
      "headers": { "Referer": "https://megaplay.buzz/", "Origin": "https://megaplay.buzz", "User-Agent": "…" },
      "subtitles": [{ "file": "https://…/eng-2.vtt", "label": "English", "default": true, "proxied": "/api/relay?…" }],
      "intro": { "start": 31, "end": 111 }, "outro": { "start": 1376, "end": 1447 },
      "server": { "name": "HD-1", "id": "323" },
      "embed": "https://megaplay.buzz/stream/s-2/2142/sub?s=tcdn"
    },
    "anilist": { "id": 21, "idMal": 21, "title": "ONE PIECE", "format": "TV", "episodes": null, "…": "…" },
    "match": {
      "animeId": "1642", "slug": "one-piece-odmau", "title": "One Piece",
      "method": "mal-verified", "confidence": 1, "malId": "21",
      "episodeId": "30298", "availableEpisodes": 1180, "firstEpisode": "1", "lastEpisode": "1180"
    },
    "attempts": [
      { "step": "anilist", "ok": true }, { "step": "map", "ok": true }, { "step": "site", "ok": true }
    ],
    "links": {
      "json": "http://localhost:3000/api/stream/21/1?type=sub",
      "playlist": "http://localhost:3000/api/stream/21/1.m3u8?type=sub",
      "relay": "http://localhost:3000/api/relay?url=…&t=…",
      "page": "http://localhost:3000/?anilist=21&ep=1&type=sub"
    },
    "cached": false, "tookMs": 2140
  }
}`,
  },
  {
    method: "GET",
    path: "/api/search",
    summary:
      "Scrapes the site's filter page for a keyword and upserts every card into the local library.",
    params: [
      { name: "q", type: "string", note: "keyword, required" },
      { name: "page", type: "int", note: "1–500, defaults to 1" },
    ],
    example: `curl 'http://localhost:3000/api/search?q=one+piece&page=1'`,
    response: `{
  "ok": true,
  "cached": false,
  "data": {
    "query": "one piece",
    "items": [
      {
        "id": "1642",
        "slug": "one-piece-odmau",
        "title": "One Piece",
        "japaneseTitle": "One Piece",
        "poster": "https://cdn.anipixcdn.co/thumbnail/f899…jpg",
        "genres": ["Action", "Adventure", "Fantasy"],
        "type": "TV",
        "score": 8.73,
        "subCount": 1180,
        "dubCount": 1133,
        "totalEpisodes": 1180,
        "url": "https://anikototv.to/watch/one-piece-odmau"
      }
    ],
    "pagination": { "page": 1, "totalPages": 11, "hasNext": true }
  }
}`,
  },
  {
    method: "GET",
    path: "/api/trending",
    summary: "Scrapes the home page trending widget (GET /ajax/home/widget/trending).",
    example: `curl 'http://localhost:3000/api/trending'`,
  },
  {
    method: "GET",
    path: "/api/anime/[slug]",
    summary:
      "Scrapes /watch/{slug} for metadata and ajax/episode/list/{id} for the whole episode table, then persists both.",
    params: [{ name: "force", type: "bool", note: "1 bypasses the TTL cache and re-scrapes" }],
    example: `curl 'http://localhost:3000/api/anime/one-piece-odmau'`,
    response: `{
  "ok": true,
  "data": {
    "detail": {
      "id": "1642", "slug": "one-piece-odmau", "title": "One Piece",
      "genres": ["Action","Adventure","Fantasy","Comedy","Shounen"],
      "studios": ["Toei Animation"], "type": "TV", "status": "Currently Airing",
      "score": 8.73, "duration": "24 min", "aired": "Oct 20, 1999 to ?",
      "subCount": 0, "dubCount": 0, "totalEpisodes": 1180
    },
    "episodes": [
      {
        "id": "30298", "number": "1",
        "title": "I'm Luffy! The Man Who's Gonna Be King of the Pirates!",
        "hasSub": true, "hasDub": true,
        "serverIds": "cTFsbUc1WkRESy9LdjF0QWw0WHcva1dr…",
        "airedAt": "1778430601"
      }
    ],
    "cached": false
  }
}`,
  },
  {
    method: "GET",
    path: "/api/episodes/[episodeId]/servers",
    summary:
      "Replays the cached data-ids payload against ajax/server/list and returns every sub/dub server.",
    example: `curl 'http://localhost:3000/api/episodes/30298/servers'`,
    response: `{
  "ok": true,
  "data": {
    "episodeId": "30298",
    "servers": [
      { "episodeId": "30298", "name": "HD-1", "serverId": "323",
        "cmid": "animixplay-fqsqfvdf4u", "linkId": "MTF1dkFtaW9BRTZPbzJJRElF…", "type": "sub" }
    ]
  }
}`,
  },
  {
    method: "GET",
    path: "/api/episodes/[episodeId]/source",
    summary:
      "The full chain: ajax/server?get={link-id} → embed page → stream/getSourcesNew → AES-256-CBC decrypt → master.m3u8. Persisted in the sources table.",
    params: [
      { name: "server", type: "string", note: "serverId to prefer (e.g. 323)" },
      { name: "type", type: "string", note: "sub | dub" },
      { name: "index", type: "int", note: "position in the server list" },
      { name: "force", type: "bool", note: "1 ignores the cached playlist" },
    ],
    example: `curl 'http://localhost:3000/api/episodes/30298/source?type=sub'`,
    response: `{
  "ok": true,
  "data": {
    "episodeId": "30298",
    "animeId": "1642",
    "server": { "name": "HD-1", "serverId": "323", "type": "sub", "…": "…" },
    "resolved": {
      "embedUrl": "https://megaplay.buzz/stream/s-2/2142/sub?s=tcdn",
      "playerId": "36396",
      "hlsUrl": "https://megap.shiora.top/f899…/61b8…/master.m3u8",
      "referer": "https://megaplay.buzz/",
      "intro": { "start": 31, "end": 111 },
      "outro": { "start": 1376, "end": 1447 },
      "tracks": [
        { "file": "https://de3bv…/subtitles/eng-2.vtt", "label": "English",
          "kind": "captions", "default": true }
      ],
      "decrypted": { "file": "https://megap.shiora.top/…/master.m3u8" }
    },
    "proxiedUrl": "/api/relay?url=https%3A%2F%2Fmegap.shiora.top%2F…%2Fmaster.m3u8",
    "cached": false
  }
}`,
  },
  {
    method: "GET",
    path: "/proxy/hls",
    summary:
      "Stateless sealed-context HLS proxy. Validates the HMAC-SHA256 sig & expiry, opens the AES-256-GCM sealed ctx=c1.<ctxExp>.<iv>.<ciphertext>.<tag>, injects upstream Referer/Origin, XOR-decodes FlixCloud _v7 manifests on the fly using the sealed 32-byte WASM __pk key, promotes English audio when dub is requested, converts .ass/.srt subtitles to WebVTT, unwraps PNG-disguised MPEG-TS segments, and re-signs every nested URI.",
    params: [
      { name: "url", type: "string", note: "upstream playlist, key.bin, segment, or subtitle URL" },
      { name: "exp", type: "int", note: "unix expiry seconds" },
      { name: "sig", type: "string", note: "43-char base64url HMAC-SHA256 over (url, exp, ref, ctx)" },
      { name: "ref", type: "string", note: "upstream Referer (e.g. https://flixcloud.cc/)" },
      { name: "ctx", type: "string", note: "c1.<ctxExp>.<12B-iv>.<ciphertext>.<16B-gcm-tag>" },
      { name: "purpose", type: "probe|playback|prewarm|manual", note: "unauthenticated purpose tag" },
    ],
    example: `curl 'http://localhost:3000/proxy/hls?url=https%3A%2F%2Ffetch9.flixcloud.cc%2F_v7%2F…%2Fmaster.m3u8%3Ftoken%3D…&exp=1793538000&sig=…&ref=https%3A%2F%2Fflixcloud.cc%2F&ctx=c1.1793559600.…&purpose=probe'`,
  },
  {
    method: "GET",
    path: "/api/relay",
    summary:
      "Streams a playlist, segment or subtitle file with the Referer the CDN demands, rewriting nested URIs so the whole stream stays same-origin. Only media extensions are relayed.",
    params: [{ name: "url", type: "string", note: "absolute .m3u8 / .ts / .vtt / image url" }],
    example: `curl '/api/relay?url=https%3A%2F%2Fmegap.shiora.top%2F…%2Fmaster.m3u8'`,
  },
  {
    method: "POST",
    path: "/api/scrape",
    summary:
      "Bulk crawl. Crawl search pages into the library, or fully index one title and resolve real playlists for its first episodes.",
    example: `curl -X POST 'http://localhost:3000/api/scrape' \\
  -H 'content-type: application/json' \\
  -d '{"keyword":"frieren","pages":2}'

curl -X POST 'http://localhost:3000/api/scrape' \\
  -H 'content-type: application/json' \\
  -d '{"slug":"one-piece-odmau","resolveEpisodes":2}'`,
  },
  {
    method: "GET",
    path: "/api/library",
    summary: "Read the local cache.",
    params: [
      { name: "kind", type: "string", note: "animes | jobs | stats | sources | ok-sources" },
      { name: "limit", type: "int", note: "1–200" },
    ],
    example: `curl 'http://localhost:3000/api/library?kind=stats'`,
  },
  {
    method: "GET",
    path: "/api/jobs",
    summary: "The scrape audit trail.",
    params: [{ name: "limit", type: "int", note: "1–500, defaults to 80" }],
    example: `curl 'http://localhost:3000/api/jobs?limit=50'`,
  },
  {
    method: "GET",
    path: "/api/stats",
    summary: "Aggregate counters for the console.",
    example: `curl 'http://localhost:3000/api/stats'`,
  },
];

export default function DocsPage() {
  return (
    <div className="mx-auto w-full max-w-[1400px] px-5 py-8">
      <div className="border-b border-ink-700 pb-4">
        <p className="label">reference</p>
        <h1 className="mt-2 font-display text-[clamp(1.7rem,3.6vw,2.4rem)] leading-none font-extrabold tracking-[-0.02em] text-mist-50">
          HTTP API
        </h1>
        <p className="mt-2 max-w-2xl text-[13.5px] text-mist-400">
          Every route runs on the Node runtime and performs the scrape server-side, so the upstream
          site never sees a browser origin and the player key never reaches the client bundle.
        </p>
      </div>

      <section className="mt-8 grid gap-4 lg:grid-cols-3">
        <div className="panel p-4">
          <p className="label">upstream</p>
          <code className="mt-2 block font-mono text-[12px] text-ember-300">{SITE.baseUrl}</code>
          <p className="mt-2 font-mono text-[10.5px] leading-relaxed text-mist-500">
            timeout {SITE.timeoutMs}ms · {SITE.retries} retries
          </p>
        </div>
        <div className="panel p-4">
          <p className="label">player cipher</p>
          <p className="mt-2 font-mono text-[11.5px] text-mist-300">aes-256-cbc · base64url payload</p>
          <p className="mt-2 font-mono text-[10.5px] leading-relaxed break-all text-mist-500">
            key <span className="text-mist-300">{PLAYER.aesKey}</span> (zero-padded to 32B)
            <br />
            iv <span className="text-mist-300">{PLAYER.aesIv}</span>
          </p>
        </div>
        <div className="panel p-4">
          <p className="label">cache ttl</p>
          <ul className="mt-2 space-y-1 font-mono text-[10.5px] text-mist-500">
            <li>
              source <span className="text-mist-300">{Math.round(CACHE.sourceTtlMs / 60000)}m</span>
            </li>
            <li>
              episodes <span className="text-mist-300">{Math.round(CACHE.episodeTtlMs / 3600000)}h</span>
            </li>
            <li>
              anime <span className="text-mist-300">{Math.round(CACHE.animeTtlMs / 86400000)}d</span>
            </li>
            <li>
              trending <span className="text-mist-300">{Math.round(CACHE.trendingTtlMs / 60000)}m</span>
            </li>
          </ul>
        </div>
      </section>

      <section className="mt-8 flex flex-col gap-5">
        {ENDPOINTS.map((ep) => (
          <div key={`${ep.method}-${ep.path}`} className="panel overflow-hidden">
            <div className="panel-header flex-wrap gap-2">
              <div className="flex min-w-0 items-center gap-2">
                <span
                  className={[
                    "shrink-0 border px-1.5 py-0.5 font-mono text-[9.5px] tracking-[0.12em]",
                    ep.method === "GET"
                      ? "border-signal-500/40 text-signal-400"
                      : "border-flare-400/40 text-flare-400",
                  ].join(" ")}
                >
                  {ep.method}
                </span>
                <code className="truncate font-mono text-[12.5px] text-mist-50">{ep.path}</code>
              </div>
              {ep.example && <CopyButton value={ep.example} label="copy curl" />}
            </div>

            <div className="p-4">
              <p className="max-w-3xl text-[13px] leading-relaxed text-mist-400">{ep.summary}</p>

              {ep.params && (
                <div className="mt-3 flex flex-wrap gap-1.5">
                  {ep.params.map((p) => (
                    <span key={p.name} className="chip" title={p.note}>
                      <span className="text-ember-300">{p.name}</span>
                      <span className="text-mist-500">:</span>
                      {p.type}
                      <span className="ml-1 text-mist-500">— {p.note}</span>
                    </span>
                  ))}
                </div>
              )}

              {ep.example && (
                <pre className="mt-4 overflow-x-auto rounded-[3px] border border-ink-700 bg-ink-950 p-3 font-mono text-[11px] leading-relaxed text-mist-300">
                  {ep.example}
                </pre>
              )}

              {ep.response && (
                <pre className="mt-3 max-h-80 overflow-auto rounded-[3px] border border-ink-700 bg-ink-950 p-3 font-mono text-[11px] leading-relaxed text-signal-400/90">
                  {ep.response}
                </pre>
              )}
            </div>
          </div>
        ))}
      </section>

      <section className="panel mt-8 p-5">
        <h2 className="font-display text-lg font-bold text-mist-50">How the playlist is unwrapped</h2>
        <ol className="mt-3 space-y-2 text-[13px] leading-relaxed text-mist-400">
          <li>
            <span className="font-mono text-ember-400">1.</span> Each episode anchor carries an
            opaque <code className="text-mist-200">data-ids</code> blob. It is replayed against{" "}
            <code className="text-mist-200">/ajax/server/list</code> to reveal{" "}
            <code className="text-mist-200">data-link-id</code> per server.
          </li>
          <li>
            <span className="font-mono text-ember-400">2.</span>{" "}
            <code className="text-mist-200">/ajax/server?get=&#123;link-id&#125;</code> answers with
            the embed URL plus community intro/outro markers.
          </li>
          <li>
            <span className="font-mono text-ember-400">3.</span> The embed page only renders when the
            request carries the site as <code className="text-mist-200">Referer</code>; its player
            element exposes <code className="text-mist-200">data-id</code>.
          </li>
          <li>
            <span className="font-mono text-ember-400">4.</span>{" "}
            <code className="text-mist-200">/stream/getSourcesNew?id=…</code> returns{" "}
            <code className="text-mist-200">enc</code>, a base64url AES-256-CBC ciphertext. The
            key/iv are static strings hidden inside the player bundle&apos;s self-defending string
            table and are recovered once, then supplied via{" "}
            <code className="text-mist-200">PLAYER_AES_KEY</code> /{" "}
            <code className="text-mist-200">PLAYER_AES_IV</code>.
          </li>
          <li>
            <span className="font-mono text-ember-400">5.</span> The plaintext is{" "}
            <code className="text-mist-200">&#123;&quot;file&quot;: &quot;…/master.m3u8&quot;&#125;</code>.
            The CDN rejects requests without the embed host as referer, so{" "}
            <code className="text-mist-200">/api/relay</code> proxies and rewrites it for playback.
          </li>
        </ol>
      </section>
    </div>
  );
}

import { PLAYER } from "@/lib/config";
import { fetchRaw } from "@/lib/http";
import {
  isPlaylist,
  rewritePlaylist,
  rewriteVtt,
  unwrapTransportStream,
  upstreamMediaHeaders,
} from "@/lib/hls";
import { isRelayAllowed } from "@/lib/relay";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const CORS = {
  "access-control-allow-origin": "*",
  "access-control-allow-headers": "*",
  "access-control-expose-headers": "content-length, content-type",
};

function jsonError(message: string, status: number) {
  return new Response(JSON.stringify({ ok: false, error: message }), {
    status,
    headers: { "content-type": "application/json", ...CORS },
  });
}

/**
 * GET /api/relay?url=<absolute media url>&t=<signature>
 *
 * Relays playlists, segments and subtitle files, injecting the Referer the CDN
 * demands and rewriting (and signing) every nested URI so the whole stream
 * stays same-origin and playable from a browser.
 *
 * The CDN disguises MPEG-TS fragments as image assets, so the text/binary
 * decision is made by sniffing the payload rather than trusting the extension
 * or the upstream content-type.
 */
export async function GET(request: Request) {
  const search = new URL(request.url).searchParams;
  // URLSearchParams already percent-decodes exactly once. Decoding again would
  // corrupt signed CDN URLs that legitimately contain %2F / %3D sequences.
  const absolute = search.get("url");
  if (!absolute) return jsonError("missing ?url=<absolute media url>", 400);

  if (!isRelayAllowed(absolute, search.get("t"))) {
    return jsonError("that url is neither signed by this app nor an allowed media asset", 403);
  }

  try {
    new URL(absolute);
  } catch {
    return jsonError("malformed url", 400);
  }

  try {
    const upstream = await fetchRaw(absolute, {
      referer: PLAYER.cdnReferer,
      retries: 1,
      headers: upstreamMediaHeaders(),
    });

    if (!upstream.ok) {
      return jsonError(`upstream responded ${upstream.status}`, 502);
    }

    const contentType = upstream.headers.get("content-type") ?? "";
    const buffer = Buffer.from(await upstream.arrayBuffer());
    if (buffer.length === 0) return jsonError("upstream returned an empty body", 502);

    const head = buffer.subarray(0, 16).toString("utf8").replace(/^\uFEFF/, "");
    const isM3u8 = head.startsWith("#EXTM3U") || (contentType.includes("mpegurl") && isPlaylist(contentType, head));
    const isVtt = head.startsWith("WEBVTT");

    if (isM3u8 || isVtt) {
      const body = buffer.toString("utf8");
      const output = isM3u8 ? rewritePlaylist(body, absolute) : rewriteVtt(body, absolute);
      const encoded = Buffer.from(output, "utf8");
      return new Response(new Uint8Array(encoded), {
        status: 200,
        headers: {
          "content-type": isM3u8 ? "application/vnd.apple.mpegurl" : "text/vtt; charset=utf-8",
          "content-length": String(encoded.length),
          "cache-control": "no-store, max-age=0",
          ...CORS,
        },
      });
    }

    const { data, isTs } = unwrapTransportStream(buffer);
    return new Response(new Uint8Array(data), {
      status: 200,
      headers: {
        // Fragments are routinely mislabelled as images; real images keep their type.
        "content-type": isTs ? "video/mp2t" : contentType || "application/octet-stream",
        "content-length": String(data.length),
        "cache-control": "public, max-age=3600",
        ...CORS,
      },
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    return jsonError(`relay failed: ${message}`, 502);
  }
}

export async function OPTIONS() {
  return new Response(null, { status: 204, headers: CORS });
}

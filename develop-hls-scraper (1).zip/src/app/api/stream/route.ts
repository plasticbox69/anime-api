import { handleStream } from "@/lib/stream-http";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 60;

/**
 * GET /api/stream?anilist=21&ep=1&type=sub&provider=anikoto|reanime|aniwaves|auto&strategy=auto&format=json&force=0
 *
 * AniList id + episode number -> HLS stream across anikototv.to, reanime.to, or aniwaves.ru.
 */
export async function GET(request: Request) {
  const sp = new URL(request.url).searchParams;
  return handleStream(request, {
    anilist: sp.get("anilist") ?? sp.get("id"),
    episode: sp.get("ep") ?? sp.get("episode"),
    type: sp.get("type"),
    provider: sp.get("provider") ?? sp.get("source"),
    strategy: sp.get("strategy"),
    force: sp.get("force"),
    format: sp.get("format"),
  });
}

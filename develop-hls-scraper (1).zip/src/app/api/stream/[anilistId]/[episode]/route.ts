import { handleStream } from "@/lib/stream-http";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 60;

/**
 * GET /api/stream/{anilistId}/{episode}?provider=anikoto|reanime|aniwaves|auto&type=sub|dub
 * GET /api/stream/{anilistId}/{episode}.m3u8?provider=reanime&type=sub   <- playable playlist
 */
export async function GET(
  request: Request,
  context: { params: Promise<{ anilistId: string; episode: string }> },
) {
  const { anilistId, episode } = await context.params;
  const sp = new URL(request.url).searchParams;
  return handleStream(request, {
    anilist: anilistId,
    episode: decodeURIComponent(episode),
    type: sp.get("type"),
    provider: sp.get("provider") ?? sp.get("source"),
    strategy: sp.get("strategy"),
    force: sp.get("force"),
    format: sp.get("format"),
  });
}

import { getAnime } from "@/lib/scraper";
import { fail, ok, parseBoolParam } from "@/lib/api";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * GET /api/anime/[slug]?force=1
 *
 * Scrapes `/watch/{slug}` for metadata and `ajax/episode/list/{id}` for the
 * full episode table, persisting both.
 */
export async function GET(
  request: Request,
  context: { params: Promise<{ slug: string }> },
) {
  const { slug } = await context.params;
  const { searchParams } = new URL(request.url);
  const force = parseBoolParam(searchParams.get("force"));

  try {
    const result = await getAnime(decodeURIComponent(slug), force);
    return ok(result, { cached: result.cached });
  } catch (err) {
    return fail(err);
  }
}

import { runBulk, parseIdScope, type BulkScope } from "@/lib/bulk";
import { publicOrigin } from "@/lib/stream-http";
import { fail, ok } from "@/lib/api";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 600;

/**
 * POST /api/bulk
 *
 * Body:
 * {
 *   "scope":  {"kind":"ids","from":1,"to":1000}
 *          or {"kind":"chart","chart":"trending","period":"week","limit":100}
 *          or {"kind":"chart","chart":"popular","limit":10000},
 *   "type": "sub"|"dub",
 *   "episodes": "first"|"all",
 *   "limit": 100
 * }
 *
 * Resolves streams for the scoped anime through the provider chain
 * (reanime → xmark → kaa → aniwaves → xanime → anizone → animegg → anikoto)
 * and returns annotated /proxy/hls links.
 */
export async function POST(request: Request) {
  let body: Record<string, unknown>;
  try {
    body = (await request.json()) as Record<string, unknown>;
  } catch {
    return fail(new Error("invalid JSON body"), "invalid body");
  }

  const type = body.type === "dub" ? "dub" : "sub";
  const episodes = body.episodes === "all" ? "all" : "first";
  const limit = Math.min(Math.max(Number(body.limit ?? 100) || 100, 1), 2000);

  let scope: BulkScope;
  const rawScope = body.scope as Record<string, unknown> | string | undefined;
  try {
    if (typeof rawScope === "string") {
      scope = parseIdScope(rawScope);
      // keep raw for list-vs-range detection
    } else if (rawScope && typeof rawScope === "object" && rawScope.kind === "ids") {
      const from = Number(rawScope.from);
      const to = Number(rawScope.to);
      if (!Number.isInteger(from) || !Number.isInteger(to) || from <= 0 || to <= 0) {
        throw new Error("ids scope needs numeric from/to");
      }
      if (to < from || to - from > 50_000) throw new Error("id range too large (max 50,000)");
      scope = { kind: "ids", from, to };
    } else if (rawScope && rawScope.kind === "chart") {
      const chart = rawScope.chart === "popular" ? "popular" : "trending";
      const periodRaw = String(rawScope.period ?? "week");
      const period = periodRaw === "day" || periodRaw === "week" || periodRaw === "month" ? periodRaw : "week";
      const chartLimit = Math.min(Math.max(Number(rawScope.limit ?? 100) || 100, 1), 10_000);
      scope = { kind: "chart", chart, period, limit: chartLimit };
    } else {
      throw new Error("scope must be {kind:'ids',from,to}, an id-range string like \"1-1000\", or {kind:'chart',chart,period,limit}");
    }
  } catch (err) {
    return fail(err, "invalid scope");
  }

  try {
    const result = await runBulk(
      { scope, type, episodes, limit },
      publicOrigin(request),
    );
    return ok(result, { cached: false });
  } catch (err) {
    return fail(err);
  }
}

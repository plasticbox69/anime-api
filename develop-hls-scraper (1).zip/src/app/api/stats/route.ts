import { getStats } from "@/lib/scraper";
import { fail, ok } from "@/lib/api";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** GET /api/stats — aggregate counters for the dashboard. */
export async function GET() {
  try {
    return ok(await getStats());
  } catch (err) {
    return fail(err);
  }
}

import { resolveSource } from "@/lib/scraper";
import { fail, ok, parseBoolParam, parseIntParam } from "@/lib/api";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * GET /api/episodes/[episodeId]/source?server=<svId>&type=<sub|dub>&index=<n>&force=1
 *
 * Runs the whole extraction chain and returns the decrypted HLS master playlist
 * plus a relay URL that the bundled player can consume directly.
 */
export async function GET(
  request: Request,
  context: { params: Promise<{ episodeId: string }> },
) {
  const { episodeId } = await context.params;
  const { searchParams } = new URL(request.url);

  const server = searchParams.get("server") ?? undefined;
  const type = searchParams.get("type") ?? undefined;
  const indexRaw = searchParams.get("index");
  const force = parseBoolParam(searchParams.get("force"));

  try {
    const result = await resolveSource(
      episodeId,
      {
        serverId: server,
        type,
        index: indexRaw === null ? undefined : parseIntParam(indexRaw, 0, 0, 50),
      },
      force,
    );
    return ok(result, { cached: result.cached });
  } catch (err) {
    return fail(err);
  }
}

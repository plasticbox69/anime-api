import { getServers } from "@/lib/scraper";
import { fail, ok } from "@/lib/api";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * GET /api/episodes/[episodeId]/servers
 *
 * Uses the cached `data-ids` payload for the episode to list every streaming
 * server the site advertises (sub + dub).
 */
export async function GET(
  _request: Request,
  context: { params: Promise<{ episodeId: string }> },
) {
  const { episodeId } = await context.params;
  try {
    const servers = await getServers(episodeId);
    return ok({ episodeId, servers });
  } catch (err) {
    return fail(err);
  }
}

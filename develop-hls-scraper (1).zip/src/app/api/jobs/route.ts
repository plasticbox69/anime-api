import { getJobs } from "@/lib/scraper";
import { fail, ok, parseIntParam } from "@/lib/api";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** GET /api/jobs?limit= — the scrape audit trail. */
export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const limit = parseIntParam(searchParams.get("limit"), 80, 1, 500);
  try {
    return ok({ jobs: await getJobs(limit) });
  } catch (err) {
    return fail(err);
  }
}

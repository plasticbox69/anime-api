import { getAnime, resolveSource, searchAnimes } from "@/lib/scraper";
import { fail, ok } from "@/lib/api";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 120;

interface ScrapeBody {
  keyword?: string;
  slug?: string;
  pages?: number;
  /** When scraping a slug, also resolve HLS for the first N episodes. */
  resolveEpisodes?: number;
}

/**
 * POST /api/scrape
 *
 * Bulk scrape. Either crawl search results into the local library
 *   { "keyword": "one piece", "pages": 3 }
 * or fully index one title and optionally resolve real playlists
 *   { "slug": "one-piece-odmau", "resolveEpisodes": 2 }
 */
export async function POST(request: Request) {
  let body: ScrapeBody = {};
  try {
    body = (await request.json()) as ScrapeBody;
  } catch {
    body = {};
  }

  const pages = Math.min(Math.max(Number(body.pages ?? 1) || 1, 1), 10);

  try {
    if (body.slug) {
      const anime = await getAnime(body.slug.replace(/^\/+|\/+$/g, ""), true);
      const wanted = Math.min(Math.max(Number(body.resolveEpisodes ?? 0) || 0, 0), 5);
      const resolved: Array<{
        episodeId: string;
        number: string;
        hlsUrl: string | null;
        server: string;
        error?: string;
      }> = [];

      for (const ep of anime.episodes.slice(0, wanted)) {
        try {
          const src = await resolveSource(ep.id, undefined, true);
          resolved.push({
            episodeId: ep.id,
            number: ep.number,
            hlsUrl: src.resolved.hlsUrl,
            server: src.server.name,
          });
        } catch (err) {
          resolved.push({
            episodeId: ep.id,
            number: ep.number,
            hlsUrl: null,
            server: "-",
            error: err instanceof Error ? err.message : String(err),
          });
        }
      }

      return ok({
        mode: "slug",
        detail: anime.detail,
        episodeCount: anime.episodes.length,
        resolved,
      });
    }

    if (body.keyword) {
      const collected = [];
      let lastPage = 1;
      for (let p = 1; p <= pages; p += 1) {
        const result = await searchAnimes(body.keyword, p);
        collected.push(...result.items);
        lastPage = result.pagination.page;
        if (!result.pagination.hasNext) break;
      }
      return ok({
        mode: "keyword",
        keyword: body.keyword,
        pagesScraped: lastPage,
        items: collected,
        count: collected.length,
      });
    }

    return fail(new Error("provide either { slug } or { keyword }"), "missing target");
  } catch (err) {
    return fail(err);
  }
}

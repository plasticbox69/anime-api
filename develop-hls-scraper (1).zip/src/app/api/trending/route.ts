import { getTrending } from "@/lib/scraper";
import { fail, ok } from "@/lib/api";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** GET /api/trending — scrapes the site's home "trending" widget. */
export async function GET() {
  try {
    const items = await getTrending();
    return ok({ items });
  } catch (err) {
    return fail(err);
  }
}

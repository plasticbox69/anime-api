import { searchAnimes } from "@/lib/scraper";
import { fail, ok, parseIntParam } from "@/lib/api";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * GET /api/search?q=<keyword>&page=<n>
 *
 * Scrapes the site's filter page and upserts every discovered card into the
 * local library.
 */
export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const q = (searchParams.get("q") ?? searchParams.get("keyword") ?? "").trim();
  const page = parseIntParam(searchParams.get("page"), 1, 1, 500);

  if (!q) {
    return fail(new Error("missing ?q=<keyword>"), "missing query");
  }

  try {
    const result = await searchAnimes(q, page);
    return ok(result, { cached: result.cached });
  } catch (err) {
    return fail(err);
  }
}

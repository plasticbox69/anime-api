import { getJobs, getLibrary, getStats } from "@/lib/scraper";
import { fail, ok, parseIntParam } from "@/lib/api";
import { db } from "@/db";
import { sources } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * GET /api/library?limit=&offset=&kind=jobs|sources|stats
 *
 * Read side of the local Postgres cache: scraped anime, resolved playlists,
 * aggregate counters and the scrape audit trail.
 */
export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const kind = searchParams.get("kind") ?? "animes";
  const limit = parseIntParam(searchParams.get("limit"), 48, 1, 200);

  try {
    if (kind === "jobs") {
      const jobs = await getJobs(limit);
      return ok({ jobs });
    }
    if (kind === "stats") {
      return ok(await getStats());
    }
    if (kind === "sources") {
      const rows = await db
        .select()
        .from(sources)
        .orderBy(desc(sources.resolvedAt))
        .limit(limit);
      return ok({ sources: rows });
    }
    if (kind === "ok-sources") {
      const rows = await db
        .select()
        .from(sources)
        .where(eq(sources.status, "ok"))
        .orderBy(desc(sources.resolvedAt))
        .limit(limit);
      return ok({ sources: rows });
    }

    const animes = await getLibrary(limit);
    return ok({ animes });
  } catch (err) {
    return fail(err);
  }
}

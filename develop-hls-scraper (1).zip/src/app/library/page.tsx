import Link from "next/link";
import { desc, ilike, or, sql } from "drizzle-orm";
import { db } from "@/db";
import { animes } from "@/db/schema";
import { timeAgo } from "@/lib/format";

export const dynamic = "force-dynamic";

export default async function LibraryPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string }>;
}) {
  const { q } = await searchParams;
  const needle = (q ?? "").trim();

  const where = needle
    ? or(ilike(animes.title, `%${needle}%`), ilike(animes.slug, `%${needle}%`))
    : undefined;

  const rows = await db
    .select()
    .from(animes)
    .where(where)
    .orderBy(desc(animes.updatedAt))
    .limit(180);

  const [total] = await db.select({ n: sql<number>`count(*)::int` }).from(animes);

  return (
    <div className="mx-auto w-full max-w-[1400px] px-5 py-8">
      <div className="flex flex-wrap items-end gap-4 border-b border-ink-700 pb-4">
        <div>
          <p className="label">postgres · table <span className="text-mist-300">animes</span></p>
          <h1 className="mt-2 font-display text-[clamp(1.7rem,3.6vw,2.4rem)] leading-none font-extrabold tracking-[-0.02em] text-mist-50">
            Local library
          </h1>
          <p className="mt-2 max-w-xl text-[13.5px] text-mist-400">
            Everything the scraper has pulled off anikototv.to and persisted. {total?.n ?? 0} row(s)
            total{needle ? `, ${rows.length} matching “${needle}”` : ""}.
          </p>
        </div>

        <form method="get" className="ml-auto flex items-center gap-2">
          <input
            name="q"
            defaultValue={needle}
            placeholder="filter cached titles…"
            className="input !w-64"
            aria-label="Filter library"
          />
          <button type="submit" className="btn btn-primary">
            filter
          </button>
        </form>
      </div>

      {rows.length === 0 ? (
        <div className="panel mt-6 p-10 text-center">
          <p className="font-mono text-xs text-mist-500">
            {needle ? "no cached title matches that filter" : "the cache is empty — run a search from the console"}
          </p>
          <Link href="/" className="btn btn-primary mt-5">
            ← go scrape
          </Link>
        </div>
      ) : (
        <div className="panel mt-6 overflow-hidden">
          <table className="w-full table-mono">
            <thead>
              <tr className="border-b border-ink-700 bg-ink-850/60 text-left">
                {["id", "title", "slug", "type", "eps", "sub", "dub", "score", "updated"].map((h) => (
                  <th key={h} className="label px-3 py-2.5 font-normal">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-ink-800">
              {rows.map((row) => (
                <tr key={row.id} className="transition-colors hover:bg-ink-850/70">
                  <td className="px-3 py-2 text-ember-400">{row.id}</td>
                  <td className="max-w-[22rem] px-3 py-2">
                    <Link
                      href={`/anime/${row.slug}`}
                      className="line-clamp-1 text-mist-100 hover:text-ember-300"
                      title={row.title}
                    >
                      {row.title}
                    </Link>
                  </td>
                  <td className="max-w-[16rem] truncate px-3 py-2 text-mist-500" title={row.slug}>
                    {row.slug}
                  </td>
                  <td className="px-3 py-2 text-mist-400">{row.type ?? "—"}</td>
                  <td className="px-3 py-2 text-mist-300 tabular-nums">
                    {row.totalEpisodes || "—"}
                  </td>
                  <td className="px-3 py-2 text-signal-400 tabular-nums">{row.subCount || "—"}</td>
                  <td className="px-3 py-2 text-flare-400 tabular-nums">{row.dubCount || "—"}</td>
                  <td className="px-3 py-2 text-mist-300 tabular-nums">
                    {row.score ? row.score.toFixed(2) : "—"}
                  </td>
                  <td className="px-3 py-2 text-mist-500">{timeAgo(row.updatedAt)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

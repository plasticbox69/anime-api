import Link from "next/link";
import { getAnime, ScrapeError } from "@/lib/scraper";
import { EpisodeBrowser } from "@/components/EpisodeBrowser";
import { timeAgo } from "@/lib/format";
import { db } from "@/db";
import { sources } from "@/db/schema";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export default async function AnimePage({
  params,
  searchParams,
}: {
  params: Promise<{ slug: string }>;
  searchParams: Promise<{ force?: string }>;
}) {
  const [{ slug }, sp] = await Promise.all([params, searchParams]);
  const force = sp.force === "1" || sp.force === "true";

  let outcome: Awaited<ReturnType<typeof getAnime>> | null = null;
  let error: string | null = null;

  try {
    outcome = await getAnime(decodeURIComponent(slug), force);
  } catch (err) {
    error =
      err instanceof ScrapeError || err instanceof Error
        ? err.message
        : "could not reach the source site";
  }

  if (!outcome) {
    return (
      <div className="mx-auto w-full max-w-[1400px] px-5 py-16">
        <div className="panel mx-auto max-w-xl border-alert-500/40 p-8 text-center">
          <p className="label text-alert-400">scrape failed</p>
          <h1 className="mt-3 font-display text-2xl font-bold text-mist-50">{error}</h1>
          <p className="mt-3 font-mono text-[11.5px] leading-relaxed text-mist-400">
            The slug <code className="text-ember-300">{slug}</code> could not be resolved against
            anikototv.to. Search for the title from the console and open it again.
          </p>
          <Link href="/" className="btn btn-primary mt-6">
            ← back to console
          </Link>
        </div>
      </div>
    );
  }

  const { detail, episodes, cached } = outcome;
  const episodeIds = new Set(episodes.map((e) => e.id));

  const resolved = await db
    .select()
    .from(sources)
    .where(eq(sources.animeId, detail.id))
    .orderBy(sources.resolvedAt);
  const resolvedForThis = resolved.filter((r) => episodeIds.has(r.episodeId));
  const okCount = resolvedForThis.filter((r) => r.status === "ok").length;

  const facts: Array<[string, string | number | null | undefined]> = [
    ["type", detail.type],
    ["status", detail.status],
    ["episodes", detail.totalEpisodes || episodes.length],
    ["aired", detail.aired],
    ["premiered", detail.premiered],
    ["duration", detail.duration],
    ["rating", detail.rating],
    ["mal score", detail.score],
    ["studios", detail.studios.join(", ") || null],
  ];

  return (
    <div className="mx-auto w-full max-w-[1400px] px-5 py-7">
      <nav className="mb-5 flex items-center gap-2 font-mono text-[11px] text-mist-500">
        <Link href="/" className="hover:text-ember-400">
          console
        </Link>
        <span className="text-ink-500">/</span>
        <Link href="/library" className="hover:text-ember-400">
          library
        </Link>
        <span className="text-ink-500">/</span>
        <span className="truncate text-mist-300">{detail.slug}</span>
      </nav>

      <section className="panel overflow-hidden">
        <div className="grid gap-0 md:grid-cols-[220px_1fr]">
          <div className="relative aspect-[2/3] w-full overflow-hidden border-b border-ink-700 bg-ink-850 md:border-r md:border-b-0">
            {detail.poster ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={detail.poster}
                alt={detail.title}
                referrerPolicy="no-referrer"
                className="size-full object-cover"
              />
            ) : (
              <div className="grid size-full place-items-center font-mono text-[11px] text-mist-500">
                no poster
              </div>
            )}
          </div>

          <div className="flex flex-col gap-4 p-5">
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <span className="chip border-ember-500/40 text-ember-300">id {detail.id}</span>
                {detail.quality && <span className="chip">{detail.quality}</span>}
                {detail.subCount > 0 && <span className="chip text-signal-400">sub {detail.subCount}</span>}
                {detail.dubCount > 0 && <span className="chip text-flare-400">dub {detail.dubCount}</span>}
                <span className="chip">
                  {cached ? "served from cache" : "scraped live"}
                </span>
              </div>
              <h1 className="mt-3 font-display text-[clamp(1.6rem,3.6vw,2.6rem)] leading-[1.02] font-extrabold tracking-[-0.02em] text-mist-50">
                {detail.title}
              </h1>
              {detail.japaneseTitle && (
                <p className="mt-1.5 font-mono text-[12px] text-mist-500">{detail.japaneseTitle}</p>
              )}
              {detail.altNames && (
                <p className="mt-1 text-[12px] text-mist-500">{detail.altNames}</p>
              )}
            </div>

            {detail.genres.length > 0 && (
              <div className="flex flex-wrap gap-1.5">
                {detail.genres.map((g) => (
                  <span key={g} className="chip">
                    {g}
                  </span>
                ))}
              </div>
            )}

            <dl className="grid grid-cols-2 gap-x-6 gap-y-1.5 border-y border-ink-800 py-3 sm:grid-cols-3">
              {facts
                .filter(([, v]) => v !== null && v !== undefined && v !== "")
                .map(([k, v]) => (
                  <div key={k} className="flex items-baseline gap-2">
                    <dt className="label shrink-0">{k}</dt>
                    <dd className="truncate font-mono text-[11.5px] text-mist-200 capitalize">{String(v)}</dd>
                  </div>
                ))}
            </dl>

            {detail.synopsis && (
              <p className="max-w-3xl text-[13.5px] leading-relaxed text-mist-400">
                {detail.synopsis}
              </p>
            )}

            <div className="flex flex-wrap items-center gap-2">
              <a
                href={`${detail.url}`}
                target="_blank"
                rel="noreferrer noopener"
                className="btn"
              >
                open on source ↗
              </a>
              <Link href={`/anime/${detail.slug}?force=1`} className="btn btn-primary">
                re-scrape
              </Link>
              <span className="ml-auto font-mono text-[10.5px] text-mist-500">
                {episodes.length} episodes indexed · {okCount} playlist(s) resolved
              </span>
            </div>
          </div>
        </div>
      </section>

      <section className="mt-8">
        <div className="flex flex-wrap items-end gap-3 border-b border-ink-700 pb-3">
          <h2 className="font-display text-xl font-bold text-mist-50">Episode table</h2>
          <span className="font-mono text-[10.5px] text-mist-500">
            GET /ajax/episode/list/{detail.id}
          </span>
          <span className="ml-auto font-mono text-[10.5px] text-mist-500">
            {resolvedForThis.length > 0 &&
              `last resolved ${timeAgo(
                resolvedForThis[resolvedForThis.length - 1].resolvedAt,
              )}`}
          </span>
        </div>
        <div className="mt-4">
          <EpisodeBrowser animeSlug={detail.slug} episodes={episodes} />
        </div>
      </section>
    </div>
  );
}

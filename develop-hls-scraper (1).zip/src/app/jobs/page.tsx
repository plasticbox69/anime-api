import { desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { scrapeJobs } from "@/db/schema";
import { getStats } from "@/lib/scraper";
import { timeAgo } from "@/lib/format";
import Link from "next/link";

export const dynamic = "force-dynamic";

const KINDS = [
  "all",
  "stream",
  "reanime",
  "aniwaves",
  "map",
  "search",
  "anime",
  "servers",
  "source",
  "anipm",
  "anizone",
  "xanime",
  "animegg",
  "animotvslash",
  "trending",
] as const;

export default async function JobsPage({
  searchParams,
}: {
  searchParams: Promise<{ kind?: string }>;
}) {
  const sp = await searchParams;
  const kind = (KINDS as readonly string[]).includes(sp.kind ?? "") ? (sp.kind as string) : "all";

  const rows = await db
    .select()
    .from(scrapeJobs)
    .where(kind === "all" ? undefined : eq(scrapeJobs.kind, kind))
    .orderBy(desc(scrapeJobs.id))
    .limit(200);

  const stats = await getStats();
  const [byStatus] = await db
    .select({
      ok: sql<number>`count(*) filter (where status = 'ok')::int`,
      err: sql<number>`count(*) filter (where status <> 'ok')::int`,
    })
    .from(scrapeJobs);

  return (
    <div className="mx-auto w-full max-w-[1400px] px-5 py-8">
      <div className="flex flex-wrap items-end gap-4 border-b border-ink-700 pb-4">
        <div>
          <p className="label">postgres · table <span className="text-mist-300">scrape_jobs</span></p>
          <h1 className="mt-2 font-display text-[clamp(1.7rem,3.6vw,2.4rem)] leading-none font-extrabold tracking-[-0.02em] text-mist-50">
            Audit trail
          </h1>
          <p className="mt-2 max-w-2xl text-[13.5px] text-mist-400">
            Every request this app made to the upstream site, with its outcome and latency.
          </p>
        </div>
        <div className="ml-auto flex gap-2">
          <div className="panel px-3 py-2 text-right">
            <p className="label">ok</p>
            <p className="font-mono text-lg text-signal-400 tabular-nums">{byStatus?.ok ?? 0}</p>
          </div>
          <div className="panel px-3 py-2 text-right">
            <p className="label">failed</p>
            <p className="font-mono text-lg text-alert-400 tabular-nums">{byStatus?.err ?? 0}</p>
          </div>
          <div className="panel px-3 py-2 text-right">
            <p className="label">mean</p>
            <p className="font-mono text-lg text-mist-100 tabular-nums">{stats.avgJobMs}ms</p>
          </div>
        </div>
      </div>

      <div className="mt-5 flex flex-wrap gap-1.5">
        {KINDS.map((k) => (
          <Link
            key={k}
            href={k === "all" ? "/jobs" : `/jobs?kind=${k}`}
            className={[
              "border px-3 py-1 font-mono text-[10.5px] tracking-[0.12em] uppercase transition-colors",
              kind === k
                ? "border-ember-500 bg-ember-500/12 text-ember-300"
                : "border-ink-700 bg-ink-900 text-mist-400 hover:border-ink-500 hover:text-mist-100",
            ].join(" ")}
          >
            {k}
          </Link>
        ))}
      </div>

      <div className="panel mt-5 overflow-hidden">
        {rows.length === 0 ? (
          <p className="px-4 py-10 text-center font-mono text-xs text-mist-500">
            no jobs of this kind yet
          </p>
        ) : (
          <table className="w-full table-mono">
            <thead>
              <tr className="border-b border-ink-700 bg-ink-850/60 text-left">
                {["#", "status", "kind", "target", "items", "duration", "when", "error"].map((h) => (
                  <th key={h} className="label px-3 py-2.5 font-normal">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-ink-800">
              {rows.map((job) => (
                <tr key={job.id} className="align-top transition-colors hover:bg-ink-850/70">
                  <td className="px-3 py-2 text-mist-500 tabular-nums">{job.id}</td>
                  <td className="px-3 py-2">
                    <span
                      className={[
                        "inline-flex items-center gap-1.5 text-[11px]",
                        job.status === "ok" ? "text-signal-400" : "text-alert-400",
                      ].join(" ")}
                    >
                      <span
                        className={[
                          "size-1.5 rounded-full",
                          job.status === "ok" ? "bg-signal-500" : "bg-alert-500",
                        ].join(" ")}
                      />
                      {job.status}
                    </span>
                  </td>
                  <td className="px-3 py-2 text-ember-400">{job.kind}</td>
                  <td className="max-w-[20rem] truncate px-3 py-2 text-mist-200" title={job.target}>
                    {job.target}
                  </td>
                  <td className="px-3 py-2 text-mist-300 tabular-nums">{job.items}</td>
                  <td className="px-3 py-2 text-mist-300 tabular-nums">{job.durationMs}ms</td>
                  <td className="px-3 py-2 whitespace-nowrap text-mist-500">
                    {timeAgo(job.createdAt)}
                  </td>
                  <td className="max-w-[24rem] px-3 py-2 text-[10.5px] break-words text-alert-400/80">
                    {job.error ?? ""}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

import { NextResponse } from "next/server";
import { fail } from "./api";
import { relayPlaylist } from "./hls";
import { GENERIC_SITES } from "./providers/generic";
import { BROWSER_SITES } from "./providers/browser";
import {
  getStream,
  type AudioType,
  type ProviderSelection,
  type Strategy,
} from "./stream";

const CORS = { "access-control-allow-origin": "*" };

/** The origin the client actually used (honours the preview proxy headers). */
export function publicOrigin(request: Request): string {
  const url = new URL(request.url);
  const host = request.headers.get("x-forwarded-host") ?? request.headers.get("host");
  const proto = request.headers.get("x-forwarded-proto") ?? url.protocol.replace(":", "");
  if (!host) return url.origin;
  return `${proto.split(",")[0].trim()}://${host.split(",")[0].trim()}`;
}

export interface RawStreamParams {
  anilist: string | null;
  episode: string | null;
  type: string | null;
  provider?: string | null;
  strategy: string | null;
  force: string | null;
  format: string | null;
}

function badRequest(message: string) {
  return NextResponse.json({ ok: false, error: message, statusCode: 400 }, { status: 400, headers: CORS });
}

function parseProviderParam(raw: string | null | undefined): ProviderSelection | null {
  if (!raw) return "anikoto";
  const clean = raw.trim().toLowerCase();
  if (clean === "anikoto" || clean === "anikototv" || clean === "anikototv.to") return "anikoto";
  if (clean === "reanime" || clean === "reanime.to" || clean === "flix" || clean === "flixcloud") {
    return "reanime";
  }
  if (clean === "aniwaves" || clean === "aniwaves.ru" || clean === "aniwave") return "aniwaves";
  if (clean === "anipm" || clean === "ani.pm") return "anipm";
  if (clean === "anizone" || clean === "anizone.to") return "anizone";
  if (clean === "xanime" || clean === "xanime.me") return "xanime";
  if (clean === "animegg" || clean === "animegg.org") return "animegg";
  if (clean === "animotvslash" || clean === "animotvslash.org") return "animotvslash";
  if (clean === "xmark") return "xmark";
  if (clean === "kaa" || clean === "kaa.lt" || clean === "kickassanime") return "kaa";
  if (clean === "atv" || clean === "animetvplus" || clean === "animetvplus.xyz") return "atv";
  if (clean === "auto" || clean === "any") return "auto";
  const browserSite = BROWSER_SITES.find((g) => g.id === clean || g.host === clean);
  if (browserSite) return browserSite.id;
  const generic = GENERIC_SITES.find((g) => g.id === clean || g.host === clean);
  if (generic) return generic.id;
  return null;
}

/**
 * Shared implementation behind `/api/stream` and `/api/stream/[id]/[ep]`.
 *
 * format=json      (default) full payload: m3u8, `/proxy/hls` URL, subtitles, mapping
 * format=m3u8      self-contained playlist with absolute `/proxy/hls` URLs (VLC/mpv)
 * format=redirect  302 to the signed `/proxy/hls` URL
 */
export async function handleStream(request: Request, raw: RawStreamParams) {
  const anilistId = Number((raw.anilist ?? "").trim());
  if (!Number.isInteger(anilistId) || anilistId <= 0) {
    return badRequest("anilist id must be a positive integer, e.g. 21");
  }
  if (anilistId > 10_000_000) {
    return badRequest("anilist id is out of range — AniList ids are well below 10,000,000");
  }

  let episodeRaw = (raw.episode ?? "").trim();
  let format = (raw.format ?? "json").toLowerCase();
  if (/\.m3u8$/i.test(episodeRaw)) {
    episodeRaw = episodeRaw.replace(/\.m3u8$/i, "");
    format = "m3u8";
  }
  const episode = Number(episodeRaw || "1");
  if (!Number.isInteger(episode) || episode < 1 || episode > 5000) {
    return badRequest("episode must be an integer between 1 and 5000");
  }

  const provider = parseProviderParam(raw.provider);
  if (!provider) {
    return badRequest(
      `provider must be one of: anikoto, reanime, aniwaves, auto, ${[...GENERIC_SITES, ...BROWSER_SITES].map((g) => g.id).join(", ")}`,
    );
  }

  const type: AudioType = raw.type?.toLowerCase() === "dub" ? "dub" : "sub";
  const strategyRaw = raw.strategy?.toLowerCase();
  const strategy: Strategy = strategyRaw === "site" || strategyRaw === "direct" ? strategyRaw : "auto";
  const force = raw.force === "1" || raw.force === "true";

  try {
    const payload = await getStream({ anilistId, episode, type, provider, strategy, force });
    const origin = publicOrigin(request);

    const qs = new URLSearchParams({ type, provider: payload.provider });
    if (strategy !== "auto" && payload.provider === "anikoto") qs.set("strategy", strategy);

    const links = {
      json: `${origin}/api/stream/${anilistId}/${episode}?${qs}`,
      playlist: `${origin}/api/stream/${anilistId}/${episode}.m3u8?${qs}`,
      proxy: `${origin}${payload.stream.proxied}`,
      probe: `${origin}${payload.stream.probe}`,
      relay: `${origin}${payload.stream.proxied}`,
      page: `${origin}/?anilist=${anilistId}&ep=${episode}&type=${type}&provider=${payload.provider}`,
    };

    if (format === "m3u8") {
      const actualAudio: "sub" | "dub" = payload.type === "dub" ? "dub" : "sub";
      const body = await relayPlaylist(payload.stream.m3u8, `${origin}/api/relay`, {
        referer: payload.stream.referer,
        manifestKey: payload.stream.manifestKey,
        proxy: {
          ref: payload.stream.referer,
          ctx: payload.stream.proxyCtx,
          exp: payload.stream.proxyExp,
          origin,
          audio: actualAudio,
        },
      });
      return new Response(body, {
        status: 200,
        headers: {
          "content-type": "application/vnd.apple.mpegurl",
          "content-disposition": `inline; filename="anilist-${anilistId}-ep${episode}-${payload.provider}-${payload.type}.m3u8"`,
          "cache-control": "no-store, max-age=0",
          ...CORS,
        },
      });
    }

    if (format === "redirect") {
      return NextResponse.redirect(links.proxy, { status: 302, headers: CORS });
    }

    return NextResponse.json(
      {
        ok: true,
        cached: payload.cached,
        at: new Date().toISOString(),
        data: { ...payload, links },
      },
      { headers: CORS },
    );
  } catch (err) {
    return fail(err);
  }
}

/**
 * Central configuration for the anikototv.to scraper.
 *
 * Every value can be overridden through environment variables so the scraper
 * keeps working when the site rotates domains, user agents or player keys.
 */

const BROWSER_UA =
  process.env.SCRAPER_USER_AGENT ??
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";

export const SITE = {
  /** Root of the site being scraped. */
  baseUrl: (process.env.ANIKOTO_BASE_URL ?? "https://anikototv.to").replace(/\/+$/, ""),
  userAgent: BROWSER_UA,
  /** Timeout applied to every outbound request. */
  timeoutMs: Number(process.env.SCRAPER_TIMEOUT_MS ?? 25000),
  /** How many times a failed request is retried. */
  retries: Number(process.env.SCRAPER_RETRIES ?? 2),
} as const;

/**
 * The embed player (MegaPlay family) guards its assets with a Referer check and
 * encrypts the playlist location with a static AES-256-CBC key/iv pair that is
 * baked into its obfuscated player bundle.
 *
 * Recovered constants:
 *   key = zero-padded "i?LMTAx0Q6,:}50U"  -> 32 bytes
 *   iv  = "W0;27ToaUpl_P%'c"              -> 16 bytes
 */
export const PLAYER = {
  embedReferer: process.env.PLAYER_EMBED_REFERER ?? "https://megaplay.buzz/",
  cdnReferer: process.env.PLAYER_CDN_REFERER ?? "https://megaplay.buzz/",
  aesKey: process.env.PLAYER_AES_KEY ?? "i?LMTAx0Q6,:}50U",
  aesIv: process.env.PLAYER_AES_IV ?? "W0;27ToaUpl_P%'c",
  /** Endpoint (relative to the embed origin) returning the encrypted sources. */
  sourcesPath: process.env.PLAYER_SOURCES_PATH ?? "/stream/getSourcesNew",
  /**
   * The same embed player can be addressed by AniList id directly. Used as a
   * fallback when a title cannot be mapped onto the site's catalogue.
   */
  directEmbedTemplate:
    process.env.PLAYER_DIRECT_TEMPLATE ?? "https://megaplay.buzz/stream/ani/{anilistId}/{episode}/{type}",
} as const;

export const ANILIST = {
  endpoint: process.env.ANILIST_GRAPHQL_URL ?? "https://graphql.anilist.co",
  timeoutMs: Number(process.env.ANILIST_TIMEOUT_MS ?? 15000),
  /** AniList metadata barely changes; avoid their strict rate limit. */
  metaTtlMs: Number(process.env.ANILIST_META_TTL_MS ?? 24 * 60 * 60 * 1000),
  /** Failed mappings are retried after this long. */
  unmatchedTtlMs: Number(process.env.ANILIST_UNMATCHED_TTL_MS ?? 30 * 60 * 1000),
  /** Minimum title similarity accepted when no MAL id can confirm a match. */
  titleThreshold: Number(process.env.ANILIST_TITLE_THRESHOLD ?? 0.9),
} as const;

export const ANIWAVES = {
  baseUrl: (process.env.ANIWAVES_BASE_URL ?? "https://aniwaves.ru").replace(/\/+$/, ""),
  embedReferer: process.env.ANIWAVES_EMBED_REFERER ?? "https://play.vhscdn.to/",
} as const;

export const REANIME = {
  baseUrl: (process.env.REANIME_BASE_URL ?? "https://reanime.to").replace(/\/+$/, ""),
  flixOrigin: (process.env.REANIME_FLIX_ORIGIN ?? "https://flixcloud.cc").replace(/\/+$/, ""),
  flixReferer: process.env.REANIME_FLIX_REFERER ?? "https://flixcloud.cc/",
} as const;

export const HLS_PROXY = {
  path: "/proxy/hls",
  secret: process.env.HLS_PROXY_SECRET ?? process.env.RELAY_SECRET ?? "anikoto-neko-hls-proxy-v1",
  /** Signature lifetime for individual `/proxy/hls` URLs (6 hours). */
  urlTtlSec: Number(process.env.HLS_PROXY_URL_TTL_SEC ?? 6 * 3600),
  /** Sealed `ctx=c1...` lifetime (12 hours). */
  ctxTtlSec: Number(process.env.HLS_PROXY_CTX_TTL_SEC ?? 12 * 3600),
} as const;

/**
 * Cache lifetimes in milliseconds. Streaming links expire quickly, metadata
 * does not.
 */
export const CACHE = {
  /** Resolved m3u8 links are short lived. */
  sourceTtlMs: Number(process.env.CACHE_SOURCE_TTL_MS ?? 4 * 60 * 60 * 1000),
  /** Episode lists change when new episodes air. */
  episodeTtlMs: Number(process.env.CACHE_EPISODE_TTL_MS ?? 6 * 60 * 60 * 1000),
  /** Anime metadata is very stable. */
  animeTtlMs: Number(process.env.CACHE_ANIME_TTL_MS ?? 7 * 24 * 60 * 60 * 1000),
  /** Trending widget. */
  trendingTtlMs: Number(process.env.CACHE_TRENDING_TTL_MS ?? 30 * 60 * 1000),
} as const;

/** Only media-looking paths may be relayed by the HLS proxy. */
export const PROXY_ALLOWED_EXTENSIONS = [
  ".m3u8",
  ".ts",
  ".m4s",
  ".mp4",
  ".vtt",
  ".srt",
  ".jpg",
  ".jpeg",
  ".png",
  ".webp",
] as const;

export function isProxyableUrl(raw: string): boolean {
  try {
    const u = new URL(raw);
    if (u.protocol !== "https:" && u.protocol !== "http:") return false;
    const path = u.pathname.toLowerCase();
    return PROXY_ALLOWED_EXTENSIONS.some((ext) => path.endsWith(ext));
  } catch {
    return false;
  }
}

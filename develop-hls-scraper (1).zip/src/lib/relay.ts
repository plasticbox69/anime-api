import { createHmac, timingSafeEqual } from "node:crypto";
import { isProxyableUrl } from "./config";

/**
 * The CDN disguises MPEG-TS segments as `.image` resources on a third-party
 * host, so an extension allowlist alone cannot describe every URL a playlist
 * legitimately references.
 *
 * Instead the relay signs every URL it hands out. A signed URL is always
 * served (we generated it ourselves), while an unsigned one must still pass the
 * media-extension allowlist. That keeps the route from becoming an open proxy.
 */
const SECRET = process.env.RELAY_SECRET ?? "anikoto-hls-relay-v1";
const BASE_PATH = "/api/relay";

export function signTarget(target: string): string {
  return createHmac("sha256", SECRET).update(target).digest("base64url").slice(0, 24);
}

export function buildRelayUrl(target: string, basePath: string = BASE_PATH): string {
  return `${basePath}?url=${encodeURIComponent(target)}&t=${signTarget(target)}`;
}

export function verifyTarget(target: string, token: string | null | undefined): boolean {
  if (!token) return false;
  const expected = Buffer.from(signTarget(target));
  const given = Buffer.from(token);
  return expected.length === given.length && timingSafeEqual(expected, given);
}

/** True when the relay is allowed to fetch this URL. */
export function isRelayAllowed(target: string, token: string | null): boolean {
  if (verifyTarget(target, token)) return true;
  return isProxyableUrl(target);
}

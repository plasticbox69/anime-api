import * as cheerio from "cheerio";
import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { sources } from "@/db/schema";
import { CACHE, SITE } from "@/lib/config";
import { candidateTitles, preferredTitle, type AnilistMedia } from "@/lib/anilist";
import { fetchJson, fetchText } from "@/lib/http";
import { dice, searchKeyword } from "@/lib/match";
import { resolveEmbedToHls } from "@/lib/player";
import { errorMessage, isFresh, ScrapeError, withJob } from "@/lib/scraper";
import type { ResolvedSource, ServerItem, SkipRange } from "@/lib/types";

/**
 * Config-driven adapter for the long tail of anime streaming sites.
 *
 * Each site is described by how it exposes three things:
 *   1. search results      -> `searchUrl` + `resultLink` regex
 *   2. episode links       -> `episodeLink` regex on the title page
 *   3. the video embed     -> `embed` regex / iframe on the episode page
 *
 * Sites that render entirely client-side (no server HTML, no public JSON API)
 * cannot be scraped without a headless browser; they are listed with
 * `enabled: false` and produce an explicit, actionable error instead of a
 * silently broken stream.
 */
export interface GenericSiteConfig {
  id: string;
  label: string;
  host: string;
  enabled: boolean;
  searchUrl: (keyword: string) => string;
  /** Regex with one capture group for the anime title path. */
  resultLink: RegExp;
  /** Regex with one capture group for the episode path on the title page. */
  episodeLink: RegExp;
  /** Regex with one capture group for the embed URL on the episode page. */
  embed: RegExp;
  /** Optional JSON API used instead of HTML scraping. */
  api?: {
    search: (keyword: string) => string;
    /** Path in the JSON response holding the result array. */
    itemsPath: string;
    titlePath: string;
    linkPath: string;
  };
  note: string;
}

const abs = (href: string, base: string) => {
  try {
    return new URL(href, base).toString();
  } catch {
    return href;
  }
};

export const GENERIC_SITES: GenericSiteConfig[] = [
  {
    id: "senshi",
    label: "senshi.to",
    host: "senshi.to",
    enabled: false,
    searchUrl: (k) => `https://senshi.to/search?q=${encodeURIComponent(k)}`,
    resultLink: re("(/anime/[^\"?#]+)"),
    episodeLink: re("(/anime/[^\"?#]*ep[^\"?#]*)"),
    embed: re("(https?://[^\"\\'\\s<>]+(?:embed|stream|watch)[^\"\\'\\s<>]*)"),
    note: "SvelteKit SPA behind Cloudflare — no server HTML or public JSON API",
  },
  {
    id: "mmani",
    label: "mmani.com",
    host: "mmani.com",
    enabled: false,
    searchUrl: (k) => `https://mmani.com/search?q=${encodeURIComponent(k)}`,
    resultLink: re("(/[^\"?#]*(?:anime|watch)[^\"?#]*)"),
    episodeLink: re("(/[^\"?#]*(?:episode|ep-)[^\"?#]*)"),
    embed: re("(https?://[^\"\\'\\s<>]+(?:embed|stream|watch)[^\"\\'\\s<>]*)"),
    note: "Client-rendered catalogue; embeds live on play.ani69.com",
  },
  {
    id: "gotaku",
    label: "gotaku.to",
    host: "gotaku.to",
    enabled: false,
    searchUrl: (k) => `https://gotaku.to/search?q=${encodeURIComponent(k)}`,
    resultLink: re("(/[^\"?#]*(?:anime|watch)[^\"?#]*)"),
    episodeLink: re("(/[^\"?#]*(?:episode|ep-)[^\"?#]*)"),
    embed: re("(https?://[^\"\\'\\s<>]+(?:embed|stream|watch)[^\"\\'\\s<>]*)"),
    note: "Vite SPA with an empty shell — content loads from a private API",
  },
  {
    id: "mkissa",
    label: "mkissa.to",
    host: "mkissa.to",
    enabled: false,
    searchUrl: (k) => `https://mkissa.to/search?q=${encodeURIComponent(k)}`,
    resultLink: re("(/[^\"?#]*(?:anime|watch)[^\"?#]*)"),
    episodeLink: re("(/[^\"?#]*(?:episode|ep-)[^\"?#]*)"),
    embed: re("(https?://[^\"\\'\\s<>]+(?:embed|stream|watch)[^\"\\'\\s<>]*)"),
    note: "SvelteKit SPA served from cdn.mkissa.net — no server HTML",
  },
  {
    id: "anisnatch",
    label: "anisnatch.to",
    host: "anisnatch.to",
    enabled: false,
    searchUrl: (k) => `https://anisnatch.to/search?q=${encodeURIComponent(k)}`,
    resultLink: re("(/[^\"?#]*(?:anime|watch)[^\"?#]*)"),
    episodeLink: re("(/[^\"?#]*(?:episode|ep-)[^\"?#]*)"),
    embed: re("(https?://[^\"\\'\\s<>]+(?:embed|stream|watch)[^\"\\'\\s<>]*)"),
    note: "Custom pako-compressed AJAX shell — payload is client-decoded",
  },
  {
    id: "2dhive",
    label: "2dhive.com",
    host: "2dhive.com",
    enabled: false,
    searchUrl: (k) => `https://2dhive.com/search?q=${encodeURIComponent(k)}`,
    resultLink: re("(/[^\"?#]*(?:anime|watch)[^\"?#]*)"),
    episodeLink: re("(/[^\"?#]*(?:episode|ep-)[^\"?#]*)"),
    embed: re("(https?://[^\"\\'\\s<>]+(?:embed|stream|watch)[^\"\\'\\s<>]*)"),
    note: "Astro static shell; playback is proxied through animealpha.cc",
  }
];

function re(pattern: string): RegExp {
  return new RegExp(pattern, "i");
}

/** All capture-group-1 matches of `pattern` in `text`. */
function findall(pattern: RegExp, text: string): string[] {
  const flags = pattern.flags.includes("g") ? pattern.flags : `${pattern.flags}g`;
  const global = new RegExp(pattern.source, flags);
    const out: string[] = [];
  let m: RegExpExecArray | null;
  while ((m = global.exec(text)) !== null) {
    out.push(m[1] ?? m[0]);
    if (m.index === global.lastIndex) global.lastIndex += 1;
  }
  return out;
}

export function getGenericSite(id: string): GenericSiteConfig | undefined {
  return GENERIC_SITES.find((s) => s.id === id);
}

export interface GenericMatchInfo {
  siteId: string;
  siteLabel: string;
  siteHost: string;
  animePath: string;
  title: string;
  confidence: number;
  episodePath: string | null;
  episodeTitle: string | null;
  availableEpisodes: number;
}

export interface GenericOutcome {
  resolved: ResolvedSource;
  server: ServerItem;
  match: GenericMatchInfo;
  cached: boolean;
}

function pickBest(candidates: string[], targets: string[]): { path: string; score: number } | null {
  let best: { path: string; score: number } | null = null;
  for (const path of candidates) {
    const slug = path.replace(/\/+$/, "").split("/").pop() ?? path;
    const score = Math.max(...targets.map((t) => dice(t, slug.replace(/-/g, " "))));
    if (!best || score > best.score) best = { path, score };
  }
  return best;
}

/** Searches one generic site and returns the best matching title path. */
async function searchGenericSite(
  site: GenericSiteConfig,
  media: AnilistMedia,
): Promise<{ path: string; title: string; score: number }> {
  const targets = candidateTitles(media);
  const keyword = searchKeyword(targets[0] ?? preferredTitle(media));

  if (site.api) {
    try {
      const json = (await fetchJson<Record<string, unknown>>(site.api.search(keyword), {
        referer: `https://${site.host}/`,
      })) as Record<string, unknown>;
      const items = json[site.api.itemsPath];
      if (Array.isArray(items) && items.length) {
        const paths: string[] = [];
        const titles: string[] = [];
        for (const item of items) {
          if (!item || typeof item !== "object") continue;
          const rec = item as Record<string, unknown>;
          const link = rec[site.api.linkPath];
          if (typeof link === "string" && link) paths.push(link);
          const title = rec[site.api.titlePath];
          if (typeof title === "string") titles.push(title);
        }
        const best = pickBest(paths, targets);
        if (best && best.score >= 0.55) {
          return { path: best.path, title: titles[0] ?? best.path, score: best.score };
        }
      }
    } catch {
      /* fall through to HTML */
    }
  }

  const html = await fetchText(site.searchUrl(keyword), { referer: `https://${site.host}/` });
  let hrefs = Array.from(new Set(findall(site.resultLink, html)));
  if (!hrefs.length) {
    // Fallback: any internal link that looks like a title page.
    hrefs = Array.from(
      new Set(
        findall(new RegExp(`(/[^"?#]*(?:anime|title|series|watch|show)[^"?#]*)"`, "i"), html),
      ),
    );
  }
  const paths = hrefs
    .map((m) => (m.startsWith("http") ? m : abs(m, `https://${site.host}`)))
    .filter((u) => u.includes(`/${site.id === "anipm" ? "anime" : ""}`) || true);

  const best = pickBest(paths, targets);
  if (!best || best.score < 0.5) {
    throw new ScrapeError(
      `${site.label} returned no confident match for “${preferredTitle(media)}”`,
      404,
    );
  }
  return { path: best.path, title: best.path, score: best.score };
}

function normaliseSkip(value: unknown): SkipRange | null {
  if (!value) return null;
  if (Array.isArray(value)) {
    const [s, e] = value as number[];
    if (typeof s === "number" && typeof e === "number" && (s > 0 || e > 0)) return { start: s, end: e };
    return null;
  }
  if (typeof value === "object") {
    const rec = value as Record<string, unknown>;
    const start = Number(rec.start);
    const end = Number(rec.end);
    if (Number.isFinite(start) && Number.isFinite(end) && (start > 0 || end > 0)) {
      return { start, end };
    }
  }
  return null;
}

/** Extracts the first playable embed URL from an episode page. */
async function extractEmbed(episodeUrl: string, site: GenericSiteConfig): Promise<string> {
  const html = await fetchText(episodeUrl, { referer: `https://${site.host}/` });

  // 1. direct m3u8 in the page
  const m3u8 = html.match(/(https?:\/\/[^\s"'<>]+?\.m3u8[^\s"'<>]*)/i);
  if (m3u8) return m3u8[1].replace(/\\\//g, "/");

  // 2. iframe src
  const $ = cheerio.load(html);
  const iframeSrc = $("iframe").first().attr("src");
  if (iframeSrc) return abs(iframeSrc, episodeUrl);

  // 3. configured embed regex
  let found = findall(site.embed, html);
  if (!found.length) {
    found = Array.from(
      new Set(
        findall(new RegExp('(?:src|href)="(https?://[^"]+)"', "i"), html).filter((u) =>
          /embed|stream|watch|player|video|cdn/i.test(u),
        ),
      ),
    );
  }
  for (const candidate of found) {
    if (candidate && !candidate.includes("anikototv") && candidate.length > 12) {
      return candidate.replace(/\\\//g, "/");
    }
  }

  throw new ScrapeError(`${site.label} episode page exposed no embed URL`, 502);
}

/**
 * Resolves an AniList id + episode through one of the generic sites.
 */
export async function resolveGenericStream(params: {
  siteId: string;
  anilistId: number;
  episode: number;
  type: "sub" | "dub";
  media: AnilistMedia;
  force?: boolean;
}): Promise<GenericOutcome> {
  const { siteId, anilistId, episode, type, media, force = false } = params;
  const site = getGenericSite(siteId);
  if (!site) throw new ScrapeError(`unknown generic site “${siteId}”`, 404);
  if (!site.enabled) {
    throw new ScrapeError(
      `${site.label} cannot be scraped server-side: ${site.note}. Use anikototv.to, reanime.to or aniwaves.ru instead.`,
      501,
    );
  }

  const epKey = `generic:${site.id}:${anilistId}:${episode}`;

  if (!force) {
    const rows = await db
      .select()
      .from(sources)
      .where(
        and(
          eq(sources.episodeId, epKey),
          eq(sources.status, "ok"),
          eq(sources.audioType, type),
        ),
      )
      .orderBy(desc(sources.resolvedAt))
      .limit(1);
    const cached = rows[0];
    if (cached?.hlsUrl && isFresh(cached.resolvedAt, CACHE.sourceTtlMs)) {
      return {
        cached: true,
        server: {
          episodeId: epKey,
          name: cached.serverName ?? "embed",
          serverId: cached.serverId ?? "1",
          cmid: site.id,
          linkId: cached.linkId ?? "",
          type,
        },
        match: {
          siteId: site.id,
          siteLabel: site.label,
          siteHost: site.host,
          animePath: cached.cmid ?? "",
          title: preferredTitle(media),
          confidence: 1,
          episodePath: null,
          episodeTitle: null,
          availableEpisodes: media.episodes ?? episode,
        },
        resolved: {
          embedUrl: cached.embedUrl ?? "",
          embedOrigin: cached.embedUrl ? new URL(cached.embedUrl).origin : `https://${site.host}`,
          playerId: null,
          hlsUrl: cached.hlsUrl,
          referer: cached.referer ?? `https://${site.host}/`,
          posterUrl: cached.posterUrl ?? null,
          tracks: (cached.tracks ?? []) as ResolvedSource["tracks"],
          intro:
            cached.introStart != null || cached.introEnd != null
              ? { start: cached.introStart, end: cached.introEnd }
              : null,
          outro:
            cached.outroStart != null || cached.outroEnd != null
              ? { start: cached.outroStart, end: cached.outroEnd }
              : null,
        },
      };
    }
  }

  return withJob<GenericOutcome>("generic", `${site.label} · anilist ${anilistId} · ep ${episode}`, async () => {
    const found = await searchGenericSite(site, media);
    const animeUrl = abs(found.path, `https://${site.host}`);

    const titleHtml = await fetchText(animeUrl, { referer: `https://${site.host}/` });
    let episodeHrefs = Array.from(new Set(findall(site.episodeLink, titleHtml)));
    if (!episodeHrefs.length) {
      episodeHrefs = Array.from(
        new Set(findall(new RegExp('([^"?#]*(?:episode|ep-|/ep/)[^"?#]*)"', "i"), titleHtml)),
      );
    }
    if (!episodeHrefs.length) {
      throw new ScrapeError(`${site.label} title page exposed no episode links`, 502);
    }

    const numbered = episodeHrefs
      .map((href) => {
        const absHref = abs(href, animeUrl);
        const m = absHref.match(/(?:episode|ep-)(\d+(?:\.\d+)?)/i) ?? absHref.match(/-(\d+(?:\.\d+)?)(?:\/|$)/);
        return { href: absHref, num: m ? Number(m[1]) : null };
      })
      .filter((e) => e.num !== null) as Array<{ href: string; num: number }>;

    const target =
      numbered.find((e) => e.num === episode) ??
      numbered.find((e) => Math.round(e.num) === episode) ??
      numbered[0];
    if (!target) {
      throw new ScrapeError(`${site.label} has no episode ${episode}`, 404);
    }

    const episodeUrl = target.href;
    const embedUrl = await extractEmbed(episodeUrl, site);

    let resolved: ResolvedSource;
    if (/\.m3u8($|\?)/i.test(embedUrl)) {
      resolved = {
        embedUrl,
        embedOrigin: new URL(embedUrl).origin,
        playerId: null,
        hlsUrl: embedUrl,
        referer: `https://${site.host}/`,
        tracks: [],
        intro: null,
        outro: null,
      };
    } else {
      resolved = await resolveEmbedToHls(embedUrl);
    }

    await db.insert(sources).values({
      episodeId: epKey,
      animeId: null,
      anilistId: String(anilistId),
      episodeNumber: String(episode),
      provider: site.id,
      audioType: type,
      strategy: "site",
      serverName: "embed",
      serverId: "1",
      cmid: site.id,
      linkId: embedUrl,
      embedUrl,
      hlsUrl: resolved.hlsUrl,
      posterUrl: resolved.posterUrl ?? null,
      referer: resolved.referer,
      introStart: resolved.intro?.start ?? null,
      introEnd: resolved.intro?.end ?? null,
      outroStart: resolved.outro?.start ?? null,
      outroEnd: resolved.outro?.end ?? null,
      tracks: resolved.tracks,
      status: "ok",
    });

    return {
      value: {
        resolved,
        cached: false,
        server: {
          episodeId: epKey,
          name: "embed",
          serverId: "1",
          cmid: site.id,
          linkId: embedUrl,
          type,
        },
        match: {
          siteId: site.id,
          siteLabel: site.label,
          siteHost: site.host,
          animePath: animeUrl,
          title: found.title,
          confidence: Number(found.score.toFixed(3)),
          episodePath: episodeUrl,
          episodeTitle: null,
          availableEpisodes: numbered.length,
        },
      },
      items: 1,
    };
  });
}

export { SITE };

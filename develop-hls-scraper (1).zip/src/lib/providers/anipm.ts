import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { sources } from "@/db/schema";
import { CACHE, SITE } from "@/lib/config";
import { candidateTitles, preferredTitle, type AnilistMedia } from "@/lib/anilist";
import { fetchJson, fetchRaw } from "@/lib/http";
import { dice, searchKeyword } from "@/lib/match";

/** Fetches JSON while forwarding any Set-Cookie from prior requests. */
async function fetchJsonWithCookies<T>(url: string, referer: string, cookieJar: Map<string, string>): Promise<T> {
  const cookieHeader = [...cookieJar.entries()].map(([k, v]) => `${k}=${v}`).join("; ");
  const res = await fetchRaw(url, {
    referer,
    headers: {
      Accept: "application/json, text/plain, */*",
      "Accept-Language": "en-US,en;q=0.9",
      "Cache-Control": "no-cache",
      Origin: new URL(referer).origin,
      "Sec-Fetch-Dest": "empty",
      "Sec-Fetch-Mode": "cors",
      "Sec-Fetch-Site": "same-origin",
      ...(cookieHeader ? { Cookie: cookieHeader } : {}),
    },
    timeoutMs: 20000,
  });
  const setCookies = res.headers.getSetCookie?.() ?? [];
  for (const sc of setCookies) {
    const [pair] = sc.split(";");
    const eq = pair.indexOf("=");
    if (eq > 0) cookieJar.set(pair.slice(0, eq).trim(), pair.slice(eq + 1).trim());
  }
  return (await res.json()) as T;
}
import { isFresh, ScrapeError, withJob } from "@/lib/scraper";
import type { ResolvedSource, ServerItem, SkipRange } from "@/lib/types";

const ANIPM_BASE = "https://ani.pm";

/** Recursively finds the first .m3u8 URL in a JSON object. */
function findM3u8(obj: unknown): string | null {
  if (typeof obj === "string" && /\.m3u8/i.test(obj)) return obj;
  if (Array.isArray(obj)) {
    for (const v of obj) { const r = findM3u8(v); if (r) return r; }
  } else if (obj && typeof obj === "object") {
    for (const v of Object.values(obj as Record<string, unknown>)) { const r = findM3u8(v); if (r) return r; }
  }
  return null;
}

interface AniPmSearchItem {
  id: number;
  source: string;
  slug: string;
  title: string;
  native?: string;
  episodeCount?: number;
  subCount?: number;
  dubCount?: number;
  malId?: number;
  anilistId?: number;
}

interface AniPmBootstrap {
  settlarSelection?: string;
  source?: string;
  id?: number;
  skip?: {
    op?: { start: number; end: number };
    ed?: { start: number; end: number };
  };
}

interface AniPmSessionResponse {
  embedUrl?: string;
}

interface SettlarEmbedSession {
  source?: string;
  title?: string;
  provider?: string;
  kind?: string;
  subtitles?: Array<{
    url: string;
    label?: string;
    lang?: string;
    default?: boolean;
  }>;
}

export interface AniPmOutcome {
  resolved: ResolvedSource;
  server: ServerItem;
  actualType: "sub" | "dub";
  typeFallback: boolean;
  match: {
    animeId: string;
    slug: string;
    title: string;
    method: string;
    confidence: number;
    siteUrl: string;
    availableEpisodes: number;
  };
  cached: boolean;
}

/**
 * Searches `ani.pm/api/anime/search?q={keyword}` and returns the matching item.
 */
async function searchAniPm(media: AnilistMedia): Promise<{ item: AniPmSearchItem; confidence: number }> {
  // 1. Keyword search first — returns the internal (settlar) item with its
  //    `source` ("settlar") and numeric `id`, which is what playback-bootstrap
  //    expects. The /anime/ani/{anilistId} endpoint returns an AniList-sourced
  //    meta object that is NOT a valid playback target.
  const targets = candidateTitles(media);
  const keyword = searchKeyword(targets[0] ?? preferredTitle(media));

  const searchRes = await fetchRaw(`${ANIPM_BASE}/api/anime/search?q=${encodeURIComponent(keyword)}`, {
    referer: `${ANIPM_BASE}/`,
    headers: {
      Accept: "application/json, text/plain, */*",
      "Accept-Language": "en-US,en;q=0.9",
      Origin: ANIPM_BASE,
      "Sec-Fetch-Dest": "empty",
      "Sec-Fetch-Mode": "cors",
      "Sec-Fetch-Site": "same-origin",
    },
    timeoutMs: 15000,
  });
  if (!searchRes.ok) throw new ScrapeError(`ani.pm search HTTP ${searchRes.status} for ${searchRes.url}`, 502);
  const json = (await searchRes.json()) as { items?: AniPmSearchItem[] };

  const items = json.items ?? [];
  if (items.length) {
    // Exact MAL or AniList ID match wins
    for (const it of items) {
      if (media.idMal && it.malId && String(it.malId) === String(media.idMal)) {
        return { item: it, confidence: 1 };
      }
      const itAni = Number(it.anilistId);
      if (Number.isFinite(itAni) && itAni === media.id) {
        return { item: it, confidence: 1 };
      }
    }

    // Fuzzy title match
    let best: { item: AniPmSearchItem; score: number } | null = null;
    for (const it of items) {
      const titleScore = Math.max(...targets.map((t) => Math.max(dice(t, it.title), dice(t, it.slug.replace(/-/g, " ")))));
      if (!best || titleScore > best.score) best = { item: it, score: titleScore };
    }

    if (best && best.score >= 0.45) {
      return { item: best.item, confidence: Number(best.score.toFixed(3)) };
    }
  }

  // 2. Fallback: direct AniList meta lookup (may not be a playback target)
  try {
    const direct = await fetchJson<AniPmSearchItem>(
      `${ANIPM_BASE}/api/anime/ani/${media.id}`,
      { referer: `${ANIPM_BASE}/`, timeoutMs: 10000, retries: 1 },
    );
    if (direct && direct.id) {
      return { item: { ...direct, source: direct.source || "anilist" }, confidence: 0.9 };
    }
  } catch {
    /* no match */
  }

  throw new ScrapeError(`ani.pm returned no results for “${preferredTitle(media)}”`, 404);
}

// Keep a legacy reference so the old body is not duplicated.
export async function resolveAniPmStream(params: {
  anilistId: number;
  episode: number;
  type: "sub" | "dub";
  media: AnilistMedia;
  force?: boolean;
}): Promise<AniPmOutcome> {
  const { anilistId, episode, type, media, force = false } = params;
  const epKey = `anipm:${anilistId}:${episode}`;

  if (!force) {
    const rows = await db
      .select()
      .from(sources)
      .where(and(eq(sources.episodeId, epKey), eq(sources.status, "ok"), eq(sources.audioType, type)))
      .orderBy(desc(sources.resolvedAt))
      .limit(1);
    const cached = rows[0];
    if (cached?.hlsUrl && isFresh(cached.resolvedAt, CACHE.sourceTtlMs)) {
      return {
        cached: true,
        actualType: (cached.audioType === "dub" ? "dub" : "sub"),
        typeFallback: false,
        server: {
          episodeId: epKey,
          name: cached.serverName ?? "settlar",
          serverId: cached.serverId ?? "1",
          cmid: "anipm",
          linkId: cached.linkId ?? "",
          type: cached.audioType ?? type,
        },
        match: {
          animeId: String(cached.animeId ?? anilistId),
          slug: cached.cmid ?? String(anilistId),
          title: preferredTitle(media),
          method: "cached",
          confidence: 1,
          siteUrl: `${ANIPM_BASE}/ani/${anilistId}?ep=${episode}`,
          availableEpisodes: media.episodes ?? episode,
        },
        resolved: {
          embedUrl: cached.embedUrl ?? "",
          embedOrigin: "https://embed.settlar.io",
          playerId: null,
          hlsUrl: cached.hlsUrl,
          referer: "https://embed.settlar.io/",
          posterUrl: cached.posterUrl ?? null,
          tracks: (cached.tracks ?? []) as ResolvedSource["tracks"],
          intro: cached.introStart != null ? { start: cached.introStart, end: cached.introEnd } : null,
          outro: cached.outroStart != null ? { start: cached.outroStart, end: cached.outroEnd } : null,
        },
      };
    }
  }

  return withJob<AniPmOutcome>("anipm", `ani.pm · anilist ${anilistId} · ep ${episode} · ${type}`, async () => {
    let searchResult: { item: AniPmSearchItem; confidence: number };
    try {
      searchResult = await searchAniPm(media);
    } catch (e) {
      throw new ScrapeError(`ani.pm searchAniPm failed: ${e instanceof Error ? e.message : String(e)}`, 502);
    }
    const { item, confidence } = searchResult;
    const itemId = item.id;
    // Always use "settlar" as source — the search API returns settlar-sourced
    // items whose numeric id is what playback-bootstrap expects.
    const sourceType = "settlar";

    // 1. Playback bootstrap
    const bootUrl = `${ANIPM_BASE}/api/anime/playback-bootstrap/${sourceType}/${itemId}?ep=${episode}&lang=${type}`;
    const cookieJar = new Map<string, string>();
    // Warm up the session with the watch page so Cloudflare clears us
    try {
      // Warm up with the HTML watch page to collect Cloudflare clearance cookies
      const warmRes = await fetchRaw(`${ANIPM_BASE}/ani/${anilistId}?ep=${episode}`, {
        referer: `${ANIPM_BASE}/`,
        headers: {
          Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
          "Accept-Language": "en-US,en;q=0.9",
          "Sec-Fetch-Dest": "document",
          "Sec-Fetch-Mode": "navigate",
          "Sec-Fetch-Site": "same-origin",
          "Sec-Fetch-User": "?1",
          "Upgrade-Insecure-Requests": "1",
        },
        timeoutMs: 20000,
      });
      const setCookies = warmRes.headers.getSetCookie?.() ?? [];
      for (const sc of setCookies) {
        const [pair] = sc.split(";");
        const eq = pair.indexOf("=");
        if (eq > 0) cookieJar.set(pair.slice(0, eq).trim(), pair.slice(eq + 1).trim());
      }
    } catch { /* ignore warmup failure */ }
    const boot = await fetchJsonWithCookies<AniPmBootstrap>(bootUrl, `${ANIPM_BASE}/ani/${anilistId}?ep=${episode}`, cookieJar).catch((e) => {
      throw new ScrapeError(`ani.pm bootstrap failed for ${bootUrl}: ${e instanceof Error ? e.message : String(e)}`, 502);
    });

    const selection = boot.settlarSelection;
    if (!selection) {
      throw new ScrapeError(`ani.pm playback bootstrap returned no stream selection for ep ${episode}`, 502);
    }

    // 2. Settlar session
    const sessQs = new URLSearchParams({
      selection,
      provider: "anipm",
      ep: String(episode),
      channel: type,
      telemetry: "0",
    });
    const sessUrl = `${ANIPM_BASE}/api/anime/settlar/session?${sessQs.toString()}`;
    const sess = await fetchJsonWithCookies<AniPmSessionResponse>(sessUrl, `${ANIPM_BASE}/ani/${anilistId}?ep=${episode}`, cookieJar);

    const embedUrl = sess.embedUrl;
    if (!embedUrl) {
      throw new ScrapeError("ani.pm settlar session returned no embed URL", 502);
    }

    // The settlar session response sometimes includes the media URL directly.
    // Also try ani.pm beta-server origin/path for a direct media.settlar.io URL.
    const directM3u8 = findM3u8(sess);
    if (directM3u8) {
      const resolved: ResolvedSource = {
        embedUrl,
        embedOrigin: "https://media.settlar.io",
        playerId: null,
        hlsUrl: directM3u8,
        referer: "https://embed.settlar.io/",
        posterUrl: null,
        tracks: [],
        intro: boot.skip?.op ? { start: boot.skip.op.start, end: boot.skip.op.end } : null,
        outro: boot.skip?.ed ? { start: boot.skip.ed.start, end: boot.skip.ed.end } : null,
      };
      await db.insert(sources).values({
        episodeId: epKey, animeId: String(itemId), anilistId: String(anilistId),
        episodeNumber: String(episode), provider: "anipm", audioType: type, strategy: "site",
        serverName: "settlar-direct", serverId: "1", cmid: item.slug, linkId: embedUrl,
        embedUrl, hlsUrl: directM3u8, posterUrl: null, referer: resolved.referer,
        introStart: resolved.intro?.start ?? null, introEnd: resolved.intro?.end ?? null,
        outroStart: resolved.outro?.start ?? null, outroEnd: resolved.outro?.end ?? null,
        tracks: [], status: "ok",
      });
      return {
        value: {
          resolved, cached: false,
          server: { episodeId: epKey, name: "settlar-direct", serverId: "1", cmid: "anipm", linkId: embedUrl, type },
          actualType: type, typeFallback: false,
          match: { animeId: String(itemId), slug: item.slug, title: item.title, method: "settlar-direct", confidence, siteUrl: `${ANIPM_BASE}/ani/${anilistId}?ep=${episode}`, availableEpisodes: item.episodeCount || media.episodes || episode },
        },
        items: 1,
      };
    }

    // 3. Extract embed token and call embed.settlar.io/api/embed/session
    let token = "";
    try {
      const parsedEmbed = new URL(embedUrl);
      token = parsedEmbed.searchParams.get("t") ?? "";
    } catch {
      token = "";
    }

    if (!token) {
      throw new ScrapeError("ani.pm embed URL contains no token parameter", 502);
    }

    // Try ani.pm's own beta-server which returns qualities + direct URLs
    try {
      const betaUrl = `${ANIPM_BASE}/api/anime/beta-server/${anilistId}/qualities?ep=${episode}`;
      const betaRes = await fetchRaw(betaUrl, {
        referer: `${ANIPM_BASE}/ani/${anilistId}?ep=${episode}`,
        headers: { Accept: "application/json", Origin: ANIPM_BASE, "Sec-Fetch-Dest": "empty", "Sec-Fetch-Mode": "cors", "Sec-Fetch-Site": "same-origin" },
        timeoutMs: 15000,
      });
      if (betaRes.ok) {
        const beta = (await betaRes.json()) as Record<string, unknown>;
        const m3u8 = findM3u8(beta);
        if (m3u8) {
          const resolved: ResolvedSource = {
            embedUrl: `${ANIPM_BASE}/ani/${anilistId}?ep=${episode}`,
            embedOrigin: ANIPM_BASE,
            playerId: null,
            hlsUrl: m3u8,
            referer: `${ANIPM_BASE}/`,
            posterUrl: null,
            tracks: [],
            intro: boot.skip?.op ? { start: boot.skip.op.start, end: boot.skip.op.end } : null,
            outro: boot.skip?.ed ? { start: boot.skip.ed.start, end: boot.skip.ed.end } : null,
          };
          await db.insert(sources).values({
            episodeId: epKey, animeId: String(itemId), anilistId: String(anilistId),
            episodeNumber: String(episode), provider: "anipm", audioType: type, strategy: "site",
            serverName: "beta-server", serverId: "1", cmid: item.slug, linkId: betaUrl,
            embedUrl: resolved.embedUrl, hlsUrl: resolved.hlsUrl, posterUrl: null,
            referer: resolved.referer,
            introStart: resolved.intro?.start ?? null, introEnd: resolved.intro?.end ?? null,
            outroStart: resolved.outro?.start ?? null, outroEnd: resolved.outro?.end ?? null,
            tracks: [], status: "ok",
          });
          return {
            value: {
              resolved, cached: false,
              server: { episodeId: epKey, name: "beta-server", serverId: "1", cmid: "anipm", linkId: betaUrl, type },
              actualType: type, typeFallback: false,
              match: { animeId: String(itemId), slug: item.slug, title: item.title, method: "beta-server", confidence, siteUrl: `${ANIPM_BASE}/ani/${anilistId}?ep=${episode}`, availableEpisodes: item.episodeCount || media.episodes || episode },
            },
            items: 1,
          };
        }
      }
    } catch { /* fall through to settlar */ }

    // The embed.settlar.io token is bound to a real browser session (Cloudflare
    // + cookies), so resolve it with headless Chromium exactly like a user would.
    let m3u8Url: string | null = null;
    try {
      const pw = await import("playwright");
      const browser = await pw.chromium.launch({ args: ["--no-sandbox", "--disable-dev-shm-usage"] });
      try {
        const ctx = await browser.newContext({ userAgent: SITE.userAgent });
        const page = await ctx.newPage();
        let captured: string | null = null;
        page.on("response", async (res) => {
          const u = res.url();
          if (u.includes(".m3u8") && res.status() === 200) captured = u;
        });
        await page.goto(embedUrl, { waitUntil: "networkidle", timeout: 30000 }).catch(() => undefined);
        await page.waitForTimeout(6000);
        if (captured) m3u8Url = captured;
        // Also check the session API response body directly
        if (!m3u8Url) {
          const sess2 = await page.evaluate(async (t) => {
            try {
              const r = await fetch(`/api/embed/session?t=${encodeURIComponent(t)}`, { credentials: "include" });
              if (!r.ok) return null;
              const j = await r.json();
              return j.source || null;
            } catch { return null; }
          }, token);
          if (sess2) m3u8Url = sess2;
        }
        await ctx.close();
      } finally {
        await browser.close().catch(() => undefined);
      }
    } catch { /* fall through */ }

    if (!m3u8Url) {
      // Last resort: ani.pm beta-server gives origin+path; construct media URL
      try {
        const betaRes = await fetchRaw(`${ANIPM_BASE}/api/anime/beta-server/${anilistId}`, {
          referer: `${ANIPM_BASE}/`,
          headers: { Accept: "application/json", Origin: ANIPM_BASE, "Sec-Fetch-Dest": "empty", "Sec-Fetch-Mode": "cors", "Sec-Fetch-Site": "same-origin" },
          timeoutMs: 15000,
        });
        if (betaRes.ok) {
          const beta = (await betaRes.json()) as Record<string, unknown>;
          const found = findM3u8(beta);
          if (found) m3u8Url = found;
        }
      } catch { /* ignore */ }
    }

    if (!m3u8Url) {
      throw new ScrapeError("ani.pm: could not resolve a media URL from the settlar session", 502);
    }
    const hlsUrl: string = m3u8Url;

    const tracks: ResolvedSource["tracks"] = [] as ResolvedSource["tracks"];

    const intro: SkipRange | null = boot.skip?.op ? { start: boot.skip.op.start, end: boot.skip.op.end } : null;
    const outro: SkipRange | null = boot.skip?.ed ? { start: boot.skip.ed.start, end: boot.skip.ed.end } : null;

    const resolved: ResolvedSource = {
      embedUrl,
      embedOrigin: "https://embed.settlar.io",
      playerId: null,
      hlsUrl,
      referer: "https://embed.settlar.io/",
      posterUrl: null,
      tracks,
      intro,
      outro,
    };

    try {
      if (process.env.ANIPM_SKIP_CACHE === "1") throw new Error("skip");
      await db.insert(sources).values({
        episodeId: epKey,
        animeId: String(itemId),
        anilistId: String(anilistId),
        episodeNumber: String(episode),
        provider: "anipm",
        audioType: type,
        strategy: "site",
        serverName: "settlar",
        serverId: "1",
        cmid: item.slug,
        linkId: embedUrl,
        embedUrl,
        hlsUrl,
        posterUrl: null,
        referer: "https://embed.settlar.io/",
        introStart: intro?.start ?? null,
        introEnd: intro?.end ?? null,
        outroStart: outro?.start ?? null,
        outroEnd: outro?.end ?? null,
        tracks: JSON.parse(JSON.stringify(resolved.tracks)) as unknown[],
        status: "ok",
      });
    } catch (insertErr) {
      // Cache write failures are non-fatal — the stream is already resolved.
      console.warn("[anipm] cache insert failed (non-fatal):", insertErr instanceof Error ? insertErr.message.slice(0, 200) : insertErr);
    }

    return {
      value: {
        resolved,
        server: {
          episodeId: epKey,
          name: "settlar",
          serverId: "1",
          cmid: "anipm",
          linkId: embedUrl,
          type,
        },
        actualType: type,
        typeFallback: false,
        match: {
          animeId: String(itemId),
          slug: item.slug,
          title: item.title,
          method: "api-search",
          confidence,
          siteUrl: `${ANIPM_BASE}/ani/${anilistId}?ep=${episode}`,
          availableEpisodes: item.episodeCount || (media.episodes ?? episode),
        },
        cached: false,
      },
      items: 1,
    };
  });
}

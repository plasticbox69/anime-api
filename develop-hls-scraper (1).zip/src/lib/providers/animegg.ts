import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { sources } from "@/db/schema";
import { CACHE } from "@/lib/config";
import { candidateTitles, preferredTitle, type AnilistMedia } from "@/lib/anilist";
import { fetchJson, fetchRaw, fetchText } from "@/lib/http";
import { dice, searchKeyword } from "@/lib/match";
import { isFresh, ScrapeError, withJob } from "@/lib/scraper";
import type { ResolvedSource, ServerItem } from "@/lib/types";

const ANIMEGG_BASE = "https://www.animegg.org";

interface AnimeggSearchItem {
  id: number;
  name: string;
  url: string;
  thumbnailUrl?: string;
}

interface VideoSourceEntry {
  file: string;
  label?: string;
}

export interface AnimeggOutcome {
  resolved: ResolvedSource;
  server: ServerItem;
  actualType: "sub" | "dub";
  typeFallback: boolean;
  match: {
    animeId: string;
    slug: string;
    title: string;
    method: string;
    confidence: number;
    siteUrl: string;
    availableEpisodes: number;
  };
  cached: boolean;
}

/** Searches animegg /search/auto/?q={keyword} and returns matching item. */
async function searchAnimegg(media: AnilistMedia): Promise<{ item: AnimeggSearchItem; confidence: number }> {
  const targets = candidateTitles(media);
  const keyword = searchKeyword(targets[0] ?? preferredTitle(media));

  const items = await fetchJson<AnimeggSearchItem[]>(
    `${ANIMEGG_BASE}/search/auto/?q=${encodeURIComponent(keyword)}`,
    { referer: `${ANIMEGG_BASE}/` },
  );

  if (!items || !items.length) {
    throw new ScrapeError(`animegg.org returned no search results for “${preferredTitle(media)}”`, 404);
  }

  let best: { item: AnimeggSearchItem; score: number } | null = null;
  for (const it of items) {
    const s = Math.max(...targets.map((t) => dice(t, it.name)));
    if (!best || s > best.score) best = { item: it, score: s };
  }

  if (!best || best.score < 0.45) {
    throw new ScrapeError(`animegg.org has no confident match for “${preferredTitle(media)}”`, 404);
  }

  return { item: best.item, confidence: Number(best.score.toFixed(3)) };
}

/**
 * Resolves an AniList id + episode through `animegg.org`.
 */
export async function resolveAnimeggStream(params: {
  anilistId: number;
  episode: number;
  type: "sub" | "dub";
  media: AnilistMedia;
  force?: boolean;
}): Promise<AnimeggOutcome> {
  const { anilistId, episode, type, media, force = false } = params;
  const epKey = `animegg:${anilistId}:${episode}`;

  if (!force) {
    const rows = await db
      .select()
      .from(sources)
      .where(and(eq(sources.episodeId, epKey), eq(sources.status, "ok"), eq(sources.audioType, type)))
      .orderBy(desc(sources.resolvedAt))
      .limit(1);
    const cached = rows[0];
    if (cached?.hlsUrl && isFresh(cached.resolvedAt, CACHE.sourceTtlMs)) {
      return {
        cached: true,
        actualType: (cached.audioType === "dub" ? "dub" : "sub"),
        typeFallback: false,
        server: {
          episodeId: epKey,
          name: cached.serverName ?? "animegg",
          serverId: cached.serverId ?? "1",
          cmid: "animegg",
          linkId: cached.linkId ?? "",
          type: cached.audioType ?? type,
        },
        match: {
          animeId: String(cached.animeId ?? anilistId),
          slug: cached.cmid ?? String(anilistId),
          title: preferredTitle(media),
          method: "cached",
          confidence: 1,
          siteUrl: `${ANIMEGG_BASE}${cached.cmid}`,
          availableEpisodes: media.episodes ?? episode,
        },
        resolved: {
          embedUrl: cached.embedUrl ?? "",
          embedOrigin: cached.embedUrl ? new URL(cached.embedUrl).origin : ANIMEGG_BASE,
          playerId: null,
          hlsUrl: cached.hlsUrl,
          referer: `${ANIMEGG_BASE}/`,
          posterUrl: cached.posterUrl ?? null,
          tracks: (cached.tracks ?? []) as ResolvedSource["tracks"],
          intro: cached.introStart != null ? { start: cached.introStart, end: cached.introEnd } : null,
          outro: cached.outroStart != null ? { start: cached.outroStart, end: cached.outroEnd } : null,
        },
      };
    }
  }

  return withJob<AnimeggOutcome>("animegg", `animegg.org · anilist ${anilistId} · ep ${episode} · ${type}`, async () => {
    const { item, confidence } = await searchAnimegg(media);
    const seriesUrl = `${ANIMEGG_BASE}${item.url}`;

    // 1. Fetch series page to find episode link
    const seriesHtml = await fetchText(seriesUrl, { referer: `${ANIMEGG_BASE}/` });
    const epLinks = Array.from(new Set(
      Array.from(seriesHtml.matchAll(/href="(\/[^"?#]+-episode-\d+[^"?#]*)"/gi)).map((m) => m[1])
    ));

    const targetPattern = new RegExp(`-episode-${episode}(?:#|$)`, "i");
    const matchedEpLink = epLinks.find((l) => targetPattern.test(l)) ?? epLinks.find((l) => l.includes(`-episode-${episode}`));

    if (!matchedEpLink) {
      throw new ScrapeError(`animegg.org has no episode ${episode} for “${item.name}”`, 404);
    }

    // 2. Fetch episode page
    const cleanEpPath = matchedEpLink.split("#")[0];
    const epUrl = `${ANIMEGG_BASE}${cleanEpPath}`;
    const epHtml = await fetchText(epUrl, { referer: seriesUrl });

    // 3. Extract embed iframes (src attribute may come before or after other attrs)
    const iframes = Array.from(new Set(
      Array.from(epHtml.matchAll(/<iframe[^>]*?src="(\/embed\/\d+)"/gi)).map((m) => m[1])
    ));

    if (!iframes.length) {
      throw new ScrapeError("animegg.org episode page exposed no embed iframe", 502);
    }

    // For dub vs sub, choose the right iframe if labelled or default to first/second
    const chosenEmbedPath = type === "dub" && iframes.length > 1 ? iframes[1] : iframes[0];
    const embedUrl = `${ANIMEGG_BASE}${chosenEmbedPath}`;
    const embedHtml = await fetchText(embedUrl, { referer: epUrl });

    // 4. Extract videoSources from embed HTML
    const vsMatch = embedHtml.match(/videoSources\s*=\s*(\[[^\]]+\])/);
    if (!vsMatch) {
      throw new ScrapeError("animegg.org embed page did not contain videoSources", 502);
    }

    // Parse JS object array
    const sourcesRaw = vsMatch[1];
    const files = Array.from(sourcesRaw.matchAll(/file:\s*["']([^"']+)["']/g)).map((m) => m[1]);

    if (!files.length) {
      throw new ScrapeError("animegg.org videoSources contained no file entries", 502);
    }

    // Pick highest quality (last item is usually 1080p)
    const playPath = files[files.length - 1];
    const playUrl = `${ANIMEGG_BASE}${playPath}`;

    // 5. HEAD the /play/ URL to follow the 302 redirect to the actual CDN video.
    let finalVideoUrl = playUrl;
    try {
      const headRes = await fetchRaw(playUrl, {
        referer: embedUrl,
        headers: { Accept: "*/*" },
        timeoutMs: 15000,
        retries: 1,
      });
      // Node's fetch (undici) exposes the final URL on the response
      const effectiveUrl = (headRes as unknown as { url?: string }).url;
      if (effectiveUrl && /^https?:\/\//.test(effectiveUrl) && effectiveUrl.includes("video.mp4")) {
        finalVideoUrl = effectiveUrl;
      }
    } catch {
      /* use playUrl directly */
    }

    const resolved: ResolvedSource = {
      embedUrl,
      embedOrigin: ANIMEGG_BASE,
      playerId: null,
      hlsUrl: finalVideoUrl,
      referer: `${ANIMEGG_BASE}/`,
      posterUrl: null,
      tracks: [],
      intro: null,
      outro: null,
    };

    await db.insert(sources).values({
      episodeId: epKey,
      animeId: String(item.id),
      anilistId: String(anilistId),
      episodeNumber: String(episode),
      provider: "animegg",
      audioType: type,
      strategy: "site",
      serverName: "animegg",
      serverId: "1",
      cmid: item.url,
      linkId: embedUrl,
      embedUrl,
      hlsUrl: finalVideoUrl,
      posterUrl: null,
      referer: `${ANIMEGG_BASE}/`,
      introStart: null,
      introEnd: null,
      outroStart: null,
      outroEnd: null,
      tracks: resolved.tracks,
      status: "ok",
    });

    return {
      value: {
        resolved,
        server: {
          episodeId: epKey,
          name: "animegg",
          serverId: "1",
          cmid: item.url,
          linkId: embedUrl,
          type,
        },
        actualType: type,
        typeFallback: false,
        match: {
          animeId: String(item.id),
          slug: item.url,
          title: item.name,
          method: "auto-search",
          confidence,
          siteUrl: epUrl,
          availableEpisodes: epLinks.length || (media.episodes ?? episode),
        },
        cached: false,
      },
      items: 1,
    };
  });
}

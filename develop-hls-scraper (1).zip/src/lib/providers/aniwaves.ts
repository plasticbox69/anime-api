import * as cheerio from "cheerio";
import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { sources } from "@/db/schema";
import { ANIWAVES, CACHE } from "@/lib/config";
import { candidateTitles, preferredTitle, type AnilistMedia } from "@/lib/anilist";
import { fetchJson, fetchText } from "@/lib/http";
import { dice, scoreCandidate, searchKeyword } from "@/lib/match";
import { parseAnimeItems, parseServers } from "@/lib/parse";
import { resolveEmbedToHls } from "@/lib/player";
import { errorMessage, isFresh, ScrapeError, withJob } from "@/lib/scraper";
import type { AnimeListItem, ResolvedSource, ServerItem, SkipRange } from "@/lib/types";

interface AjaxEnvelope<T = unknown> {
  status?: number;
  message?: string;
  result?: T;
}

interface AniwavesEpisode {
  number: string;
  title: string | null;
  serverIds: string;
  hasSub: boolean;
  hasDub: boolean;
}

export interface AniwavesMatchInfo {
  animeId: string;
  slug: string;
  title: string;
  method: string;
  confidence: number;
  siteUrl: string;
  episodeTitle: string | null;
  availableEpisodes: number;
  firstEpisode: string | null;
  lastEpisode: string | null;
}

export interface AniwavesResolveOutcome {
  resolved: ResolvedSource;
  server: ServerItem;
  actualType: string;
  typeFallback: boolean;
  match: AniwavesMatchInfo;
  cached: boolean;
}

function unwrap<T>(envelope: AjaxEnvelope<T>, label: string): T {
  if (envelope && envelope.status === 200 && envelope.result !== undefined) {
    return envelope.result;
  }
  const msg = envelope?.message ? ` (${envelope.message})` : "";
  throw new ScrapeError(`aniwaves.ru refused ${label}${msg}`, 502);
}

/** Parses `aniwaves.ru`'s `ajax/episode/list/{id}` HTML (`a[data-ids][data-num]`). */
function parseAniwavesEpisodes(fragment: string): AniwavesEpisode[] {
  const $ = cheerio.load(fragment);
  const out: AniwavesEpisode[] = [];
  const seen = new Set<string>();

  $("a[data-ids][data-num]").each((_, el) => {
    const $a = $(el);
    const num = ($a.attr("data-num") ?? "").trim();
    const serverIds = ($a.attr("data-ids") ?? "").trim();
    if (!num || !serverIds || seen.has(num)) return;
    seen.add(num);

    const $li = $a.closest("li");
    const rawTitle =
      $li.attr("title") ??
      $li.attr("data-original-title") ??
      $a.attr("data-original-title") ??
      $a.attr("title") ??
      null;
    const title = rawTitle ? rawTitle.replace(/\s+/g, " ").trim() || null : null;

    out.push({
      number: num,
      title,
      serverIds,
      hasSub: $a.attr("data-sub") === "1",
      hasDub: $a.attr("data-dub") === "1",
    });
  });

  return out;
}

/**
 * Verifies a candidate on `aniwaves.ru` via its lightweight tooltip endpoint,
 * comparing `Other names` (including native Japanese title) and aired year
 * against the AniList entry so multi-season titles don't collide.
 */
async function scoreWithTooltip(
  item: AnimeListItem,
  baseScore: number,
  media: AnilistMedia,
  allTitles: string[],
): Promise<{ score: number; yearMatched: boolean }> {
  let score = baseScore;
  let yearMatched = false;

  if (media.episodes && item.totalEpisodes && media.episodes === item.totalEpisodes) {
    score = Math.min(1, score + 0.04);
  }

  try {
    const tipHtml = await fetchText(`${ANIWAVES.baseUrl}/ajax/anime/tooltip/${item.id}`, {
      referer: `${ANIWAVES.baseUrl}/`,
      xhr: true,
      timeoutMs: 10000,
      retries: 1,
    });
    const $ = cheerio.load(tipHtml);
    const otherNames: string[] = [];
    const jpAttr = $(".d-title").attr("data-jp");
    if (jpAttr) otherNames.push(jpAttr.trim());

    $(".meta-bl > div").each((_, row) => {
      const text = $(row).text().replace(/\s+/g, " ").trim();
      if (/^other names\s*:/i.test(text)) {
        const rest = text.replace(/^other names\s*:\s*/i, "");
        for (const part of rest.split(",")) {
          const clean = part.trim();
          if (clean) otherNames.push(clean);
        }
      } else if (/^aired\s*:/i.test(text)) {
        const expectedYear = media.seasonYear ?? media.startDate?.year ?? null;
        const yearMatch = text.match(/\b(19\d{2}|20\d{2})\b/);
        if (expectedYear && yearMatch) {
          if (Number(yearMatch[1]) === expectedYear) {
            yearMatched = true;
            score = Math.min(1, score + 0.06);
          } else {
            score = Math.max(0, score - 0.18);
          }
        }
      }
    });

    if (media.title.native && otherNames.some((n) => n.includes(media.title.native!))) {
      score = Math.min(1, Math.max(score, 0.96) + (yearMatched ? 0.04 : 0));
    } else {
      for (const alias of otherNames) {
        for (const target of allTitles) {
          const d = dice(target, alias);
          if (d > score) score = d;
        }
      }
    }
  } catch {
    /* tooltip enrichment is best-effort */
  }

  return { score: Number(Math.min(1, score).toFixed(3)), yearMatched };
}

/** Searches `aniwaves.ru/filter` and matches the AniList entry onto a site card. */
async function matchAniwavesTitle(media: AnilistMedia): Promise<{
  item: AnimeListItem;
  confidence: number;
  method: string;
}> {
  const targets = candidateTitles(media);
  if (!targets.length) {
    throw new ScrapeError("AniList entry has no searchable titles for aniwaves.ru", 422);
  }

  const pool = new Map<string, AnimeListItem>();
  for (const title of targets.slice(0, 3)) {
    try {
      const url = `${ANIWAVES.baseUrl}/filter?keyword=${encodeURIComponent(searchKeyword(title))}`;
      const html = await fetchText(url, { referer: `${ANIWAVES.baseUrl}/` });
      const cards = parseAnimeItems(html, ANIWAVES.baseUrl, "#list-items");
      for (const card of cards) {
        if (!pool.has(card.id)) pool.set(card.id, card);
      }
    } catch {
      continue;
    }
    const exact = [...pool.values()].some((c) => scoreCandidate(targets, c, media.format) >= 0.97);
    if (exact) break;
  }

  if (pool.size === 0) {
    throw new ScrapeError(`aniwaves.ru returned no results for “${preferredTitle(media)}”`, 404);
  }

  const prelim = [...pool.values()]
    .map((c) => ({ c, score: scoreCandidate(targets, c, media.format) }))
    .sort((a, b) => b.score - a.score);

  const topCandidates = prelim.slice(0, 3).filter((entry) => entry.score >= 0.35);
  const enriched = await Promise.all(
    topCandidates.map(async (entry) => {
      const res = await scoreWithTooltip(entry.c, entry.score, media, targets);
      return { c: entry.c, score: res.score, yearMatched: res.yearMatched };
    }),
  );
  enriched.sort((a, b) => b.score - a.score);

  const best = enriched[0] ?? (prelim[0] ? { ...prelim[0], yearMatched: false } : null);
  if (!best || best.score < 0.72) {
    const hint = best ? ` (closest: “${best.c.title}” at ${best.score.toFixed(2)})` : "";
    throw new ScrapeError(`no confident match on aniwaves.ru for “${preferredTitle(media)}”${hint}`, 404);
  }

  return {
    item: best.c,
    confidence: best.score,
    method: best.yearMatched ? "title+year" : "title-match",
  };
}

function normaliseSkip(value: unknown): SkipRange | null {
  if (!value) return null;
  if (Array.isArray(value)) {
    const [s, e] = value as number[];
    if (typeof s === "number" && typeof e === "number" && (s > 0 || e > 0)) {
      return { start: s, end: e };
    }
    return null;
  }
  if (typeof value === "object") {
    const rec = value as Record<string, unknown>;
    const start = Number(rec.start);
    const end = Number(rec.end);
    if (Number.isFinite(start) && Number.isFinite(end) && (start > 0 || end > 0)) {
      return { start, end };
    }
  }
  return null;
}

/**
 * Unwraps an `aniwaves.ru` embed URL (`play.vhscdn.to/embed-1/{sourceId}` or
 * fallback embed hosts) into a playable `master.m3u8`.
 */
async function resolveAniwavesEmbed(embedUrl: string): Promise<ResolvedSource> {
  // Normalize malformed `?v=1?asi=0` query strings emitted by `ajax/sources`.
  const cleanUrl = embedUrl.replace(/\?([^?]*)\?/, "?$1&");
  const parsed = new URL(cleanUrl);
  const origin = parsed.origin;

  // EchoVideo / VhsCDN (`play.vhscdn.to/embed-1/<hexId>`)
  const embedPathMatch = parsed.pathname.match(/^(\/embed-\d+\/)([A-Za-z0-9_-]+)/);
  if (embedPathMatch) {
    const prefix = embedPathMatch[1];
    let sourceId = embedPathMatch[2];

    type EchoSourcesPayload = {
      ok?: boolean;
      sources?: unknown;
      tracks?: Array<Record<string, unknown>>;
      intro?: unknown;
      outro?: unknown;
      image?: string;
      message?: string;
      err?: string;
    };

    let info: EchoSourcesPayload | null = null;
    try {
      info = await fetchJson<EchoSourcesPayload>(
        `${origin}${prefix}getSources?id=${encodeURIComponent(sourceId)}`,
        { referer: cleanUrl },
      );
    } catch {
      info = null;
    }

    // Fallback: inspect `#screen[data-id]` on the embed HTML if path id differed.
    if (!info || info.ok === false || !info.sources) {
      const html = await fetchText(cleanUrl, {
        referer: `${ANIWAVES.baseUrl}/`,
        timeoutMs: 15000,
        retries: 1,
      });
      const $ = cheerio.load(html);
      const domId = $("#screen").attr("data-id")?.trim();
      if (domId) sourceId = domId;
      info = await fetchJson<EchoSourcesPayload>(
        `${origin}${prefix}getSources?id=${encodeURIComponent(sourceId)}`,
        { referer: cleanUrl },
      );
    }

    if (!info || info.ok === false) {
      throw new ScrapeError(info?.message ?? info?.err ?? "EchoVideo getSources failed", 502);
    }

    let hlsUrl: string | null = null;
    if (typeof info.sources === "string" && info.sources.trim()) {
      hlsUrl = info.sources.trim();
    } else if (Array.isArray(info.sources)) {
      for (const entry of info.sources) {
        if (typeof entry === "string" && entry.trim()) {
          hlsUrl = entry.trim();
          break;
        }
        if (entry && typeof entry === "object") {
          const rec = entry as Record<string, unknown>;
          const candidate = rec.file ?? rec.src ?? rec.url;
          if (typeof candidate === "string" && candidate.trim()) {
            hlsUrl = candidate.trim();
            break;
          }
        }
      }
    } else if (info.sources && typeof info.sources === "object") {
      const rec = info.sources as Record<string, unknown>;
      const candidate = rec.file ?? rec.src ?? rec.url;
      if (typeof candidate === "string" && candidate.trim()) hlsUrl = candidate.trim();
    }

    if (!hlsUrl) {
      throw new ScrapeError("EchoVideo getSources returned an empty HLS source", 502);
    }

    const tracks: ResolvedSource["tracks"] = [];
    if (Array.isArray(info.tracks)) {
      for (const t of info.tracks) {
        if (!t || typeof t.file !== "string" || !t.file.trim()) continue;
        tracks.push({
          file: t.file.trim(),
          label: typeof t.label === "string" ? t.label : undefined,
          kind: typeof t.kind === "string" ? t.kind : "captions",
          default: t.default === true,
        });
      }
    }

    return {
      embedUrl: cleanUrl,
      embedOrigin: origin,
      playerId: sourceId.slice(0, 24),
      hlsUrl,
      referer: `${origin}/`,
      posterUrl: typeof info.image === "string" && info.image ? info.image : null,
      tracks,
      intro: normaliseSkip(info.intro),
      outro: normaliseSkip(info.outro),
    };
  }

  return resolveEmbedToHls(cleanUrl);
}

function cacheKey(anilistId: number, episode: number): string {
  return `aniwaves:${anilistId}:${episode}`;
}

/**
 * Resolves an AniList ID + episode number through `aniwaves.ru`.
 */
export async function resolveAniwavesStream(params: {
  anilistId: number;
  episode: number;
  type: "sub" | "dub";
  media: AnilistMedia;
  force?: boolean;
}): Promise<AniwavesResolveOutcome> {
  const { anilistId, episode, type, media, force = false } = params;
  const epKey = cacheKey(anilistId, episode);

  if (!force) {
    const rows = await db
      .select()
      .from(sources)
      .where(
        and(
          eq(sources.episodeId, epKey),
          eq(sources.provider, "aniwaves"),
          eq(sources.status, "ok"),
          eq(sources.audioType, type),
        ),
      )
      .orderBy(desc(sources.resolvedAt))
      .limit(1);
    const cached = rows[0];
    if (cached?.hlsUrl && isFresh(cached.resolvedAt, CACHE.sourceTtlMs)) {
      const siteSlug = cached.cmid || String(cached.animeId ?? anilistId);
      return {
        cached: true,
        actualType: cached.audioType ?? type,
        typeFallback: false,
        match: {
          animeId: cached.animeId ?? "",
          slug: siteSlug,
          title: preferredTitle(media),
          method: "cached",
          confidence: 1,
          siteUrl: `${ANIWAVES.baseUrl}/watch/${siteSlug}`,
          episodeTitle: null,
          availableEpisodes: media.episodes ?? episode,
          firstEpisode: "1",
          lastEpisode: media.episodes ? String(media.episodes) : null,
        },
        server: {
          episodeId: epKey,
          name: cached.serverName ?? "Vidplay",
          serverId: cached.serverId ?? "4",
          cmid: siteSlug,
          linkId: cached.linkId ?? "",
          type: cached.audioType ?? type,
        },
        resolved: {
          embedUrl: cached.embedUrl ?? "",
          embedOrigin: cached.embedUrl ? new URL(cached.embedUrl).origin : "https://play.vhscdn.to",
          playerId: null,
          hlsUrl: cached.hlsUrl,
          referer: cached.referer ?? ANIWAVES.embedReferer,
          posterUrl: cached.posterUrl ?? null,
          tracks: (cached.tracks ?? []) as ResolvedSource["tracks"],
          intro:
            cached.introStart != null || cached.introEnd != null
              ? { start: cached.introStart, end: cached.introEnd }
              : null,
          outro:
            cached.outroStart != null || cached.outroEnd != null
              ? { start: cached.outroStart, end: cached.outroEnd }
              : null,
        },
      };
    }
  }

  return withJob<AniwavesResolveOutcome>(
    "aniwaves",
    `anilist ${anilistId} · ep ${episode} · ${type}`,
    async () => {
      const matched = await matchAniwavesTitle(media);
      const watchReferer = `${ANIWAVES.baseUrl}/watch/${matched.item.slug}`;

      const epListBody = await fetchJson<AjaxEnvelope<string>>(
        `${ANIWAVES.baseUrl}/ajax/episode/list/${matched.item.id}`,
        { referer: watchReferer, xhr: true },
      );
      const episodes = parseAniwavesEpisodes(unwrap(epListBody, "episode list"));
      if (episodes.length === 0) {
        throw new ScrapeError(`aniwaves.ru lists no episodes for “${matched.item.title}”`, 404);
      }

      const targetEp =
        episodes.find((e) => Number(e.number) === episode) ??
        episodes.find((e) => e.number === String(episode));
      if (!targetEp) {
        const first = episodes[0]?.number ?? "1";
        const last = episodes[episodes.length - 1]?.number ?? "?";
        throw new ScrapeError(
          `episode ${episode} is not on aniwaves.ru — available episodes ${first}–${last}`,
          404,
        );
      }

      // Note: `serverIds` is already formatted as `{animeId}&eps={epNum}`.
      const serverListUrl = `${ANIWAVES.baseUrl}/ajax/server/list?servers=${targetEp.serverIds}`;
      const serverBody = await fetchJson<AjaxEnvelope<string>>(serverListUrl, {
        referer: `${watchReferer}/ep-${targetEp.number}`,
        xhr: true,
      });
      const allServers = parseServers(unwrap(serverBody, "server list"));
      if (allServers.length === 0) {
        throw new ScrapeError("aniwaves.ru advertised no streaming servers for this episode", 502);
      }

      const sameType = allServers.filter((s) => s.type === type);
      const fallbackPool = sameType.length > 0 ? sameType : allServers.filter((s) => s.type === "sub" || s.type === "dub");
      const pool = fallbackPool.length > 0 ? fallbackPool : allServers;

      // Prefer Vidplay (sv-id 4, EchoVideo HLS) first because BYFMS/DGHG are third-party file hosts.
      pool.sort((a, b) => {
        const rank = (s: ServerItem) =>
          s.serverId === "4" || /vidplay/i.test(s.name) ? 0 : 1;
        return rank(a) - rank(b);
      });

      const errors: string[] = [];
      for (const srv of pool.slice(0, 4)) {
        try {
          const srcBody = await fetchJson<
            AjaxEnvelope<{ url?: string; skip_data?: { intro?: number[]; outro?: number[] } }>
          >(
            `${ANIWAVES.baseUrl}/ajax/sources?id=${encodeURIComponent(srv.linkId)}&asi=0&autoPlay=1`,
            { referer: `${watchReferer}/ep-${targetEp.number}`, xhr: true },
          );
          const srcResult = unwrap(srcBody, "sources");
          if (!srcResult?.url) {
            throw new ScrapeError("ajax/sources returned no embed URL", 502);
          }

          const resolved = await resolveAniwavesEmbed(srcResult.url);
          const intro = resolved.intro ?? normaliseSkip(srcResult.skip_data?.intro);
          const outro = resolved.outro ?? normaliseSkip(srcResult.skip_data?.outro);
          const finalResolved: ResolvedSource = { ...resolved, intro, outro };
          const actualType = srv.type;
          const typeFallback = actualType !== type;

          await db.insert(sources).values({
            episodeId: epKey,
            animeId: matched.item.id,
            anilistId: String(anilistId),
            episodeNumber: String(episode),
            provider: "aniwaves",
            audioType: actualType,
            strategy: "site",
            serverName: srv.name,
            serverId: srv.serverId,
            cmid: matched.item.slug,
            linkId: srv.linkId,
            embedUrl: finalResolved.embedUrl,
            hlsUrl: finalResolved.hlsUrl,
            posterUrl: finalResolved.posterUrl ?? null,
            referer: finalResolved.referer,
            introStart: intro?.start ?? null,
            introEnd: intro?.end ?? null,
            outroStart: outro?.start ?? null,
            outroEnd: outro?.end ?? null,
            tracks: finalResolved.tracks,
            status: "ok",
          });

          return {
            value: {
              resolved: finalResolved,
              server: srv,
              actualType,
              typeFallback,
              cached: false,
              match: {
                animeId: matched.item.id,
                slug: matched.item.slug,
                title: matched.item.title,
                method: matched.method,
                confidence: matched.confidence,
                siteUrl: watchReferer,
                episodeTitle: targetEp.title,
                availableEpisodes: episodes.length,
                firstEpisode: episodes[0]?.number ?? null,
                lastEpisode: episodes[episodes.length - 1]?.number ?? null,
              },
            },
            items: 1,
          };
        } catch (err) {
          errors.push(`${srv.type}/${srv.name}: ${errorMessage(err)}`);
        }
      }

      throw new ScrapeError(`aniwaves.ru servers failed — ${errors.join("; ")}`, 502);
    },
  );
}

import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { sources } from "@/db/schema";
import { CACHE } from "@/lib/config";
import { candidateTitles, preferredTitle, type AnilistMedia } from "@/lib/anilist";
import { fetchJson, fetchText } from "@/lib/http";
import { scoreCandidate, searchKeyword } from "@/lib/match";
import { resolveEmbedToHls } from "@/lib/player";
import { isFresh, ScrapeError, withJob } from "@/lib/scraper";
import type { ResolvedSource, ServerItem, SkipRange } from "@/lib/types";

const ATS_BASE = "https://animotvslash.org";

export interface AnimotvslashOutcome {
  resolved: ResolvedSource;
  server: ServerItem;
  actualType: "sub" | "dub";
  typeFallback: boolean;
  match: {
    animeId: string;
    slug: string;
    title: string;
    method: string;
    confidence: number;
    siteUrl: string;
    availableEpisodes: number;
  };
  cached: boolean;
}

/** Searches animotvslash.org/?s={keyword} and returns the matched anime slug. */
async function searchAnimotvslash(
  media: AnilistMedia,
): Promise<{ animeSlug: string; title: string; confidence: number }> {
  const targets = candidateTitles(media);
  const keyword = searchKeyword(targets[0] ?? preferredTitle(media));

  const html = await fetchText(`${ATS_BASE}/?s=${encodeURIComponent(keyword)}`, {
    referer: `${ATS_BASE}/`,
    headers: {
      Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
      "Accept-Language": "en-US,en;q=0.9",
    },
  });

  // Result cards live in <article> blocks with a link to /anime/{slug}/
  const slugs = Array.from(
    new Set(
      Array.from(html.matchAll(/href="https:\/\/animotvslash\.org\/anime\/([^"?#/]+)\/?"/gi)).map(
        (m) => m[1],
      ),
    ),
  );

  if (!slugs.length) {
    throw new ScrapeError(`animotvslash.org returned no results for “${preferredTitle(media)}”`, 404);
  }

  // Compare against the primary English/romaji titles rather than all synonyms
  // so an unnumbered Season 1 never matches a `-season-2` slug via a broad synonym.
  const coreTargets = [media.title.english, media.title.romaji, preferredTitle(media)].filter(
    (v): v is string => typeof v === "string" && v.length > 0,
  );
  let best: { slug: string; score: number } | null = null;
  for (const slug of slugs) {
    const isDubSlug = /-dub$/i.test(slug);
    const cleanTitle = slug.replace(/-dub$/i, "").replace(/-/g, " ");
    let s = scoreCandidate(coreTargets, { title: cleanTitle }, media.format);
    if (isDubSlug) s -= 0.05; // prefer main entry unless only dub exists
    if (!best || s > best.score) best = { slug, score: s };
  }

  if (!best || best.score < 0.6) {
    throw new ScrapeError(
      `animotvslash.org has no confident match for “${preferredTitle(media)}” (best: ${best?.slug} @ ${best?.score.toFixed(2) ?? "0"})`,
      404,
    );
  }

  return {
    animeSlug: best.slug,
    title: best.slug.replace(/-/g, " "),
    confidence: Number(best.score.toFixed(3)),
  };
}

interface DecodedMirror {
  url: string;
  kind: "hls" | "mp4" | "kazumi" | "ats-embed" | "megaplay" | "embed";
  poster?: string | null;
}

/**
 * Decodes one mirror `<option value="{base64}">` payload into a candidate.
 *
 * - `/plyr-player/{b64}`, `/jw-player/{b64}`, `/vidstack-player/{b64}` decode
 *   to JSON `{ url, url_1080, url_720, url_480, poster }` (`cdn.videas.fr` HLS,
 *   `cdn4.videas.fr` MP4, or `rumble.com` HLS).
 * - `/apdm-embed/?apdm_player={videoId}` is Kazumi (Dailymotion HLS).
 * - `animotvslash.ru/watch/{anilistId}/{ep}` is the site's Koto embed.
 */
function decodeMirror(htmlFragment: string): DecodedMirror | null {
  const srcMatch = htmlFragment.match(/src="([^"]+)"/i);
  if (!srcMatch) return null;
  const rawSrc = srcMatch[1].replace(/&#038;/g, "&").replace(/&amp;/g, "&");

  // 1. Player wrapper: /jw-player/{tok} | /vidstack-player/{tok} | /plyr-player/{tok}
  const wrapper = rawSrc.match(/\/(?:jw-player|vidstack-player|plyr-player)\/([A-Za-z0-9+/=_-]+)/);
  if (wrapper) {
    try {
      const b64 = wrapper[1].replace(/-/g, "+").replace(/_/g, "/");
      const json = JSON.parse(Buffer.from(b64, "base64").toString("utf8")) as Record<string, unknown>;
      const poster = typeof json.poster === "string" && json.poster ? json.poster : null;
      for (const key of ["url", "url_1080", "url_720", "url_480", "url_360"]) {
        const v = json[key];
        if (typeof v === "string" && /^https?:\/\//.test(v)) {
          return {
            url: v,
            kind: /\.m3u8/i.test(v) ? "hls" : "mp4",
            poster,
          };
        }
      }
    } catch {
      return null;
    }
    return null;
  }

  // 2. Kazumi Dailymotion embed: /apdm-embed/?apdm_player={dmVideoId}
  const kazumiMatch = rawSrc.match(/[?&]apdm_player=([A-Za-z0-9]+)/i);
  if (kazumiMatch) {
    return { url: kazumiMatch[1], kind: "kazumi" };
  }

  // 3. animotvslash.ru own embed: /watch/{id}/{ep}?lang=sub&embed=1
  if (/animotvslash\.ru\/watch\//i.test(rawSrc)) {
    return { url: rawSrc, kind: "ats-embed" };
  }

  // 4. MegaPlay embed
  if (/megaplay\.buzz/i.test(rawSrc)) {
    return { url: rawSrc, kind: "megaplay" };
  }

  // 5. Direct media URL
  if (/\.m3u8(\?|$)/i.test(rawSrc)) return { url: rawSrc, kind: "hls" };
  if (/\.(mp4|mkv)(\?|$)/i.test(rawSrc)) return { url: rawSrc, kind: "mp4" };

  return { url: rawSrc, kind: "embed" };
}

/** Resolves a Kazumi (`apdm_player`) video ID via Dailymotion's player metadata JSON. */
async function resolveKazumiHls(videoId: string): Promise<{ hlsUrl: string; referer: string }> {
  const metaUrl = `https://www.dailymotion.com/player/metadata/video/${encodeURIComponent(videoId)}`;
  const meta = await fetchJson<{
    qualities?: { auto?: Array<{ type?: string; url?: string }> };
  }>(metaUrl, { referer: "https://www.dailymotion.com/", timeoutMs: 12000 });
  const m3u8 = meta?.qualities?.auto?.find((q) => q.url)?.url;
  if (!m3u8) {
    throw new Error("Kazumi Dailymotion metadata had no auto HLS URL");
  }
  return { hlsUrl: m3u8, referer: "https://www.dailymotion.com/" };
}

/**
 * Resolves the real episode URL on `animotvslash.org`.
 * Tries `https://animotvslash.org/{anime-slug}-episode-{n}/` directly first;
 * if that 404s (some WordPress posts have `-2` suffixes like `-episode-1-2/`),
 * fetches `/anime/{anime-slug}/` and picks the exact numeric episode link.
 */
async function fetchAnimotvslashEpisodePage(
  animeSlug: string,
  episode: number,
): Promise<{ episodeUrl: string; epHtml: string; totalEpisodes: number | null }> {
  const directUrl = `${ATS_BASE}/${animeSlug}-episode-${episode}/`;
  const reqHeaders = {
    Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
  };

  try {
    const html = await fetchText(directUrl, {
      referer: `${ATS_BASE}/anime/${animeSlug}/`,
      headers: reqHeaders,
    });
    if (/<option\s+value="[A-Za-z0-9+/=]{20,}"/i.test(html)) {
      return { episodeUrl: directUrl, epHtml: html, totalEpisodes: null };
    }
  } catch {
    /* fall through to anime page lookup */
  }

  const animeUrl = `${ATS_BASE}/anime/${animeSlug}/`;
  const animeHtml = await fetchText(animeUrl, {
    referer: `${ATS_BASE}/`,
    headers: reqHeaders,
  });

  const epLinks = Array.from(
    new Set(
      Array.from(
        animeHtml.matchAll(/href="(https:\/\/animotvslash\.org\/[^"?#]*episode-\d+[^"?#]*)"/gi),
      ).map((m) => m[1]),
    ),
  );

  const epNumOf = (l: string): number | null => {
    const m = l.match(/episode-(\d+)/i);
    return m ? Number(m[1]) : null;
  };
  const matched =
    epLinks.find((l) => epNumOf(l) === episode) ??
    epLinks.find((l) => epNumOf(l) !== null && Math.round(epNumOf(l)!) === episode);

  if (!matched) {
    throw new ScrapeError(`animotvslash.org has no episode ${episode} for ${animeSlug}`, 404);
  }

  const epHtml = await fetchText(matched, {
    referer: animeUrl,
    headers: reqHeaders,
  });
  return { episodeUrl: matched, epHtml, totalEpisodes: epLinks.length || null };
}

/**
 * Resolves an AniList id + episode through `animotvslash.org` using its real
 * WordPress URLs (`https://animotvslash.org/{anime-slug}-episode-{n}/`) and
 * the base64 mirror list on that page (`ANIMO-H`, `Kazumi`, `ANIMO-D`, etc.).
 */
export async function resolveAnimotvslashStream(params: {
  anilistId: number;
  episode: number;
  type: "sub" | "dub";
  media: AnilistMedia;
  force?: boolean;
}): Promise<AnimotvslashOutcome> {
  const { anilistId, episode, type, media, force = false } = params;
  const epKey = `animotvslash:${anilistId}:${episode}`;

  if (!force) {
    const rows = await db
      .select()
      .from(sources)
      .where(
        and(
          eq(sources.episodeId, epKey),
          eq(sources.provider, "animotvslash"),
          eq(sources.status, "ok"),
          eq(sources.audioType, type),
        ),
      )
      .orderBy(desc(sources.resolvedAt))
      .limit(1);
    const cached = rows[0];
    if (
      cached?.hlsUrl &&
      !cached.hlsUrl.includes("rumble.com") &&
      isFresh(cached.resolvedAt, CACHE.sourceTtlMs)
    ) {
      return {
        cached: true,
        actualType: cached.audioType === "dub" ? "dub" : "sub",
        typeFallback: false,
        server: {
          episodeId: epKey,
          name: cached.serverName ?? "ANIMO",
          serverId: cached.serverId ?? "animo",
          cmid: "animotvslash",
          linkId: cached.linkId ?? "",
          type: cached.audioType ?? type,
        },
        match: {
          animeId: String(cached.animeId ?? anilistId),
          slug: cached.cmid ?? String(anilistId),
          title: preferredTitle(media),
          method: "cached",
          confidence: 1,
          siteUrl: cached.linkId ?? `${ATS_BASE}/`,
          availableEpisodes: media.episodes ?? episode,
        },
        resolved: {
          embedUrl: cached.embedUrl ?? "",
          embedOrigin: cached.embedUrl ? new URL(cached.embedUrl).origin : ATS_BASE,
          playerId: null,
          hlsUrl: cached.hlsUrl,
          referer: cached.referer ?? `${ATS_BASE}/`,
          posterUrl: cached.posterUrl ?? null,
          tracks: (cached.tracks ?? []) as ResolvedSource["tracks"],
          intro:
            cached.introStart != null || cached.introEnd != null
              ? { start: cached.introStart, end: cached.introEnd }
              : null,
          outro:
            cached.outroStart != null || cached.outroEnd != null
              ? { start: cached.outroStart, end: cached.outroEnd }
              : null,
        },
      };
    }
  }

  return withJob<AnimotvslashOutcome>(
    "animotvslash",
    `animotvslash.org · anilist ${anilistId} · ep ${episode} · ${type}`,
    async () => {
      const { animeSlug, title, confidence } = await searchAnimotvslash(media);
      const { episodeUrl, epHtml, totalEpisodes } = await fetchAnimotvslashEpisodePage(
        animeSlug,
        episode,
      );

      // <select class="mirror"> holds base64-encoded <option value="…"> entries
      const mirrorOptions = Array.from(
        epHtml.matchAll(/<option\s+value="([A-Za-z0-9+/=]{20,})"[^>]*>([\s\S]*?)<\/option>/g),
      );

      const decoded: Array<{ label: string } & DecodedMirror> = [];
      for (const [, b64, labelHtml] of mirrorOptions) {
        let payload = "";
        try {
          payload = Buffer.from(b64, "base64").toString("utf8");
        } catch {
          continue;
        }
        const parsed = decodeMirror(payload);
        if (parsed) {
          decoded.push({ label: (labelHtml || "").replace(/\s+/g, " ").trim(), ...parsed });
        }
      }

      if (!decoded.length) {
        throw new ScrapeError(`animotvslash.org episode page exposed no playable mirror`, 502);
      }

      // Rank candidates:
      // 1. Sub vs Dub agreement
      // 2. ANIMO-H (`cdn.videas.fr` multi-quality HLS)
      // 3. Kazumi (Dailymotion multi-quality HLS)
      // 4. HD0 (`animotvslash.ru` Koto HLS)
      // 5. ANIMO-D (`cdn4.videas.fr` direct 1080p/480p MP4)
      // Skip `rumble.com` (`ANIMO-M`) because Rumble puts Cloudflare JS challenge on playlist.m3u8.
      const wantedType = type === "dub" ? /dub/i : /sub/i;
      const rank = (d: { label: string; kind: DecodedMirror["kind"]; url: string }): number => {
        if (d.url.includes("rumble.com")) return 999;
        let r = 0;
        if (wantedType.test(d.label)) r -= 40;
        if (d.kind === "hls" && d.url.includes("videas.fr")) r -= 35; // ANIMO-H
        else if (d.kind === "kazumi") r -= 30; // Kazumi HLS
        else if (d.kind === "ats-embed") r -= 25; // HD0
        else if (d.kind === "hls") r -= 20;
        else if (d.kind === "mp4") r -= 15; // ANIMO-D
        else if (d.kind === "megaplay") r -= 5;
        else r += 50;
        return r;
      };
      const ordered = [...decoded]
        .filter((d) => !d.url.includes("rumble.com") && d.kind !== "embed")
        .sort((a, b) => rank(a) - rank(b));

      const errors: string[] = [];
      for (const cand of ordered) {
        try {
          let hlsUrl = cand.url;
          let referer = `${ATS_BASE}/`;

          if (cand.kind === "hls" || cand.kind === "mp4") {
            // cdn.videas.fr returns 403 if Referer is animotvslash.org; it requires its own origin
            if (cand.url.includes("videas.fr")) {
              referer = `${new URL(cand.url).origin}/`;
            }
          } else if (cand.kind === "kazumi") {
            const km = await resolveKazumiHls(cand.url);
            hlsUrl = km.hlsUrl;
            referer = km.referer;
          } else if (cand.kind === "ats-embed") {
            const apiUrl = `https://animotvslash.ru/api/stream/sources/koto?anilistId=${anilistId}&episode=${episode}&lang=${type}`;
            const apiRes = await fetchJson<{ sources?: Array<{ url?: string }> }>(apiUrl, {
              referer: "https://animotvslash.ru/",
              timeoutMs: 12000,
            });
            const u = apiRes.sources?.find((x) => x.url)?.url;
            if (!u) throw new Error("HD0 stream API returned no source");
            hlsUrl = u;
            referer = "https://animotvslash.ru/";
          } else if (cand.kind === "megaplay") {
            const mp = await resolveEmbedToHls(cand.url);
            if (!mp.hlsUrl) throw new Error("MegaPlay mirror had no HLS URL");
            hlsUrl = mp.hlsUrl;
            referer = mp.referer;
          } else {
            continue;
          }

          const resolved: ResolvedSource = {
            embedUrl: episodeUrl,
            embedOrigin: new URL(hlsUrl).origin,
            playerId: null,
            hlsUrl,
            referer,
            posterUrl: cand.poster ?? null,
            tracks: [],
            intro: null,
            outro: null,
          };

          await db
            .insert(sources)
            .values({
              episodeId: epKey,
              animeId: animeSlug,
              anilistId: String(anilistId),
              episodeNumber: String(episode),
              provider: "animotvslash",
              audioType: type,
              strategy: "site",
              serverName: cand.label || "ANIMO",
              serverId: "animo",
              cmid: animeSlug,
              linkId: episodeUrl,
              embedUrl: episodeUrl,
              hlsUrl: resolved.hlsUrl,
              posterUrl: resolved.posterUrl ?? null,
              referer: resolved.referer,
              introStart: null,
              introEnd: null,
              outroStart: null,
              outroEnd: null,
              tracks: [],
              status: "ok",
            })
            .catch(() => undefined);

          return {
            value: {
              resolved,
              server: {
                episodeId: epKey,
                name: cand.label || "ANIMO",
                serverId: "animo",
                cmid: animeSlug,
                linkId: episodeUrl,
                type,
              },
              actualType: type,
              typeFallback: false,
              match: {
                animeId: animeSlug,
                slug: animeSlug,
                title,
                method: "wordpress-mirror",
                confidence,
                siteUrl: episodeUrl,
                availableEpisodes: totalEpisodes ?? media.episodes ?? episode,
              },
              cached: false,
            },
            items: 1,
          };
        } catch (err) {
          errors.push(`${cand.label}: ${err instanceof Error ? err.message : String(err)}`);
        }
      }

      throw new ScrapeError(
        `animotvslash.org mirrors failed — ${errors.length ? errors.join("; ") : "no playable mirrors"}`,
        502,
      );
    },
  );
}

/**
 * "xmark" — the watermark-free source exposed by animotvslash.ru's own
 * /api/stream/sources/koto endpoint (stream.animotvslash.ru CDN). Kept as a
 * separate provider so the real animotvslash.org mirror path stays distinct.
 */
export async function resolveXmarkStream(params: {
  anilistId: number;
  episode: number;
  type: "sub" | "dub";
  media: AnilistMedia;
  force?: boolean;
}): Promise<AnimotvslashOutcome> {
  const { anilistId, episode, type, media, force = false } = params;
  const epKey = `xmark:${anilistId}:${episode}`;

  if (!force) {
    const rows = await db
      .select()
      .from(sources)
      .where(
        and(
          eq(sources.episodeId, epKey),
          eq(sources.provider, "xmark"),
          eq(sources.status, "ok"),
          eq(sources.audioType, type),
        ),
      )
      .orderBy(desc(sources.resolvedAt))
      .limit(1);
    const cached = rows[0];
    if (cached?.hlsUrl && isFresh(cached.resolvedAt, CACHE.sourceTtlMs)) {
      return {
        cached: true,
        actualType: cached.audioType === "dub" ? "dub" : "sub",
        typeFallback: false,
        server: {
          episodeId: epKey,
          name: "xmark (no watermark)",
          serverId: "xmark",
          cmid: "xmark",
          linkId: cached.linkId ?? "",
          type: cached.audioType ?? type,
        },
        match: {
          animeId: "xmark",
          slug: "xmark",
          title: preferredTitle(media),
          method: "cached",
          confidence: 1,
          siteUrl: "https://animotvslash.ru/",
          availableEpisodes: media.episodes ?? episode,
        },
        resolved: {
          embedUrl: cached.embedUrl ?? "",
          embedOrigin: "https://stream.animotvslash.ru",
          playerId: null,
          hlsUrl: cached.hlsUrl,
          referer: cached.referer ?? "https://animotvslash.ru/",
          posterUrl: null,
          tracks: (cached.tracks ?? []) as ResolvedSource["tracks"],
          intro: null,
          outro: null,
        },
      };
    }
  }

  return withJob<AnimotvslashOutcome>(
    "xmark",
    `xmark · anilist ${anilistId} · ep ${episode} · ${type}`,
    async () => {
      const apiUrl = `https://animotvslash.ru/api/stream/sources/koto?anilistId=${anilistId}&episode=${episode}&lang=${type}`;
      const apiRes = await fetchJson<{
        sources?: Array<{ name?: string; url?: string }>;
        server?: string;
      }>(apiUrl, {
        referer: "https://animotvslash.ru/",
        headers: {
          Accept: "application/json",
          Origin: "https://animotvslash.ru",
          "Sec-Fetch-Dest": "empty",
          "Sec-Fetch-Mode": "cors",
          "Sec-Fetch-Site": "same-origin",
        },
        timeoutMs: 15000,
      });

      const src = apiRes.sources?.find((x: { url?: string }) => x.url) ?? apiRes.sources?.[0];
      if (!src?.url) {
        throw new ScrapeError("xmark: animotvslash.ru stream API returned no source", 404);
      }

      const hlsUrl = src.url;
      const resolved: ResolvedSource = {
        embedUrl: apiUrl,
        embedOrigin: "https://stream.animotvslash.ru",
        playerId: null,
        hlsUrl,
        referer: "https://animotvslash.ru/",
        posterUrl: null,
        tracks: [],
        intro: null,
        outro: null,
      };

      await db
        .insert(sources)
        .values({
          episodeId: epKey,
          animeId: "xmark",
          anilistId: String(anilistId),
          episodeNumber: String(episode),
          provider: "xmark",
          audioType: type,
          strategy: "site",
          serverName: "xmark (no watermark)",
          serverId: "xmark",
          cmid: "xmark",
          linkId: apiUrl,
          embedUrl: apiUrl,
          hlsUrl,
          posterUrl: null,
          referer: resolved.referer,
          introStart: null,
          introEnd: null,
          outroStart: null,
          outroEnd: null,
          tracks: [],
          status: "ok",
        })
        .catch(() => undefined);

      return {
        value: {
          resolved,
          server: {
            episodeId: epKey,
            name: "xmark (no watermark)",
            serverId: "xmark",
            cmid: "xmark",
            linkId: apiUrl,
            type,
          },
          actualType: type,
          typeFallback: false,
          match: {
            animeId: "xmark",
            slug: "xmark",
            title: preferredTitle(media),
            method: "xmark-watermark-free",
            confidence: 1,
            siteUrl: "https://animotvslash.ru/",
            availableEpisodes: media.episodes ?? episode,
          },
          cached: false,
        },
        items: 1,
      };
    },
  );
}

export type { SkipRange };

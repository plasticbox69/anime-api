import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { sources } from "@/db/schema";
import { CACHE } from "@/lib/config";
import { candidateTitles, preferredTitle, type AnilistMedia } from "@/lib/anilist";
import { fetchText } from "@/lib/http";
import { scoreCandidate, searchKeyword } from "@/lib/match";
import { isFresh, ScrapeError, withJob } from "@/lib/scraper";
import type { ResolvedSource, ServerItem } from "@/lib/types";

const ANIZONE_BASE = "https://anizone.to";

interface AnizoneSearchItem {
  slug: string;
  url: string;
  main_title: string;
  title_list?: Record<string, string>;
  type?: string;
  start_year?: number;
  episode_count?: number;
}

interface AnizoneEpisodeItem {
  slug: string;
  url: string;
  title_list?: Record<string, string>;
}

export interface AnizoneOutcome {
  resolved: ResolvedSource;
  server: ServerItem;
  actualType: "sub" | "dub";
  typeFallback: boolean;
  match: {
    animeId: string;
    slug: string;
    title: string;
    method: string;
    confidence: number;
    siteUrl: string;
    availableEpisodes: number;
  };
  cached: boolean;
}

function unescapeAnizoneString(value: string): string {
  return value
    .replace(/\\\\u([0-9a-fA-F]{4})/g, (_m, hex) => String.fromCharCode(parseInt(hex, 16)))
    .replace(/\\u([0-9a-fA-F]{4})/g, (_m, hex) => String.fromCharCode(parseInt(hex, 16)))
    .replace(/\\\\\//g, "/")
    .replace(/\\\//g, "/")
    .replace(/\\"/g, '"')
    .replace(/\\'/g, "'");
}

/**
 * Extracts items from `items: JSON.parse('...')` in anizone's Alpine `x-data`.
 * Unescapes the single-quoted JS string literal first, then parses the inner JSON.
 */
function extractItemsJson<T>(html: string): T[] {
  const m = html.match(/items:\s*JSON\.parse\('([^']+)'\)/);
  if (!m) return [];
  try {
    const jsStr = JSON.parse(`"${m[1].replace(/"/g, '\\"')}"`) as string;
    const parsed = JSON.parse(jsStr) as T[];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

/** Searches anizone.to/anime?search={keyword} and parses the embedded items. */
async function searchAnizone(
  media: AnilistMedia,
): Promise<{ item: AnizoneSearchItem; confidence: number }> {
  const targets = candidateTitles(media);
  const keyword = searchKeyword(targets[0] ?? preferredTitle(media));

  // anizone.to's search breaks on punctuation/long titles, so try the full
  // title first, then romaji, then without "Season N", then first word.
  const stripped = keyword.replace(/\b(?:season\s*\d+|\d+(?:st|nd|rd|th)\s+season)\b/gi, "").trim();
  const keywordCandidates = [
    keyword,
    searchKeyword(targets[1] ?? keyword),
    stripped,
    keyword.split(/\s+/)[0],
    searchKeyword(preferredTitle(media)).split(/\s+/)[0],
  ].filter((v, i, arr) => v && arr.indexOf(v) === i);

  let items: AnizoneSearchItem[] = [];
  for (const kw of keywordCandidates) {
    const html = await fetchText(`${ANIZONE_BASE}/anime?search=${encodeURIComponent(kw)}`, {
      referer: `${ANIZONE_BASE}/`,
    });
    const parsed = extractItemsJson<AnizoneSearchItem>(html);
    if (parsed.length) {
      items = parsed;
      break;
    }
  }

  if (!items.length) {
    throw new ScrapeError(`anizone.to returned no search results for “${preferredTitle(media)}”`, 404);
  }

  let best: { item: AnizoneSearchItem; score: number } | null = null;
  for (const it of items) {
    const titlesToCheck: string[] = [it.main_title].filter(Boolean);
    if (it.title_list) {
      titlesToCheck.push(...Object.values(it.title_list));
    }
    let maxScore = 0;
    for (const cand of titlesToCheck) {
      const s = scoreCandidate(targets, { title: cand }, media.format);
      if (s > maxScore) maxScore = s;
    }
    const expectedYear = media.seasonYear ?? media.startDate?.year ?? null;
    if (it.start_year && expectedYear) {
      if (it.start_year === expectedYear) {
        maxScore = Math.min(1, maxScore + 0.12);
      } else {
        maxScore = Math.max(0, maxScore - 0.15);
      }
    }
    if (!best || maxScore > best.score) {
      best = { item: it, score: maxScore };
    }
  }

  if (!best || best.score < 0.45) {
    throw new ScrapeError(`anizone.to has no confident match for “${preferredTitle(media)}”`, 404);
  }

  return { item: best.item, confidence: Number(best.score.toFixed(3)) };
}

/**
 * Resolves an AniList id + episode through `anizone.to`.
 */
export async function resolveAnizoneStream(params: {
  anilistId: number;
  episode: number;
  type: "sub" | "dub";
  media: AnilistMedia;
  force?: boolean;
}): Promise<AnizoneOutcome> {
  const { anilistId, episode, type, media, force = false } = params;
  const epKey = `anizone:${anilistId}:${episode}`;

  if (!force) {
    const rows = await db
      .select()
      .from(sources)
      .where(
        and(
          eq(sources.episodeId, epKey),
          eq(sources.provider, "anizone"),
          eq(sources.status, "ok"),
          eq(sources.audioType, type),
        ),
      )
      .orderBy(desc(sources.resolvedAt))
      .limit(1);
    const cached = rows[0];
    if (
      cached?.hlsUrl &&
      !cached.hlsUrl.includes("u002") &&
      isFresh(cached.resolvedAt, CACHE.sourceTtlMs)
    ) {
      return {
        cached: true,
        actualType: cached.audioType === "dub" ? "dub" : "sub",
        typeFallback: false,
        server: {
          episodeId: epKey,
          name: cached.serverName ?? "vid-cdn",
          serverId: cached.serverId ?? "1",
          cmid: "anizone",
          linkId: cached.linkId ?? "",
          type: cached.audioType ?? type,
        },
        match: {
          animeId: String(cached.animeId ?? anilistId),
          slug: cached.cmid ?? String(anilistId),
          title: preferredTitle(media),
          method: "cached",
          confidence: 1,
          siteUrl: `${ANIZONE_BASE}/anime/${cached.cmid}/${episode}`,
          availableEpisodes: media.episodes ?? episode,
        },
        resolved: {
          embedUrl: cached.embedUrl ?? "",
          embedOrigin: cached.embedUrl ? new URL(cached.embedUrl).origin : "https://seiryuu.vid-cdn.xyz",
          playerId: null,
          hlsUrl: cached.hlsUrl,
          referer: "https://anizone.to/",
          posterUrl: cached.posterUrl ?? null,
          tracks: (cached.tracks ?? []) as ResolvedSource["tracks"],
          intro:
            cached.introStart != null || cached.introEnd != null
              ? { start: cached.introStart, end: cached.introEnd }
              : null,
          outro:
            cached.outroStart != null || cached.outroEnd != null
              ? { start: cached.outroStart, end: cached.outroEnd }
              : null,
        },
      };
    }
  }

  return withJob<AnizoneOutcome>(
    "anizone",
    `anizone.to · anilist ${anilistId} · ep ${episode} · ${type}`,
    async () => {
      const { item, confidence } = await searchAnizone(media);
      const animeSlug = item.slug;
      const animeUrl = `${ANIZONE_BASE}/anime/${animeSlug}`;

      // 1. Fetch anime page to find episode list
      const animeHtml = await fetchText(animeUrl, { referer: `${ANIZONE_BASE}/` });
      const epItems = extractItemsJson<AnizoneEpisodeItem>(animeHtml);
      const targetEp =
        epItems.find((e) => String(e.slug) === String(episode)) ??
        epItems.find((e) => Number(e.slug) === episode) ??
        null;

      // 2. Episode page URL is always /anime/{slug}/{episodeNumber}
      const epNum = targetEp ? String(targetEp.slug) : String(episode);
      const epUrl = `${ANIZONE_BASE}/anime/${animeSlug}/${epNum}`;
      const epHtml = await fetchText(epUrl, { referer: animeUrl });

      // 3. Extract master.m3u8 from episode HTML (`https:\\\/\\\/host\\\/uuid\\\/master.m3u8\u0022`).
      let hlsUrl: string | null = null;
      for (const m of epHtml.matchAll(/(https?:[^\s"'<>]+?\.m3u8)/gi)) {
        const candidate = m[1]
          .replace(/\\u002F/gi, "/")
          .replace(/\\+/g, "")
          .trim();
        if (/^https:\/\/[a-z0-9.\-]+\/[^\s"'<>]+\.m3u8$/i.test(candidate)) {
          hlsUrl = candidate;
          break;
        }
      }
      if (!hlsUrl) {
        throw new ScrapeError(`anizone.to episode page did not contain an HLS stream`, 502);
      }

      // Extract subtitles if present
      const tracks: ResolvedSource["tracks"] = [];
      const subBlockMatch = epHtml.match(
        /\\(?:u0022|")subtitles\\(?:u0022|"):\[([\s\S]*?)\](?:,\\(?:u0022|")|\})/,
      );
      if (subBlockMatch) {
        const subRe =
          /\\(?:u0022|")title\\(?:u0022|"):\\(?:u0022|")([^"\\]+)\\(?:u0022|")[\s\S]{0,220}?\\(?:u0022|")file\\(?:u0022|"):\\(?:u0022|")([^"\\]+)\\(?:u0022|")/g;
        let sm: RegExpExecArray | null;
        while ((sm = subRe.exec(subBlockMatch[1])) !== null) {
          const label = unescapeAnizoneString(sm[1]);
          const file = unescapeAnizoneString(sm[2]).replace(/\\+/g, "");
          if (/^https?:\/\//i.test(file)) {
            tracks.push({ file, label, kind: "captions", default: tracks.length === 0 });
          }
        }
      }

      const resolved: ResolvedSource = {
        embedUrl: epUrl,
        embedOrigin: new URL(hlsUrl).origin,
        playerId: null,
        hlsUrl,
        referer: "https://anizone.to/",
        posterUrl: null,
        tracks,
        intro: null,
        outro: null,
      };

      await db
        .insert(sources)
        .values({
          episodeId: epKey,
          animeId: animeSlug,
          anilistId: String(anilistId),
          episodeNumber: String(episode),
          provider: "anizone",
          audioType: type,
          strategy: "site",
          serverName: "vid-cdn",
          serverId: "1",
          cmid: animeSlug,
          linkId: epUrl,
          embedUrl: epUrl,
          hlsUrl,
          posterUrl: null,
          referer: "https://anizone.to/",
          introStart: null,
          introEnd: null,
          outroStart: null,
          outroEnd: null,
          tracks: resolved.tracks,
          status: "ok",
        })
        .catch(() => undefined);

      return {
        value: {
          resolved,
          server: {
            episodeId: epKey,
            name: "vid-cdn",
            serverId: "1",
            cmid: animeSlug,
            linkId: epUrl,
            type,
          },
          actualType: type,
          typeFallback: false,
          match: {
            animeId: animeSlug,
            slug: animeSlug,
            title: item.main_title || preferredTitle(media),
            method: "alpine-search",
            confidence,
            siteUrl: epUrl,
            availableEpisodes: epItems.length || item.episode_count || (media.episodes ?? episode),
          },
          cached: false,
        },
        items: 1,
      };
    },
  );
}

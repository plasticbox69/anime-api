import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { sources } from "@/db/schema";
import { CACHE } from "@/lib/config";
import { candidateTitles, preferredTitle, type AnilistMedia } from "@/lib/anilist";
import { fetchJson, fetchText } from "@/lib/http";
import { scoreCandidate, searchKeyword } from "@/lib/match";
import { isFresh, ScrapeError, withJob } from "@/lib/scraper";
import type { ResolvedSource, ServerItem } from "@/lib/types";

const SITE_BASE = "https://animetvplus.xyz";
const CATALOG = "https://catalog.animetvplus.site";
const EMBED = "https://embed.animetvplus.site";

interface AtvCatalogItem {
  mal_id: string;
  anilist_id: number;
  canonical_title: string;
  english_title?: string;
  romaji_title?: string;
  has_m3u8?: number;
  m3u8_episode_count?: number;
  episodes_total?: number;
  current_episodes?: number;
  popularity?: number;
  trending?: number;
  cover_image?: string;
  average_score?: number;
  format?: string;
  status?: string;
}

interface AtvResolveResponse {
  ok: boolean;
  error?: string;
  source?: string;
  title?: string;
  mal?: number;
  anilist?: number;
  episode?: number;
  uqload?: { code: string; embed_url: string };
  embed?: string;
  m3u8_url?: string;
  url?: string;
}

export interface AtvOutcome {
  resolved: ResolvedSource;
  server: ServerItem;
  actualType: "sub" | "dub";
  typeFallback: boolean;
  match: {
    animeId: string;
    slug: string;
    title: string;
    method: string;
    confidence: number;
    siteUrl: string;
    availableEpisodes: number;
  };
  cached: boolean;
}

/** Searches the animetvplus catalog by title and returns the best match. */
async function searchAtv(
  media: AnilistMedia,
): Promise<{ item: AtvCatalogItem; confidence: number }> {
  const targets = candidateTitles(media);
  const keyword = searchKeyword(targets[0] ?? preferredTitle(media));

  const body = await fetchJson<{ items?: AtvCatalogItem[] }>(
    `${CATALOG}/api/search?q=${encodeURIComponent(keyword)}`,
    { referer: `${SITE_BASE}/`, timeoutMs: 15000 },
  );

  const items = body?.items ?? [];
  if (!items.length) {
    throw new ScrapeError(`animetvplus.xyz returned no results for “${preferredTitle(media)}”`, 404);
  }

  // Exact AniList/MAL id match wins immediately.
  for (const it of items) {
    if (Number(it.anilist_id) === media.id) return { item: it, confidence: 1 };
    if (media.idMal && String(it.mal_id) === String(media.idMal)) return { item: it, confidence: 1 };
  }

  let best: { item: AtvCatalogItem; score: number } | null = null;
  for (const it of items) {
    const names = [it.english_title, it.canonical_title, it.romaji_title].filter(
      (v): v is string => typeof v === "string" && v.length > 0,
    );
    let s = 0;
    for (const name of names) {
      const v = scoreCandidate(targets, { title: name }, media.format);
      if (v > s) s = v;
    }
    if (!best || s > best.score) best = { item: it, score: s };
  }

  if (!best || best.score < 0.55) {
    throw new ScrapeError(
      `animetvplus.xyz has no confident match for “${preferredTitle(media)}” (best: ${best?.item.english_title} @ ${best?.score.toFixed(2) ?? "0"})`,
      404,
    );
  }

  return { item: best.item, confidence: Number(best.score.toFixed(3)) };
}

/**
 * Resolves an AniList id + episode through `animetvplus.xyz`.
 *
 * Chain: catalog search → embed resolve (uqload code) → uqload embed page →
 * signed HLS master.m3u8 (captured from the embed player's network traffic,
 * since the CDN rejects plain HTTP fetches with 403).
 */
export async function resolveAtvStream(params: {
  anilistId: number;
  episode: number;
  type: "sub" | "dub";
  media: AnilistMedia;
  force?: boolean;
}): Promise<AtvOutcome> {
  const { anilistId, episode, type, media, force = false } = params;
  const epKey = `atv:${anilistId}:${episode}`;

  if (!force) {
    const rows = await db
      .select()
      .from(sources)
      .where(
        and(
          eq(sources.episodeId, epKey),
          eq(sources.provider, "atv"),
          eq(sources.status, "ok"),
          eq(sources.audioType, type),
        ),
      )
      .orderBy(desc(sources.resolvedAt))
      .limit(1);
    const cached = rows[0];
    if (cached?.hlsUrl && isFresh(cached.resolvedAt, CACHE.sourceTtlMs)) {
      return {
        cached: true,
        actualType: cached.audioType === "dub" ? "dub" : "sub",
        typeFallback: false,
        server: {
          episodeId: epKey,
          name: cached.serverName ?? "uqload",
          serverId: cached.serverId ?? "uqload",
          cmid: "atv",
          linkId: cached.linkId ?? "",
          type: cached.audioType ?? type,
        },
        match: {
          animeId: String(cached.animeId ?? anilistId),
          slug: cached.cmid ?? String(anilistId),
          title: preferredTitle(media),
          method: "cached",
          confidence: 1,
          siteUrl: cached.linkId ?? `${SITE_BASE}/anime/${anilistId}`,
          availableEpisodes: media.episodes ?? episode,
        },
        resolved: {
          embedUrl: cached.embedUrl ?? "",
          embedOrigin: cached.embedUrl ? new URL(cached.embedUrl).origin : "https://uqload.vc",
          playerId: null,
          hlsUrl: cached.hlsUrl,
          referer: cached.referer ?? "https://uqload.vc/",
          posterUrl: cached.posterUrl ?? null,
          tracks: (cached.tracks ?? []) as ResolvedSource["tracks"],
          intro: null,
          outro: null,
        },
      };
    }
  }

  return withJob<AtvOutcome>(
    "atv",
    `animetvplus.xyz · anilist ${anilistId} · ep ${episode} · ${type}`,
    async () => {
      const { item, confidence } = await searchAtv(media);
      const malId = Number(item.mal_id);
      const animeId = Number(item.anilist_id) || anilistId;

      // 1. Resolve the episode to an embed via embed.animetvplus.site
      const resolveUrl = `${EMBED}/home/api/v1/resolve?mal=${malId}&ep=${episode}`;
      const resolved = await fetchJson<AtvResolveResponse>(resolveUrl, {
        referer: `${SITE_BASE}/watch/x/${episode}`,
        timeoutMs: 15000,
      });

      if (!resolved?.ok) {
        throw new ScrapeError(
          `animetvplus.xyz has no stream for “${item.english_title ?? item.canonical_title}” episode ${episode} (${resolved?.error ?? "unknown_title"})`,
          404,
        );
      }

      const uqCode = resolved.uqload?.code;
      if (!uqCode) {
        throw new ScrapeError("animetvplus.xyz resolve returned no uqload code", 502);
      }

      // 2. Load the uqload embed page in headless Chromium and capture the
      //    signed HLS master URL from the network log (the CDN 403s plain
      //    fetches; the token is bound to the embed page's session).
      let hlsUrl: string | null = null;
      try {
        const pw = await import("playwright");
        const browser = await pw.chromium.launch({
          args: ["--no-sandbox", "--disable-dev-shm-usage"],
        });
        try {
          const ctx = await browser.newContext({ userAgent: undefined });
          const page = await ctx.newPage();
          page.on("response", (res) => {
            const u = res.url();
            const ct = (res.headers()["content-type"] ?? "").toLowerCase();
            if (
              res.status() === 200 &&
              (ct.includes("mpegurl") || /\.m3u8(\?|$)/i.test(u)) &&
              u.includes("/master.m3u8")
            ) {
              hlsUrl = u;
            }
          });
          await page.goto(`https://uqload.vc/embed-${uqCode}.html`, {
            waitUntil: "networkidle",
            timeout: 30000,
          });
          await page.waitForTimeout(6000);
          await ctx.close();
        } finally {
          await browser.close().catch(() => undefined);
        }
      } catch {
        /* fall through */
      }

      if (!hlsUrl) {
        throw new ScrapeError(
          `animetvplus.xyz: could not capture HLS URL for uqload code ${uqCode}`,
          502,
        );
      }

      const resolvedSource: ResolvedSource = {
        embedUrl: `${SITE_BASE}/watch/x/${episode}`,
        embedOrigin: new URL(hlsUrl).origin,
        playerId: uqCode,
        hlsUrl,
        referer: "https://uqload.vc/",
        posterUrl: item.cover_image ?? null,
        tracks: [],
        intro: null,
        outro: null,
      };

      await db
        .insert(sources)
        .values({
          episodeId: epKey,
          animeId: String(animeId),
          anilistId: String(anilistId),
          episodeNumber: String(episode),
          provider: "atv",
          audioType: type,
          strategy: "site",
          serverName: "uqload",
          serverId: "uqload",
          cmid: String(malId),
          linkId: `${SITE_BASE}/anime/${animeId}`,
          embedUrl: `https://uqload.vc/embed-${uqCode}.html`,
          hlsUrl,
          posterUrl: item.cover_image ?? null,
          referer: "https://uqload.vc/",
          introStart: null,
          introEnd: null,
          outroStart: null,
          outroEnd: null,
          tracks: [],
          status: "ok",
        })
        .catch(() => undefined);

      return {
        value: {
          resolved: resolvedSource,
          server: {
            episodeId: epKey,
            name: "uqload",
            serverId: "uqload",
            cmid: String(malId),
            linkId: `${SITE_BASE}/anime/${animeId}`,
            type,
          },
          actualType: type,
          typeFallback: false,
          match: {
            animeId: String(animeId),
            slug: String(malId),
            title: item.english_title || item.canonical_title || preferredTitle(media),
            method: "catalog-search",
            confidence,
            siteUrl: `${SITE_BASE}/watch/${animeId}/episode-${episode}`,
            availableEpisodes: item.m3u8_episode_count || item.current_episodes || media.episodes || episode,
          },
          cached: false,
        },
        items: 1,
      };
    },
  );
}

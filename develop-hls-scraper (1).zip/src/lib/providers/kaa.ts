import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { sources } from "@/db/schema";
import { CACHE } from "@/lib/config";
import { candidateTitles, preferredTitle, type AnilistMedia } from "@/lib/anilist";
import { fetchJson, fetchText } from "@/lib/http";
import { scoreCandidate, searchKeyword } from "@/lib/match";
import { isFresh, ScrapeError, withJob } from "@/lib/scraper";
import type { ResolvedSource, ServerItem } from "@/lib/types";

const KAA_BASE = "https://kaa.lt";
const PLAYER_HOST = "https://krussdomi.com";
const HLS_HOST = "https://hls.krussdomi.com";

interface KaaSuggestion {
  slug: string;
  title: string;
  title_en?: string;
  year?: number;
  type?: string;
  status?: string;
}

interface KaaEpisode {
  slug: string;
  title?: string;
  episode_number: number;
  episode_string?: string;
}

interface KaaEpisodesResponse {
  result?: KaaEpisode[];
}

export interface KaaOutcome {
  resolved: ResolvedSource;
  server: ServerItem;
  actualType: "sub" | "dub";
  typeFallback: boolean;
  match: {
    animeId: string;
    slug: string;
    title: string;
    method: string;
    confidence: number;
    siteUrl: string;
    availableEpisodes: number;
  };
  cached: boolean;
}

/** Searches kaa.lt by title and returns the best matching show. */
async function searchKaa(
  media: AnilistMedia,
): Promise<{ slug: string; title: string; confidence: number }> {
  const targets = candidateTitles(media);
  const keyword = searchKeyword(targets[0] ?? preferredTitle(media));

  let suggestions: KaaSuggestion[] = [];
  try {
    suggestions = await fetchJson<KaaSuggestion[]>(`${KAA_BASE}/api/search`, {
      method: "POST",
      body: JSON.stringify({ query: keyword }),
      referer: `${KAA_BASE}/`,
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json, text/plain, */*",
        Origin: KAA_BASE,
      },
      timeoutMs: 15000,
    });
  } catch (err) {
    throw new ScrapeError(`kaa.lt search failed: ${err instanceof Error ? err.message : String(err)}`, 502);
  }

  if (!Array.isArray(suggestions) || !suggestions.length) {
    throw new ScrapeError(`kaa.lt returned no results for “${preferredTitle(media)}”`, 404);
  }

  let best: { item: KaaSuggestion; score: number } | null = null;
  for (const it of suggestions) {
    const names = [it.title, it.title_en, it.slug.replace(/-/g, " ")].filter(
      (v): v is string => typeof v === "string" && v.length > 0,
    );
    const s = scoreCandidate(targets, { title: names[0], japaneseTitle: names[1] ?? null }, media.format);
    if (!best || s > best.score) best = { item: it, score: s };
  }

  if (!best || best.score < 0.55) {
    throw new ScrapeError(
      `kaa.lt has no confident match for “${preferredTitle(media)}” (best: ${best?.item.title} @ ${best?.score.toFixed(2) ?? "0"})`,
      404,
    );
  }

  return {
    slug: best.item.slug,
    title: best.item.title_en || best.item.title,
    confidence: Number(best.score.toFixed(3)),
  };
}

/**
 * Fetches the page of episodes containing `episode`.
 *
 * `?ep=N` returns the whole 100-episode page that contains N (plus a `pages`
 * summary describing every range), so one request is enough to resolve any
 * episode — even on 1000+ episode shows.
 */
async function fetchKaaEpisodePage(
  slug: string,
  episode: number,
): Promise<{ episodes: KaaEpisode[]; totalEpisodes: number }> {
  const body = await fetchJson<KaaEpisodesResponse & { pages?: Array<{ eps?: number[] }> }>(
    `${KAA_BASE}/api/show/${encodeURIComponent(slug)}/episodes?ep=${episode}&lang=en-US`,
    { referer: `${KAA_BASE}/${slug}`, timeoutMs: 20000 },
  );
  const result = body?.result ?? [];
  const allNums = (body?.pages ?? []).flatMap((p) => p.eps ?? []);
  return {
    episodes: result.sort((a, b) => a.episode_number - b.episode_number),
    totalEpisodes: allNums.length ? Math.max(...allNums) : result.length,
  };
}

/** Unescapes the `\u002F` / `\/` sequences used inside the SSR JSON blob. */
function unescapeEmbedUrl(value: string): string {
  return value
    .replace(/\\u002F/gi, "/")
    .replace(/\\\//g, "/")
    .replace(/&amp;/g, "&")
    .replace(/\\"/g, '"');
}

/** Pulls the embed player URL out of an episode page's SSR payload. */
function extractPlayerUrl(html: string): string | null {
  // The page embeds a JSON blob with `servers:[{src:"https://krussdomi.com/..."}]`
  const match =
    html.match(/servers\s*:\s*\[\s*\{[^}]*src\s*:\s*"([^"]+)"/i) ??
    html.match(/src\s*:\s*"([^"]*krussdomi\.com[^"]*)"/i) ??
    html.match(/(https?:\/\/krussdomi\.com\/cat-player\/player\?[^"'\s]+)/i);
  if (!match) return null;
  return unescapeEmbedUrl(match[1]);
}

/** Reads the master.m3u8 out of the embed player page. */
function extractManifestUrl(html: string): string | null {
  const unescaped = html.replace(/&quot;/g, '"').replace(/\u002F/gi, "/").replace(/&amp;/g, "&");
  const match = unescaped.match(/(https?:\/\/hls\.[a-z0-9.-]+\/manifest\/[a-z0-9]+\/master\.m3u8)/i);
  return match ? match[1] : null;
}

function normaliseSkip(value: unknown): { start: number; end: number } | null {
  if (!value || typeof value !== "object") return null;
  const rec = value as Record<string, unknown>;
  const start = Number(rec.start);
  const end = Number(rec.end);
  if (Number.isFinite(start) && Number.isFinite(end)) return { start, end };
  return null;
}

/**
 * Resolves an AniList id + episode through `kaa.lt`.
 *
 * Chain: POST /api/search → GET /api/show/{slug}/episodes → episode page →
 * krussdomi.com player → hls.krussdomi.com/manifest/{id}/master.m3u8
 */
export async function resolveKaaStream(params: {
  anilistId: number;
  episode: number;
  type: "sub" | "dub";
  media: AnilistMedia;
  force?: boolean;
}): Promise<KaaOutcome> {
  const { anilistId, episode, type, media, force = false } = params;
  const epKey = `kaa:${anilistId}:${episode}`;

  if (!force) {
    const rows = await db
      .select()
      .from(sources)
      .where(
        and(
          eq(sources.episodeId, epKey),
          eq(sources.provider, "kaa"),
          eq(sources.status, "ok"),
          eq(sources.audioType, type),
        ),
      )
      .orderBy(desc(sources.resolvedAt))
      .limit(1);
    const cached = rows[0];
    if (cached?.hlsUrl && isFresh(cached.resolvedAt, CACHE.sourceTtlMs)) {
      return {
        cached: true,
        actualType: cached.audioType === "dub" ? "dub" : "sub",
        typeFallback: false,
        server: {
          episodeId: epKey,
          name: cached.serverName ?? "VidStreaming",
          serverId: cached.serverId ?? "1",
          cmid: "kaa",
          linkId: cached.linkId ?? "",
          type: cached.audioType ?? type,
        },
        match: {
          animeId: String(cached.animeId ?? anilistId),
          slug: cached.cmid ?? String(anilistId),
          title: preferredTitle(media),
          method: "cached",
          confidence: 1,
          siteUrl: cached.linkId ?? `${KAA_BASE}/`,
          availableEpisodes: media.episodes ?? episode,
        },
        resolved: {
          embedUrl: cached.embedUrl ?? "",
          embedOrigin: HLS_HOST,
          playerId: null,
          hlsUrl: cached.hlsUrl,
          referer: `${PLAYER_HOST}/`,
          posterUrl: cached.posterUrl ?? null,
          tracks: (cached.tracks ?? []) as ResolvedSource["tracks"],
          intro: cached.introStart != null ? { start: cached.introStart, end: cached.introEnd } : null,
          outro: cached.outroStart != null ? { start: cached.outroStart, end: cached.outroEnd } : null,
        },
      };
    }
  }

  return withJob<KaaOutcome>("kaa", `kaa.lt · anilist ${anilistId} · ep ${episode} · ${type}`, async () => {
    const { slug, title, confidence } = await searchKaa(media);
    const { episodes, totalEpisodes } = await fetchKaaEpisodePage(slug, episode);

    if (!episodes.length) {
      throw new ScrapeError(`kaa.lt lists no episodes for “${title}”`, 404);
    }

    const target =
      episodes.find((e) => e.episode_number === episode) ??
      episodes.find((e) => e.episode_string === String(episode));
    if (!target) {
      throw new ScrapeError(
        `episode ${episode} is not on kaa.lt (this show has ${totalEpisodes} episodes)`,
        404,
      );
    }

    const episodeUrl = `${KAA_BASE}/${slug}/ep-${target.episode_number}-${target.slug}`;
    const epHtml = await fetchText(episodeUrl, { referer: `${KAA_BASE}/${slug}` });

    const playerUrl = extractPlayerUrl(epHtml);
    if (!playerUrl) {
      // kaa.lt renders `servers:[]` for episodes that exist in the index but
      // have no playable source yet.
      throw new ScrapeError(
        `kaa.lt has no playable server for ${title} episode ${episode}`,
        404,
      );
    }

    const playerHtml = await fetchText(playerUrl, { referer: episodeUrl });
    const hlsUrl = extractManifestUrl(playerHtml);
    if (!hlsUrl) {
      throw new ScrapeError("kaa.lt player page exposed no manifest URL", 502);
    }

    // Subtitles and thumbnails live alongside the manifest. The player payload
    // is HTML-escaped (`&quot;`), so unescape before matching.
    const tracks: ResolvedSource["tracks"] = [];
    const unescaped = playerHtml
      .replace(/&quot;/g, '"')
      .replace(/&amp;/g, "&")
      .replace(/&#039;/g, "'");
    const subRe =
      /"language":\[0,"([a-z]{2,3})"\],"name":\[0,"([^"]+)"\],"src":\[0,"(https?:\/\/[^"]+)"/g;
    let sm: RegExpExecArray | null;
    while ((sm = subRe.exec(unescaped)) !== null) {
      tracks.push({ file: sm[3], label: sm[2], kind: "captions", default: sm[2] === "English" });
    }

    const intro = normaliseSkip(parseJsonField(playerHtml, "intro"));
    const outro = normaliseSkip(parseJsonField(playerHtml, "outro"));

    const resolved: ResolvedSource = {
      embedUrl: episodeUrl,
      embedOrigin: HLS_HOST,
      playerId: null,
      hlsUrl,
      referer: `${PLAYER_HOST}/`,
      posterUrl: null,
      tracks,
      intro,
      outro,
    };

    await db
      .insert(sources)
      .values({
        episodeId: epKey,
        animeId: slug,
        anilistId: String(anilistId),
        episodeNumber: String(episode),
        provider: "kaa",
        audioType: type,
        strategy: "site",
        serverName: "VidStreaming",
        serverId: "1",
        cmid: slug,
        linkId: episodeUrl,
        embedUrl: episodeUrl,
        hlsUrl,
        posterUrl: null,
        referer: `${PLAYER_HOST}/`,
        introStart: intro?.start ?? null,
        introEnd: intro?.end ?? null,
        outroStart: outro?.start ?? null,
        outroEnd: outro?.end ?? null,
        tracks: resolved.tracks,
        status: "ok",
      })
      .catch(() => undefined);

    return {
      value: {
        resolved,
        server: {
          episodeId: epKey,
          name: "VidStreaming",
          serverId: "1",
          cmid: slug,
          linkId: episodeUrl,
          type,
        },
        actualType: type,
        typeFallback: false,
        match: {
          animeId: slug,
          slug,
          title,
          method: "api-search",
          confidence,
          siteUrl: episodeUrl,
          availableEpisodes: totalEpisodes,
        },
        cached: false,
      },
      items: 1,
    };
  });
}

/** Best-effort extraction of a JSON object field from the player payload. */
function parseJsonField(html: string, field: string): unknown {
  const match = html.match(new RegExp(`"${field}"\\s*:\\s*(\\{[^}]*\\})`, "i"));
  if (!match) return null;
  try {
    return JSON.parse(match[1]);
  } catch {
    return null;
  }
}

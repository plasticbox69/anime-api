import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { sources } from "@/db/schema";
import { CACHE, PLAYER, SITE } from "@/lib/config";
import { candidateTitles, preferredTitle, type AnilistMedia } from "@/lib/anilist";
import { fetchText } from "@/lib/http";
import { dice, searchKeyword } from "@/lib/match";
import { resolveEmbedToHls } from "@/lib/player";
import { errorMessage, isFresh, ScrapeError, withJob } from "@/lib/scraper";
import type { ResolvedSource, SkipRange } from "@/lib/types";

/**
 * Browser-rendered provider for sites that ship an empty HTML shell and fetch
 * their catalogue + player entirely client-side.
 *
 * A headless Chromium instance renders the real page, so the site's own JS
 * performs its API calls, token minting and player setup. We then read the
 * resulting DOM and the network log — which is exactly what a user's browser
 * does — and pull the `.m3u8` out of it.
 */

export interface BrowserSiteConfig {
  id: string;
  label: string;
  host: string;
  /** Search page; `{q}` is replaced with the URL-encoded keyword. */
  searchUrl: string;
  /** Regex (with one capture group) matching anime cards on the search page. */
  resultLink: RegExp;
  /** Regex matching episode links on the anime page. */
  episodeLink: RegExp;
  /** Regex matching the player iframe / embed link on the episode page. */
  embedLink: RegExp;
  /** Take the stream purely from the network log (embeds are CF-gated). */
  captureFromNetworkOnly?: boolean;
  /** Optional element to click before capturing (e.g. a play/episode button). */
  clickSelector?: string;
  /** Optional text matcher for the element to click. */
  clickText?: RegExp;
  /** Extra wait (ms) after loading the episode page, for slow players. */
  waitMs?: number;
  /** True when the site is a manga reader and cannot serve anime video. */
  mangaOnly?: boolean;
  note: string;
}

export const BROWSER_SITES: BrowserSiteConfig[] = [
  {
    id: "senshi",
    label: "senshi.to",
    host: "senshi.to",
    searchUrl: "https://senshi.to/browse?search={q}",
    resultLink: /(\/watch\/[A-Za-z0-9_-]+\/\d+)/i,
    episodeLink: /(\/watch\/[A-Za-z0-9_-]+\/\d+)/i,
    // The real playlists are served as `.../<token>.jpg` with
    // `content-type: application/vnd.apple.mpegurl`, so we sniff the network
    // log instead of resolving an embed page.
    embedLink: /(https?:\/\/artplayer\.org[^"'\s<>]*)/i,
    captureFromNetworkOnly: true,
    clickSelector: "video",
    waitMs: 26000,
    note: "SvelteKit; /anime/filter search + bcdn1.se disguised m3u8 playlists",
  },
  {
    id: "2dhive",
    label: "2dhive.com",
    host: "2dhive.com",
    searchUrl: "https://2dhive.com/?q={q}",
    resultLink: /(\/anime\?anime=\d+)/i,
    episodeLink: /(\/episode\?anime=\d+&ep_num=\d+)/i,
    embedLink: /(https?:\/\/[^"'\s<>]*babastream[^"'\s<>]*)/i,
    note: "Astro SSR keyed by MAL id; babastream.top embeds",
  },
  {
    id: "gotaku",
    label: "gotaku.to",
    host: "gotaku.to",
    searchUrl: "https://gotaku.to/browse?q={q}",
    resultLink: /(\/title\/[A-Za-z0-9_-]+)/i,
    episodeLink: /(\/title\/[A-Za-z0-9_-]+[^"]*(?:episode|ep-)[^"]*)/i,
    embedLink: /(https?:\/\/[^"'\s<>]*(?:embed|stream|watch)[^"'\s<>]*)/i,
    note: "React SPA; /browse?q= → /title/{id}",
  },
  
  {
    id: "mmani",
    label: "mmani.com",
    host: "mmani.com",
    searchUrl: "https://mmani.com/search/?wd={q}",
    resultLink: /(\/(?:up|anime|watch)\/[A-Za-z0-9_-]+)/i,
    episodeLink: /(\/(?:up|anime|watch)\/[A-Za-z0-9_-]+[^"]*(?:episode|ep-)[^"]*)/i,
    embedLink: /(https?:\/\/[^"'\s<>]*(?:embed|stream|watch)[^"'\s<>]*)/i,
    note: "jQuery catalogue at /search/?wd=",
  },
  {
    id: "mkissa",
    label: "mkissa.to",
    host: "mkissa.to",
    // SPA: /search?type=anime&q= resolves anime via api.mkissa.net GraphQL
    searchUrl: "https://mkissa.to/search?type=anime&q={q}",
    resultLink: /(\/anime\/[A-Za-z0-9_-]{8,})/i,
    episodeLink: /(\/anime\/[A-Za-z0-9_-]{8,})/i,
    embedLink: /(https?:\/\/[^"'\s<>]*(?:embed|stream|watch|player)[^"'\s<>]*)/i,
    clickSelector: "button",
    clickText: /^(?:1|ep\s*1|play|watch)/i,
    note: "Next-style SPA backed by api.mkissa.net GraphQL; anime catalogue + episode pages render client-side",
  },
  {
    id: "anisnatch",
    label: "anisnatch.to",
    host: "anisnatch.to",
    searchUrl: "https://anisnatch.to/home?q={q}",
    resultLink: /(\/(?:anime|watch)\/[A-Za-z0-9_-]+)/i,
    episodeLink: /(\/(?:anime|watch)\/[A-Za-z0-9_-]+[^"]*(?:episode|ep-)[^"]*)/i,
    embedLink: /(https?:\/\/[^"'\s<>]*(?:embed|stream|watch)[^"'\s<>]*)/i,
    note: "pako-compressed AJAX shell; catalogue is client-decoded",
  },
];

export function getBrowserSite(id: string): BrowserSiteConfig | undefined {
  return BROWSER_SITES.find((s) => s.id === id);
}

export interface BrowserMatch {
  siteId: string;
  siteLabel: string;
  siteHost: string;
  animeUrl: string;
  title: string;
  confidence: number;
  episodeUrl: string | null;
  availableEpisodes: number;
}

export interface BrowserOutcome {
  resolved: ResolvedSource;
  match: BrowserMatch;
  cached: boolean;
  /** Network log lines captured while rendering (useful for debugging). */
  trace: string[];
}

function scoreLinks(
  items: Array<string | { href: string; text?: string }>,
  targets: string[],
): Array<{ href: string; score: number }> {
  return items
    .map((item) => {
      const href = typeof item === "string" ? item : item.href;
      const text = typeof item === "string" ? "" : (item.text ?? "");
      const slug = href.replace(/\/+$/, "").split("/").pop() ?? href;
      // Compare against the opaque id/slug and the card's visible label.
      const score = Math.max(
        ...targets.flatMap((t) => [
          dice(t, slug.replace(/[-_]/g, " ")),
          text ? dice(t, text) : 0,
        ]),
      );
      return { href, score };
    })
    .sort((a, b) => b.score - a.score);
}

function uniqueBy<T>(items: T[], key: (item: T) => string): T[] {
  const seen = new Set<string>();
  const out: T[] = [];
  for (const item of items) {
    const k = key(item);
    if (seen.has(k)) continue;
    seen.add(k);
    out.push(item);
  }
  return out;
}

/** Extracts an m3u8 URL from an embed page or resolves it through MegaPlay. */
async function resolveEmbed(embedUrl: string): Promise<ResolvedSource> {
  if (/\.m3u8($|\?)/i.test(embedUrl)) {
    return {
      embedUrl,
      embedOrigin: new URL(embedUrl).origin,
      playerId: null,
      hlsUrl: embedUrl,
      referer: PLAYER_REFERER,
      tracks: [],
      intro: null,
      outro: null,
    };
  }
  return resolveEmbedToHls(embedUrl);
}

const PLAYER_REFERER = "https://megaplay.buzz/";

/**
 * Renders a site in headless Chromium and resolves a playable playlist.
 *
 * Playwright is imported lazily so the module stays usable in environments
 * where the browser binary is not installed (a clear error is returned then).
 */
export async function resolveBrowserStream(params: {
  siteId: string;
  anilistId: number;
  episode: number;
  type: "sub" | "dub";
  media: AnilistMedia;
  force?: boolean;
}): Promise<BrowserOutcome> {
  const { siteId, anilistId, episode, type, media, force = false } = params;
  const site = getBrowserSite(siteId);
  if (!site) throw new ScrapeError(`unknown browser site “${siteId}”`, 404);
  if (site.mangaOnly) {
    throw new ScrapeError(
      `${site.label} is a manga reader — ${site.note}. Use anikototv.to, reanime.to, aniwaves.ru, senshi.to or 2dhive.com for video.`,
      501,
    );
  }

  const epKey = `browser:${site.id}:${anilistId}:${episode}`;

  if (!force) {
    const rows = await db
      .select()
      .from(sources)
      .where(and(eq(sources.episodeId, epKey), eq(sources.status, "ok"), eq(sources.audioType, type)))
      .orderBy(desc(sources.resolvedAt))
      .limit(1);
    const cached = rows[0];
    if (cached?.hlsUrl && isFresh(cached.resolvedAt, CACHE.sourceTtlMs)) {
      return {
        cached: true,
        trace: ["served from local cache"],
        match: {
          siteId: site.id,
          siteLabel: site.label,
          siteHost: site.host,
          animeUrl: cached.cmid ?? `https://${site.host}`,
          title: preferredTitle(media),
          confidence: 1,
          episodeUrl: null,
          availableEpisodes: media.episodes ?? episode,
        },
        resolved: {
          embedUrl: cached.embedUrl ?? "",
          embedOrigin: cached.embedUrl ? new URL(cached.embedUrl).origin : `https://${site.host}`,
          playerId: null,
          hlsUrl: cached.hlsUrl,
          referer: cached.referer ?? PLAYER.cdnReferer,
          posterUrl: cached.posterUrl ?? null,
          tracks: (cached.tracks ?? []) as ResolvedSource["tracks"],
          intro:
            cached.introStart != null || cached.introEnd != null
              ? { start: cached.introStart, end: cached.outroEnd }
              : null,
          outro:
            cached.outroStart != null || cached.outroEnd != null
              ? { start: cached.outroStart, end: cached.outroEnd }
              : null,
        },
      };
    }
  }

  return withJob<BrowserOutcome>("browser", `${site.label} · anilist ${anilistId} · ep ${episode}`, async () => {
    const targets = candidateTitles(media);
    const keyword = searchKeyword(targets[0] ?? preferredTitle(media));

    let chromium: typeof import("playwright").chromium;
    try {
      const pw = await import("playwright");
      chromium = pw.chromium;
    } catch {
      throw new ScrapeError(
        "Playwright is not installed — run `npx playwright install chromium` to enable browser-rendered providers",
        501,
      );
    }

    const browser = await chromium.launch({
      args: ["--no-sandbox", "--disable-dev-shm-usage", "--disable-gpu"],
    });
    const trace: string[] = [];

    try {
      const context = await browser.newContext({
        userAgent: SITE.userAgent,
        viewport: { width: 1280, height: 800 },
      });
      const page = await context.newPage();
      const m3u8Hits = new Set<string>();
      const videoHits = new Set<string>();
      const embedHits = new Set<string>();

      page.on("response", (res) => {
        const u = res.url();
        // Playlists are sometimes served with no extension (e.g. `/v/<token>`);
        // sniff the content-type as well as the path.
        const ct = (res.headers()["content-type"] ?? "").toLowerCase();
        if (
          /\.m3u8(\?|$)/i.test(u) ||
          ct.includes("mpegurl") ||
          ct.includes("dash+xml")
        ) {
          m3u8Hits.add(u);
        }
      });
      page.on("request", (req) => {
        const u = req.url();
        // Direct video files (MP4/MKV/WebM) — including signed, query-only URLs.
        if (/\.(mp4|mkv|webm)(\?|$)/i.test(u)) videoHits.add(u);
        if (
          /\/(embed|stream|watch|e|player)\//i.test(u) &&
          !/\.(js|css|png|jpe?g|webp|woff2?|svg|ico)$/i.test(u)
        ) {
          embedHits.add(u);
        }
      });

      const searchCandidates = [
        site.searchUrl,
        `https://${site.host}/search?q={q}`,
        `https://${site.host}/browse?q={q}`,
        `https://${site.host}/search?keyword={q}`,
      ].map((t) => t.replace("{q}", encodeURIComponent(keyword)));

      let searchUrl = searchCandidates[0];
      let searchLinks: Array<{ href: string; text: string }> = [];

      for (const candidate of Array.from(new Set(searchCandidates))) {
        await page.goto(candidate, { waitUntil: "networkidle", timeout: 35000 }).catch(() => undefined);
        await page.waitForTimeout(2200);
        searchLinks = await page.evaluate((patternSource) => {
          const re = new RegExp(patternSource, "i");
          const out: Array<{ href: string; text: string }> = [];
          document.querySelectorAll("a[href]").forEach((a) => {
            const href = a.getAttribute("href") ?? "";
            if (re.test(href)) out.push({ href, text: (a.textContent ?? "").trim().slice(0, 120) });
          });
          return out;
        }, site.resultLink.source);
        searchUrl = candidate;
        trace.push(`GET ${candidate} → ${searchLinks.length} link(s)`);
        if (searchLinks.length) break;
      }


      if (!searchLinks.length) {
        throw new ScrapeError(
          `${site.label} rendered no results for “${keyword}” (page text length ${await page.evaluate(() => document.body.innerText.length)})`,
          404,
        );
      }
      trace.push(`✓ ${searchLinks.length} result link(s) rendered`);

      // Opaque ids (e.g. /watch/zpykk7/1) carry no title, so score on the
      // anchor text when it is available and fall back to the href slug.
      const ranked = searchLinks
        .map((link) => ({
          href: link.href,
          score: Math.max(
            scoreLinks([link.href], targets)[0]?.score ?? 0,
            link.text ? scoreLinks([link.text], targets)[0]?.score ?? 0 : 0,
          ),
        }))
        .sort((a, b) => b.score - a.score);
      let best = ranked[0];

      // Opik/SPA search cards often render only an opaque id, so the anchor
      // text carries no title. When confidence is low, open the top few
      // candidates and score their rendered <title> instead.
      if (!best || best.score < 0.6) {
        const verified: Array<{ href: string; score: number; title: string }> = [];
        for (const cand of ranked.slice(0, 3)) {
          try {
            const abs = new URL(cand.href, searchUrl).toString();
            await page.goto(abs, { waitUntil: "domcontentloaded", timeout: 25000 });
            await page.waitForTimeout(1400);
            const title = await page.title();
            const score = scoreLinks([{ href: cand.href, text: title }], targets)[0]?.score ?? 0;
            verified.push({ href: cand.href, score, title });
            trace.push(`verified “${title.slice(0, 60)}” → ${score.toFixed(2)}`);
          } catch {
            verified.push({ href: cand.href, score: cand.score, title: "" });
          }
        }
        verified.sort((a, b) => b.score - a.score);
        const vBest = verified[0];
        if (vBest && (!best || vBest.score > best.score)) {
          best = { href: vBest.href, score: vBest.score };
        }
      }

      if (!best || best.score < 0.55) {
        throw new ScrapeError(
          `${site.label} does not appear to host “${preferredTitle(media)}” (best match ${best?.score.toFixed(2) ?? "0"})`,
          404,
        );
      }

      const animeUrl = new URL(best.href, searchUrl).toString();
      await page.goto(animeUrl, { waitUntil: "networkidle", timeout: 35000 }).catch(() => undefined);
      await page.waitForTimeout(2200);
      trace.push(`GET ${animeUrl}`);

      const episodeLinks = await page.evaluate((patternSource) => {
        const re = new RegExp(patternSource, "i");
        const out: string[] = [];
        document.querySelectorAll("a[href]").forEach((a) => {
          const href = a.getAttribute("href") ?? "";
          if (re.test(href)) out.push(href);
        });
        return Array.from(new Set(out));
      }, site.episodeLink.source);

      const pool = episodeLinks.length ? episodeLinks : [animeUrl];
      const numbered = pool
        .map((href) => {
          const abs = new URL(href, animeUrl).toString();
          const m = abs.match(/(?:episode|ep[-_/=])(\d+(?:\.\d+)?)/i) ?? abs.match(/[?&]ep(?:_num)?=(\d+)/i);
          return { abs, num: m ? Number(m[1]) : null };
        })
        .filter((x): x is { abs: string; num: number } => x.num !== null);

      const target =
        numbered.find((x) => x.num === episode) ??
        numbered.find((x) => Math.round(x.num) === episode) ??
        numbered[0] ?? { abs: animeUrl, num: episode };

      if (!numbered.length) trace.push(`! no numbered episode links — using title page`);
      trace.push(`GET ${target.abs}`);

      m3u8Hits.clear();
      embedHits.clear();
      // Arm a deterministic listener for the media response *before* navigating,
      // so we never miss a playlist that loads during app hydration.
      const mediaResponsePromise = page
        .waitForResponse(
          (r) => {
            const ct = (r.headers()["content-type"] ?? "").toLowerCase();
            const u = r.url();
            return (
              ct.includes("mpegurl") ||
              ct.includes("dash+xml") ||
              /\.m3u8(\?|$)/i.test(u) ||
              /\.(mp4|mkv|webm)(\?|$)/i.test(u)
            );
          },
          { timeout: site.waitMs ?? 30000 },
        )
        .catch(() => null);

      await page
        .goto(target.abs, {
          waitUntil: "load",
          timeout: 35000,
        })
        .catch(() => undefined);
      await page.waitForTimeout(site.waitMs ? Math.round(site.waitMs / 3) : 2500);

      // Nudge autoplay-only players.
      try {
        await page.evaluate(() => {
          const vid = document.querySelector("video");
          if (vid) {
            vid.muted = true;
            void vid.play().catch(() => undefined);
          }
        });
        await page.waitForTimeout(1200);
      } catch {
        /* ignore */
      }

      const mediaResponse = await mediaResponsePromise;
      if (mediaResponse) {
        m3u8Hits.add(mediaResponse.url());
        trace.push(`media response captured during load: ${mediaResponse.url().slice(0, 90)}`);
      }

      const iframes = await page.evaluate(() =>
        Array.from(document.querySelectorAll("iframe"))
          .map((f) => f.getAttribute("src") ?? "")
          .filter(Boolean),
      );
      const embedAnchors = await page.evaluate((patternSource) => {
        const re = new RegExp(patternSource, "i");
        const out: string[] = [];
        document.querySelectorAll("a[href]").forEach((a) => {
          const href = a.getAttribute("href") ?? "";
          if (re.test(href)) out.push(href);
        });
        return Array.from(new Set(out));
      }, site.embedLink.source);

      const embedCandidates = uniqueBy(
        [...iframes, ...embedAnchors, ...embedHits].map((u) => {
          try {
            return new URL(u, target.abs).toString();
          } catch {
            return u;
          }
        }),
        (u) => u,
      ).filter((u) => /^https?:\/\//i.test(u));

      trace.push(`iframes: ${iframes.length} · embed links: ${embedAnchors.length}`);

      const attempts: string[] = [];
      let resolved: ResolvedSource | null = null;

      // 1. A playlist captured straight from the network log.
      const captured =
        Array.from(m3u8Hits).find((u) => /\.m3u8/i.test(u) || /mpegurl/i.test(u)) ??
        Array.from(videoHits)[0];

      if (captured) {
        resolved = {
          embedUrl: target.abs,
          embedOrigin: new URL(captured).origin,
          playerId: null,
          hlsUrl: captured,
          // Media CDNs behind these SPAs gate on the site's own Referer.
          referer: `https://${site.host}/`,
          tracks: [],
          intro: null,
          outro: null,
        };
        trace.push(`captured media from network log: ${captured.slice(0, 90)}`);
      }

      // 2. Sites whose players mint playlists behind a challenge: network only.
      //    Otherwise resolve the first embed that yields a playlist.
      if (!resolved && !site.captureFromNetworkOnly) {
        for (const candidate of embedCandidates.slice(0, 3)) {
          try {
            trace.push(`resolving embed ${candidate.slice(0, 90)}`);
            resolved = await resolveEmbed(candidate);
            if (resolved.hlsUrl) {
              trace.push(`embed resolved`);
              break;
            }
          } catch (err) {
            attempts.push(`${candidate.slice(0, 60)}: ${errorMessage(err)}`);
          }
        }
      }

    if (!resolved?.hlsUrl) {
      throw new ScrapeError(
        `${site.label} rendered the episode but exposed no playable source${
          attempts.length ? ` — ${attempts.join("; ")}` : ""
        }`,
        502,
        trace,
      );
  }

    const finalResolved: ResolvedSource = {
      ...resolved,
      referer: resolved.referer || PLAYER.cdnReferer,
    };

    await db.insert(sources).values({
      episodeId: epKey,
      animeId: null,
      anilistId: String(anilistId),
      episodeNumber: String(episode),
      provider: site.id,
      audioType: type,
      strategy: "site",
      serverName: "browser",
      serverId: "1",
      cmid: animeUrl,
      linkId: finalResolved.embedUrl,
      embedUrl: finalResolved.embedUrl,
      hlsUrl: finalResolved.hlsUrl,
      posterUrl: finalResolved.posterUrl ?? null,
      referer: finalResolved.referer,
      introStart: finalResolved.intro?.start ?? null,
      introEnd: finalResolved.intro?.end ?? null,
      outroStart: finalResolved.outro?.start ?? null,
      outroEnd: finalResolved.outro?.end ?? null,
      tracks: finalResolved.tracks,
      status: "ok",
    });

    return {
      value: {
        resolved: finalResolved,
        cached: false,
        trace,
        match: {
          siteId: site.id,
          siteLabel: site.label,
          siteHost: site.host,
          animeUrl,
          title: preferredTitle(media),
          confidence: Number(best.score.toFixed(3)),
          episodeUrl: target.abs,
          availableEpisodes: numbered.length || (media.episodes ?? episode),
        },
      },
      items: 1,
    };
    } finally {
      await browser.close().catch(() => undefined);
    }
  });
}


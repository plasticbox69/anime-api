import { createDecipheriv, createHash, pbkdf2Sync } from "node:crypto";
import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { sources } from "@/db/schema";
import { CACHE, REANIME } from "@/lib/config";
import { candidateTitles, preferredTitle, type AnilistMedia } from "@/lib/anilist";
import { fetchJson, fetchText } from "@/lib/http";
import { searchKeyword } from "@/lib/match";
import { errorMessage, isFresh, ScrapeError, withJob } from "@/lib/scraper";
import type { ResolvedSource, ServerItem, SkipRange } from "@/lib/types";

interface FlixServerEntry {
  $id?: string;
  serverName?: string;
  dataLink?: string;
  dataType?: string;
  softsub?: boolean;
}

interface FlixApiResponse {
  success?: boolean;
  servers?: FlixServerEntry[];
}

interface FlixSubtitleEntry {
  url?: string;
  language?: string;
  format?: string;
  default?: boolean;
}

interface FlixEmbedData {
  video_id?: string;
  video_title?: string;
  audio_type?: string;
  default_audio_track?: number;
  w_payload?: string;
  obfuscation_seed?: string;
  obfuscated_crypto_data?: Record<string, unknown>;
  thumbnail?: string;
  thumbnails_vtt?: string;
  intro_chapter?: { start?: number; end?: number } | null;
  outro_chapter?: { start?: number; end?: number } | null;
  subtitles?: FlixSubtitleEntry[];
  [key: string]: unknown;
}

export interface ReanimeCatalogHit {
  slug: string;
  title: string;
  episodes: number;
  subbed: number;
  dubbed: number;
}

export interface ReanimeResolveOutcome {
  resolved: ResolvedSource;
  server: ServerItem;
  actualType: "sub" | "dub";
  typeFallback: boolean;
  catalog: ReanimeCatalogHit | null;
  cached: boolean;
}

function sha256Hex(input: string): string {
  return createHash("sha256").update(input, "utf8").digest("hex");
}

/** Unflattens SvelteKit's `devalue` array format (`__data.json` payloads). */
export function unflattenSvelteKitData(arr: unknown[], idx = 0, seen = new Set<number>()): unknown {
  if (typeof idx !== "number" || idx < 0 || idx >= arr.length) return idx;
  if (seen.has(idx)) return null;
  const val = arr[idx];
  if (val && typeof val === "object") {
    const next = new Set(seen);
    next.add(idx);
    if (Array.isArray(val)) {
      return val.map((item) =>
        typeof item === "number" ? unflattenSvelteKitData(arr, item, next) : item,
      );
    }
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(val as Record<string, unknown>)) {
      out[k] = typeof v === "number" ? unflattenSvelteKitData(arr, v, next) : v;
    }
    return out;
  }
  return val;
}

/** Checks that a `?token=eyJ...` JWT inside an HLS URL still has >=5 min left. */
function isJwtUrlStillValid(hlsUrl: string): boolean {
  try {
    const token = new URL(hlsUrl).searchParams.get("token");
    if (!token) return true;
    const parts = token.split(".");
    if (parts.length !== 3) return true;
    const payload = JSON.parse(Buffer.from(parts[1], "base64url").toString("utf8")) as {
      exp?: number;
    };
    if (typeof payload.exp !== "number") return true;
    return payload.exp - Math.floor(Date.now() / 1000) > 300;
  } catch {
    return true;
  }
}

/**
 * Looks up the title in `reanime.to/search/__data.json` so we can report its
 * exact `reanime.to` slug (`frieren-beyond-journey-s-end-yw2a3j`) and episode
 * counts. Non-fatal if search is unavailable because `/api/flix` accepts
 * AniList IDs directly.
 */
async function lookupReanimeCatalog(media: AnilistMedia): Promise<ReanimeCatalogHit | null> {
  const titles = candidateTitles(media).slice(0, 2);
  for (const raw of titles) {
    try {
      const q = searchKeyword(raw);
      const url = `${REANIME.baseUrl}/search/__data.json?q=${encodeURIComponent(q)}`;
      const json = await fetchJson<{
        nodes?: Array<{ type?: string; data?: unknown[] } | null>;
      }>(url, { referer: `${REANIME.baseUrl}/` });

      const dataNode = (json.nodes ?? []).find(
        (n) =>
          n?.type === "data" &&
          Array.isArray(n.data) &&
          n.data.some((entry) => entry && typeof entry === "object" && "initial" in entry),
      );
      if (!dataNode?.data) continue;

      const root = unflattenSvelteKitData(dataNode.data, 0) as {
        initial?: { results?: Array<Record<string, unknown>> };
      };
      const results = root?.initial?.results ?? [];
      const hit = results.find((r) => Number(r.anilist_id) === media.id);
      if (hit && typeof hit.anime_id === "string") {
        const titleObj = (hit.title ?? {}) as Record<string, unknown>;
        const title =
          (typeof titleObj.english === "string" && titleObj.english) ||
          (typeof titleObj.romaji === "string" && titleObj.romaji) ||
          preferredTitle(media);
        return {
          slug: hit.anime_id,
          title,
          episodes: Number(hit.episodes ?? 0) || 0,
          subbed: Number(hit.subbed ?? 0) || 0,
          dubbed: Number(hit.dubbed ?? 0) || 0,
        };
      }
    } catch {
      continue;
    }
  }
  return null;
}

/** Loads `FlixEmbedData` from `flixcloud.cc/e/{code}/__data.json` (with HTML fallback). */
async function fetchFlixEmbedData(embedUrl: string): Promise<FlixEmbedData> {
  const parsed = new URL(embedUrl);
  const dataJsonUrl = new URL(
    `${parsed.pathname.replace(/\/+$/, "")}/__data.json${parsed.search}`,
    parsed.origin,
  ).toString();

  try {
    const dj = await fetchJson<{
      nodes?: Array<{ type?: string; data?: unknown[] } | null>;
    }>(dataJsonUrl, { referer: `${REANIME.baseUrl}/` });

    const node = (dj.nodes ?? []).find(
      (n) =>
        n?.type === "data" &&
        Array.isArray(n.data) &&
        n.data.some((x) => x && typeof x === "object" && "obfuscation_seed" in x),
    );
    if (node?.data) {
      return unflattenSvelteKitData(node.data, 0) as FlixEmbedData;
    }
  } catch {
    /* fall through to HTML extraction */
  }

  const html = await fetchText(embedUrl, { referer: `${REANIME.baseUrl}/` });
  const seedMatch = html.match(/obfuscation_seed\s*:\s*"([0-9a-fA-F]+)"/);
  const wasmMatch = html.match(/w_payload\s*:\s*"([A-Za-z0-9+/=]+)"/);
  if (!seedMatch || !wasmMatch) {
    throw new ScrapeError("flixcloud embed did not expose decryption payload", 502);
  }
  throw new ScrapeError("flixcloud __data.json endpoint did not return embed state", 502);
}

/**
 * Executes FlixCloud's full decryption pipeline in Node.js:
 *   1. Double 3-round SHA-256 field de-obfuscation from `obfuscation_seed`.
 *   2. `/api/m3u8/{tokenRef}` playback token fetch.
 *   3. Inline WebAssembly (`w_payload`) `_s` + `_r` key-fragment combiner AND
 *      `_c()` 32-byte XOR manifest key (`window.__pk`).
 *   4. PBKDF2-HMAC-SHA256 (1000 iter) -> seed XOR -> SHA-256 -> AES-256-CBC
 *      decryption of the `_v7/{uuid}/master.m3u8?token=…` URL.
 */
async function decryptFlixEmbed(
  embedUrl: string,
  requestedAudio: "sub" | "dub",
): Promise<{ resolved: ResolvedSource; hasDub: boolean }> {
  const targetUrl = new URL(embedUrl);
  if (requestedAudio === "dub") {
    targetUrl.searchParams.set("a", "1");
  }
  const finalEmbedUrl = targetUrl.toString();
  const data = await fetchFlixEmbedData(finalEmbedUrl);

  const seed = data.obfuscation_seed;
  const wasmB64 = data.w_payload;
  const cryptoRoot = data.obfuscated_crypto_data;
  if (!seed || !wasmB64 || !cryptoRoot) {
    throw new ScrapeError("flixcloud embed is missing obfuscated crypto fields", 502);
  }

  let e = seed;
  for (let i = 0; i < 3; i += 1) e = sha256Hex(e + String(i));
  let a = e;
  for (let i = 0; i < 3; i += 1) a = sha256Hex(a + String(i));

  const containerName = `cd_${e.slice(24, 32)}`;
  const arrayName = `ad_${e.slice(32, 40)}`;
  const objectName = `od_${e.slice(40, 48)}`;
  const keyField = `kf_${e.slice(8, 16)}`;
  const ivField = `ivf_${e.slice(16, 24)}`;
  const tokenField = `${e.slice(48, 64)}_${e.slice(56, 64)}`;
  const keyFrag2Field = `${a.slice(0, 16)}_${a.slice(16, 24)}`;

  const container = cryptoRoot[containerName] as Record<string, unknown> | undefined;
  const arr = container?.[arrayName] as Array<Record<string, unknown>> | undefined;
  const inner = arr?.[0]?.[objectName] as Record<string, unknown> | undefined;

  const frag1B64 = typeof inner?.[keyField] === "string" ? (inner[keyField] as string) : null;
  const ivB64 = typeof inner?.[ivField] === "string" ? (inner[ivField] as string) : null;
  const frag2B64 = typeof data[keyFrag2Field] === "string" ? (data[keyFrag2Field] as string) : null;
  const tokenRef = typeof data[tokenField] === "string" ? (data[tokenField] as string) : null;

  if (!frag1B64 || !ivB64 || !frag2B64 || !tokenRef) {
    throw new ScrapeError("flixcloud field mapping did not match embed payload", 502);
  }

  const tokenUrl = `${targetUrl.origin}/api/m3u8/${encodeURIComponent(tokenRef)}`;
  const tokJson = await fetchJson<Record<string, string>>(tokenUrl, {
    referer: finalEmbedUrl,
  });

  const vidKey = sha256Hex(`${tokenRef}vid`).slice(0, 10);
  const keyKey = sha256Hex(`${tokenRef}key`).slice(0, 10);
  const cipherB64 = tokJson?.[vidKey];
  const frag3B64 = tokJson?.[keyKey];
  if (!cipherB64 || !frag3B64) {
    throw new ScrapeError("flixcloud /api/m3u8 returned an incomplete token response", 502);
  }

  const frag1 = Buffer.from(frag1B64, "base64");
  const frag2 = Buffer.from(frag2B64, "base64");
  const frag3 = Buffer.from(frag3B64, "base64");
  const iv = Buffer.from(ivB64, "base64");
  const cipher = Buffer.from(cipherB64, "base64");

  const wasmBytes = Buffer.from(wasmB64, "base64");
  const { instance } = await WebAssembly.instantiate(wasmBytes, {});
  const exports = instance.exports as {
    memory: WebAssembly.Memory;
    _s: (seed32: number) => void;
    _r: (p1: number, p2: number, p3: number, pOut: number, len: number) => void;
    _c?: () => number;
  };

  if (exports.memory.buffer.byteLength === 0) {
    exports.memory.grow(1);
  }
  const mem = new Uint8Array(exports.memory.buffer);
  const len = frag1.length;
  const p1 = 1000;
  const p2 = p1 + len;
  const p3 = p2 + len;
  const pOut = p3 + len;
  mem.set(frag1, p1);
  mem.set(frag2, p2);
  mem.set(frag3, p3);
  exports._s(Number.parseInt(seed.slice(0, 8), 16));
  exports._r(p1, p2, p3, pOut, len);
  const combined = Buffer.from(mem.subarray(pOut, pOut + len));

  let manifestKey: string | null = null;
  if (typeof exports._c === "function") {
    const pkOffset = exports._c();
    const pkBytes = Buffer.from(new Uint8Array(exports.memory.buffer).subarray(pkOffset, pkOffset + 32));
    manifestKey = pkBytes.toString("base64");
  }

  const derived = Buffer.from(pbkdf2Sync(combined, Buffer.from(seed, "utf8"), 1000, 32, "sha256"));
  for (let i = 0; i < 32; i += 1) {
    derived[i] ^= seed.charCodeAt(i % seed.length);
  }
  const aesKey = createHash("sha256").update(derived).digest();

  const decipher = createDecipheriv("aes-256-cbc", aesKey, iv);
  const masterUrl = Buffer.concat([decipher.update(cipher), decipher.final()]).toString("utf8").trim();
  if (!/^https?:\/\//i.test(masterUrl)) {
    throw new ScrapeError("flixcloud decryption did not produce a valid URL", 502);
  }

  const tracks: ResolvedSource["tracks"] = [];
  for (const sub of data.subtitles ?? []) {
    if (!sub?.url) continue;
    tracks.push({
      file: sub.url,
      label: sub.language || "Subtitles",
      kind: "captions",
      format: sub.format || undefined,
      default: Boolean(sub.default),
    });
  }
  if (typeof data.thumbnails_vtt === "string" && data.thumbnails_vtt) {
    tracks.push({ file: data.thumbnails_vtt, kind: "thumbnails" });
  }

  const toRange = (ch?: { start?: number; end?: number } | null): SkipRange | null =>
    ch && (typeof ch.start === "number" || typeof ch.end === "number")
      ? { start: ch.start ?? null, end: ch.end ?? null }
      : null;

  const hasDub = data.audio_type === "dual" || data.default_audio_track === 1;

  return {
    hasDub,
    resolved: {
      embedUrl: finalEmbedUrl,
      embedOrigin: targetUrl.origin,
      playerId: data.video_id ?? null,
      hlsUrl: masterUrl,
      manifestKey,
      referer: `${targetUrl.origin}/`,
      posterUrl: typeof data.thumbnail === "string" ? data.thumbnail : null,
      tracks,
      intro: toRange(data.intro_chapter),
      outro: toRange(data.outro_chapter),
    },
  };
}

function cacheKey(anilistId: number, episode: number): string {
  return `reanime:${anilistId}:${episode}`;
}

/**
 * Resolves an AniList ID + episode number through `reanime.to` (`flixcloud.cc`).
 */
export async function resolveReanimeStream(params: {
  anilistId: number;
  malId: number | null;
  episode: number;
  type: "sub" | "dub";
  media: AnilistMedia | null;
  force?: boolean;
}): Promise<ReanimeResolveOutcome> {
  const { anilistId, malId, episode, type, media, force = false } = params;
  const epKey = cacheKey(anilistId, episode);

  const catalogPromise = media ? lookupReanimeCatalog(media) : Promise.resolve(null);

  if (!force) {
    const rows = await db
      .select()
      .from(sources)
      .where(
        and(
          eq(sources.episodeId, epKey),
          eq(sources.provider, "reanime"),
          eq(sources.status, "ok"),
          eq(sources.audioType, type),
        ),
      )
      .orderBy(desc(sources.resolvedAt))
      .limit(1);
    const cached = rows[0];
    if (
      cached?.hlsUrl &&
      cached.manifestKey &&
      isFresh(cached.resolvedAt, CACHE.sourceTtlMs) &&
      isJwtUrlStillValid(cached.hlsUrl)
    ) {
      const catalog = await catalogPromise;
      return {
        cached: true,
        actualType: (cached.audioType === "dub" ? "dub" : "sub"),
        typeFallback: false,
        catalog,
        server: {
          episodeId: epKey,
          name: cached.serverName ?? "HD-1",
          serverId: cached.serverId ?? "hd1",
          cmid: "reanime",
          linkId: cached.linkId ?? "",
          type: cached.audioType ?? type,
        },
        resolved: {
          embedUrl: cached.embedUrl ?? "",
          embedOrigin: cached.embedUrl ? new URL(cached.embedUrl).origin : REANIME.flixOrigin,
          playerId: null,
          hlsUrl: cached.hlsUrl,
          manifestKey: cached.manifestKey,
          referer: cached.referer ?? REANIME.flixReferer,
          posterUrl: cached.posterUrl ?? null,
          tracks: (cached.tracks ?? []) as ResolvedSource["tracks"],
          intro:
            cached.introStart != null || cached.introEnd != null
              ? { start: cached.introStart, end: cached.introEnd }
              : null,
          outro:
            cached.outroStart != null || cached.outroEnd != null
              ? { start: cached.outroStart, end: cached.outroEnd }
              : null,
        },
      };
    }
  }

  return withJob<ReanimeResolveOutcome>(
    "reanime",
    `anilist ${anilistId} · ep ${episode} · ${type}`,
    async () => {
      const qs = new URLSearchParams();
      if (malId) qs.set("mal", String(malId));
      const flixApiUrl = `${REANIME.baseUrl}/api/flix/${anilistId}/${episode}${
        qs.toString() ? `?${qs.toString()}` : ""
      }`;

      const flixBody = await fetchJson<FlixApiResponse>(flixApiUrl, {
        referer: `${REANIME.baseUrl}/`,
      });
      const rawServers = (flixBody.servers ?? []).filter(
        (s): s is FlixServerEntry & { dataLink: string } =>
          typeof s?.dataLink === "string" && s.dataLink.length > 0,
      );
      if (!flixBody.success || rawServers.length === 0) {
        throw new ScrapeError(
          `reanime.to has no servers for AniList ${anilistId} episode ${episode}`,
          404,
        );
      }

      const normalizeType = (dt?: string): "sub" | "dub" =>
        dt && dt.toLowerCase().includes("dub") ? "dub" : "sub";

      const matching = rawServers.filter((s) => normalizeType(s.dataType) === type);
      const candidates = matching.length > 0 ? matching : rawServers;
      const listFallback = matching.length === 0;

      // Prefer HD-1 first, then HD-2.
      candidates.sort((x, y) => {
        const rank = (name?: string) => (name === "HD-1" ? 0 : name === "HD-2" ? 1 : 2);
        return rank(x.serverName) - rank(y.serverName);
      });

      const errors: string[] = [];
      for (const candidate of candidates.slice(0, 3)) {
        const candidateAudio = listFallback ? normalizeType(candidate.dataType) : type;
        try {
          const { resolved, hasDub } = await decryptFlixEmbed(candidate.dataLink, candidateAudio);
          const actualType: "sub" | "dub" =
            candidateAudio === "dub" && !hasDub ? "sub" : candidateAudio;
          const typeFallback = actualType !== type;
          const serverName = candidate.serverName ?? "HD-1";
          const serverId = candidate.$id ?? serverName.toLowerCase();

          await db.insert(sources).values({
            episodeId: epKey,
            animeId: null,
            anilistId: String(anilistId),
            episodeNumber: String(episode),
            provider: "reanime",
            audioType: actualType,
            strategy: "site",
            serverName,
            serverId,
            cmid: "reanime",
            linkId: candidate.dataLink,
            embedUrl: resolved.embedUrl,
            hlsUrl: resolved.hlsUrl,
            manifestKey: resolved.manifestKey ?? null,
            posterUrl: resolved.posterUrl ?? null,
            referer: resolved.referer,
            introStart: resolved.intro?.start ?? null,
            introEnd: resolved.intro?.end ?? null,
            outroStart: resolved.outro?.start ?? null,
            outroEnd: resolved.outro?.end ?? null,
            tracks: resolved.tracks,
            status: "ok",
          });

          const catalog = await catalogPromise;
          return {
            value: {
              resolved,
              actualType,
              typeFallback,
              catalog,
              cached: false,
              server: {
                episodeId: epKey,
                name: serverName,
                serverId,
                cmid: "reanime",
                linkId: candidate.dataLink,
                type: actualType,
              },
            },
            items: 1,
          };
        } catch (err) {
          errors.push(`${candidate.serverName ?? "flix"}: ${errorMessage(err)}`);
        }
      }

      throw new ScrapeError(`reanime.to stream decryption failed — ${errors.join("; ")}`, 502);
    },
  );
}

import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { sources } from "@/db/schema";
import { CACHE } from "@/lib/config";
import { candidateTitles, preferredTitle, type AnilistMedia } from "@/lib/anilist";
import { fetchText } from "@/lib/http";
import { scoreCandidate, searchKeyword, sequelMarker } from "@/lib/match";
import { isFresh, ScrapeError, withJob } from "@/lib/scraper";
import type { ResolvedSource, ServerItem } from "@/lib/types";

const XANIME_BASE = "https://xanime.me";

/** Extracts season number from a title like "X Season 2" / "X 2nd Season". */
function seasonOf(title: string): number | null {
  const n = title.toLowerCase().replace(/[‘’'`´]/g, "");
  const m =
    n.match(/\bseason\s*(\d+)\b/) ??
    n.match(/\b(\d+)\s*(?:st|nd|rd|th)\s+season\b/);
  return m ? Number(m[1]) : null;
}

function targets0(media: AnilistMedia): string {
  return candidateTitles(media)[0] ?? preferredTitle(media);
}

export interface XanimeOutcome {
  resolved: ResolvedSource;
  server: ServerItem;
  actualType: "sub" | "dub";
  typeFallback: boolean;
  match: {
    animeId: string;
    slug: string;
    title: string;
    method: string;
    confidence: number;
    siteUrl: string;
    availableEpisodes: number;
  };
  cached: boolean;
}

/** Extracts the Qwik JSON array `data.objs` from a Qwik HTML document. */
function extractQwikObjs(html: string): unknown[] {
  const m = html.match(/<script\s+type="qwik\/json">([\s\S]*?)<\/script>/);
  if (!m) return [];
  try {
    const parsed = JSON.parse(m[1]) as { objs?: unknown[] };
    return parsed.objs ?? [];
  } catch {
    return [];
  }
}

/**
 * Extracts the AniList ID embedded in a Qwik title page's cover/banner URL
 * (`https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx154587-...`).
 */
function extractQwikAnilistId(objs: unknown[]): number | null {
  for (const o of objs) {
    if (typeof o !== "string") continue;
    const m =
      o.match(/anilistcdn\/media\/anime\/cover\/[^/]+\/b[xm](\d+)-/i) ??
      o.match(/anilistcdn\/media\/anime\/banner\/(\d+)-/i);
    if (m) return Number(m[1]);
  }
  return null;
}

/** Searches xanime.me/search?word={keyword} and returns the best matching /title/{id}-{slug} path. */
async function searchXanime(
  media: AnilistMedia,
): Promise<{ titlePath: string; title: string; confidence: number }> {
  const targets = candidateTitles(media);

  // xanime.me search uses ?word= and matches shorter keywords more reliably.
  const primary = searchKeyword(targets[0] ?? preferredTitle(media));
  const stripped = primary
    .replace(/\b(?:season\s*\d+|\d+(?:st|nd|rd|th)\s+season)\b/gi, "")
    .trim();
  const keywords = [
    primary,
    stripped,
    searchKeyword(targets[1] ?? ""),
    (stripped.split(/\s+/)[0] || "").toLowerCase(),
  ].filter((v, i, a) => v && v.length >= 2 && a.indexOf(v) === i);

  let titleLinks: string[] = [];
  let lastObjs: unknown[] = [];

  for (const kw of keywords) {
    const html = await fetchText(`${XANIME_BASE}/search?word=${encodeURIComponent(kw)}`, {
      referer: `${XANIME_BASE}/`,
    });
    const objs = extractQwikObjs(html);
    const fromState = objs.filter(
      (o): o is string => typeof o === "string" && /^\/title\/\d+-/.test(o),
    );
    const fromDom = Array.from(
      new Set(Array.from(html.matchAll(/href="(\/title\/[0-9]+-[^"?#]+)"/gi)).map((m) => m[1])),
    );
    const combined = Array.from(new Set([...fromState, ...fromDom]));
    if (combined.length) {
      titleLinks = combined;
      lastObjs = objs;
      break;
    }
  }

  if (!titleLinks.length) {
    throw new ScrapeError(`xanime.me is not hosting “${preferredTitle(media)}”`, 404);
  }

  const wantSeason = sequelMarker(targets[0] ?? preferredTitle(media)) ?? null;
  let best: { path: string; score: number; name: string } | null = null;

  for (const path of titleLinks) {
    const id = path.match(/^\/title\/(\d+)/)?.[1] ?? "";
    const slug = path.replace(/^\/title\/\d+-/, "").replace(/-/g, " ");
    const idx = lastObjs.findIndex((o) => o === id || o === Number(id));
    let name = slug;
    if (idx >= 0) {
      for (let j = idx + 1; j < Math.min(lastObjs.length, idx + 6); j += 1) {
        const v = lastObjs[j];
        if (typeof v === "string" && v.length > 2 && !v.startsWith("/") && !v.startsWith("http")) {
          name = v;
          break;
        }
      }
    }
    let s = Math.max(
      scoreCandidate(targets, { title: name }, media.format),
      scoreCandidate(targets, { title: slug }, media.format),
    );
    const candSeason = sequelMarker(name) ?? sequelMarker(slug);
    if (wantSeason && candSeason && wantSeason !== candSeason) s -= 0.25;
    if (!wantSeason && candSeason) s -= 0.15;
    if (!best || s > best.score) best = { path, score: s, name };
  }

  if (!best || best.score < 0.65) {
    throw new ScrapeError(
      `xanime.me does not have “${preferredTitle(media)}” (closest: ${best?.name ?? "none"} @ ${best?.score.toFixed(2) ?? "0"})`,
      404,
    );
  }

  return { titlePath: best.path, title: best.name, confidence: Number(best.score.toFixed(3)) };
}

/**
 * Resolves an AniList id + episode through `xanime.me`.
 */
export async function resolveXanimeStream(params: {
  anilistId: number;
  episode: number;
  type: "sub" | "dub";
  media: AnilistMedia;
  force?: boolean;
}): Promise<XanimeOutcome> {
  const { anilistId, episode, type, media, force = false } = params;
  const epKey = `xanime:${anilistId}:${episode}`;

  if (!force) {
    const rows = await db
      .select()
      .from(sources)
      .where(
        and(
          eq(sources.episodeId, epKey),
          eq(sources.provider, "xanime"),
          eq(sources.status, "ok"),
          eq(sources.audioType, type),
        ),
      )
      .orderBy(desc(sources.resolvedAt))
      .limit(1);
    const cached = rows[0];
    if (cached?.hlsUrl && isFresh(cached.resolvedAt, CACHE.sourceTtlMs)) {
      const siteUrl = cached.linkId?.startsWith("http")
        ? cached.linkId
        : `${XANIME_BASE}${cached.cmid ?? ""}`;
      return {
        cached: true,
        actualType: cached.audioType === "dub" ? "dub" : "sub",
        typeFallback: false,
        server: {
          episodeId: epKey,
          name: cached.serverName ?? "xanivsrc",
          serverId: cached.serverId ?? "1",
          cmid: "xanime",
          linkId: cached.linkId ?? "",
          type: cached.audioType ?? type,
        },
        match: {
          animeId: String(cached.animeId ?? anilistId),
          slug: cached.cmid ?? String(anilistId),
          title: preferredTitle(media),
          method: "cached",
          confidence: 1,
          siteUrl,
          availableEpisodes: media.episodes ?? episode,
        },
        resolved: {
          embedUrl: cached.embedUrl ?? "",
          embedOrigin: cached.embedUrl ? new URL(cached.embedUrl).origin : "https://xanivsrc7.org",
          playerId: null,
          hlsUrl: cached.hlsUrl,
          referer: "https://xanime.me/",
          posterUrl: cached.posterUrl ?? null,
          tracks: (cached.tracks ?? []) as ResolvedSource["tracks"],
          intro:
            cached.introStart != null || cached.introEnd != null
              ? { start: cached.introStart, end: cached.introEnd }
              : null,
          outro:
            cached.outroStart != null || cached.outroEnd != null
              ? { start: cached.outroStart, end: cached.outroEnd }
              : null,
        },
      };
    }
  }

  return withJob<XanimeOutcome>(
    "xanime",
    `xanime.me · anilist ${anilistId} · ep ${episode} · ${type}`,
    async () => {
      const { titlePath, confidence } = await searchXanime(media);
      const titleUrl = `${XANIME_BASE}${titlePath}`;

      // 1. Fetch title page and verify that it actually corresponds to the
      //    requested AniList entry (and not Season 1 when Season 2 was asked).
      const titleHtml = await fetchText(titleUrl, { referer: `${XANIME_BASE}/` });
      const titleObjs = extractQwikObjs(titleHtml);
      const pageAniId = extractQwikAnilistId(titleObjs);
      const wantSeason = seasonOf(preferredTitle(media)) ?? seasonOf(targets0(media));

      if (pageAniId !== null && pageAniId !== media.id) {
        throw new ScrapeError(
          `xanime.me only has AniList #${pageAniId} (${titlePath}) — “${preferredTitle(media)}” (AniList #${media.id}) is not available on xanime.me`,
          404,
        );
      }

      const slugSeason = seasonOf(titlePath.replace(/-/g, " "));
      if (wantSeason && wantSeason > 1 && slugSeason !== wantSeason && pageAniId !== media.id) {
        throw new ScrapeError(
          `“${preferredTitle(media)}” (Season ${wantSeason}) is not available on xanime.me`,
          404,
        );
      }

      const initialWatchMatch = titleHtml.match(/href="(\/title\/\d+-[^"]+\/\d+)"/i);
      if (!initialWatchMatch) {
        throw new ScrapeError(
          `“${preferredTitle(media)}” has no episodes released on xanime.me yet`,
          404,
        );
      }
      const initialWatchPath = initialWatchMatch[1];
      const initialWatchUrl = `${XANIME_BASE}${initialWatchPath}`;

      // 2. Fetch watch page and inspect Qwik state for all episodes
      const watchHtml = await fetchText(initialWatchUrl, { referer: titleUrl });
      const objs = extractQwikObjs(watchHtml);

      // Find all episode strings: "/title/{id}/{epId}-episode-{num}"
      const episodeEntries: Array<{ epId: string; num: number; path: string }> = [];
      for (const obj of objs) {
        if (typeof obj === "string") {
          const m = obj.match(/\/title\/\d+\/(\d+)-episode-(\d+)/i);
          if (m) {
            episodeEntries.push({
              epId: m[1],
              num: Number(m[2]),
              path: obj,
            });
          }
        }
      }

      const matchedEp = episodeEntries.find((e) => e.num === episode);
      if (!matchedEp) {
        const nums = episodeEntries.map((e) => e.num).sort((a, b) => a - b);
        const range = nums.length ? `episodes ${nums[0]}–${nums[nums.length - 1]}` : "no episodes";
        throw new ScrapeError(
          `episode ${episode} is not available on xanime.me (${range} available)`,
          404,
        );
      }

      let targetWatchHtml = watchHtml;
      let targetWatchUrl = initialWatchUrl;

      if (!initialWatchPath.includes(matchedEp.epId)) {
        const targetWatchPath = `/title/${titlePath.split("/")[2]}/${matchedEp.epId}`;
        targetWatchUrl = `${XANIME_BASE}${targetWatchPath}`;
        targetWatchHtml = await fetchText(targetWatchUrl, { referer: titleUrl });
      }

      // 3. Extract direct master.m3u8 from the target episode's Qwik state
      const targetObjs = extractQwikObjs(targetWatchHtml);
      const m3u8Urls = targetObjs.filter(
        (x): x is string =>
          typeof x === "string" && x.includes(".m3u8") && /^https?:\/\//i.test(x),
      );

      if (!m3u8Urls.length) {
        throw new ScrapeError(
          `xanime.me watch page did not contain an HLS stream for episode ${episode}`,
          502,
        );
      }

      const hlsUrl = m3u8Urls[0];
      const resolved: ResolvedSource = {
        embedUrl: targetWatchUrl,
        embedOrigin: new URL(hlsUrl).origin,
        playerId: null,
        hlsUrl,
        referer: "https://xanime.me/",
        posterUrl: null,
        tracks: [],
        intro: null,
        outro: null,
      };

      await db
        .insert(sources)
        .values({
          episodeId: epKey,
          animeId: titlePath,
          anilistId: String(anilistId),
          episodeNumber: String(episode),
          provider: "xanime",
          audioType: type,
          strategy: "site",
          serverName: "xanivsrc",
          serverId: "1",
          cmid: titlePath,
          linkId: targetWatchUrl,
          embedUrl: targetWatchUrl,
          hlsUrl,
          posterUrl: null,
          referer: "https://xanime.me/",
          introStart: null,
          introEnd: null,
          outroStart: null,
          outroEnd: null,
          tracks: resolved.tracks,
          status: "ok",
        })
        .catch(() => undefined);

      return {
        value: {
          resolved,
          server: {
            episodeId: epKey,
            name: "xanivsrc",
            serverId: "1",
            cmid: titlePath,
            linkId: targetWatchUrl,
            type,
          },
          actualType: type,
          typeFallback: false,
          match: {
            animeId: titlePath,
            slug: titlePath,
            title: preferredTitle(media),
            method: pageAniId === media.id ? "anilist-verified" : "qwik-state",
            confidence,
            siteUrl: targetWatchUrl,
            availableEpisodes: episodeEntries.length || (media.episodes ?? episode),
          },
          cached: false,
        },
        items: 1,
      };
    },
  );
}

import { PLAYER, SITE } from "./config";
import { decryptSourcesPayload, extractHlsUrls } from "./crypto";
import { fetchJson, fetchText } from "./http";
import { parseEmbedSettings, parsePlayerIds } from "./parse";
import type { ResolvedSource, SkipRange } from "./types";

interface SourcesResponse {
  enc?: string;
  tracks?: Array<Record<string, unknown>>;
  intro?: { start?: number; end?: number } | number[];
  outro?: { start?: number; end?: number } | number[];
  server?: number | string;
  image?: string;
  sources?: Array<{ file?: string; url?: string; quality?: string } | string>;
  file?: string;
  [key: string]: unknown;
}

function normaliseSkip(value: unknown): SkipRange | null {
  if (!value) return null;
  if (Array.isArray(value)) {
    const [start, end] = value as number[];
    if (typeof start === "number" && typeof end === "number") return { start, end };
    return null;
  }
  if (typeof value === "object") {
    const rec = value as Record<string, unknown>;
    const start = typeof rec.start === "number" ? rec.start : null;
    const end = typeof rec.end === "number" ? rec.end : null;
    if (start !== null || end !== null) return { start, end };
  }
  return null;
}

function normaliseTracks(value: unknown): ResolvedSource["tracks"] {
  if (!Array.isArray(value)) return [];
  return value
    .map((t) => {
      if (!t || typeof t !== "object") return null;
      const rec = t as Record<string, unknown>;
      const file = typeof rec.file === "string" ? rec.file : null;
      if (!file) return null;
      return {
        file,
        label: typeof rec.label === "string" ? rec.label : undefined,
        kind: typeof rec.kind === "string" ? rec.kind : undefined,
        default: rec.default === true,
      };
    })
    .filter((t): t is NonNullable<typeof t> => t !== null);
}

/**
 * Walks the last two hops of the chain:
 *
 *   embed page  ->  player data-id  ->  /stream/getSourcesNew?id=…  ->  AES decrypt  ->  master.m3u8
 *
 * The embed host rejects requests that do not carry the site as `Referer`, and
 * the CDN later rejects requests that do not carry the embed host, so both are
 * threaded through and returned for the proxy to reuse.
 */
export async function resolveEmbedToHls(embedUrl: string): Promise<ResolvedSource> {
  const parsed = new URL(embedUrl);
  const origin = parsed.origin;

  // Use the embed's own origin as referer when it is not one of the known
  // anikoto/megaplay hosts — many third-party embeds (animotvslash.ru,
  // vidnest, etc.) reject cross-origin referers with 403.
  let embedReferer = `${SITE.baseUrl}/`;
  try {
    const host = new URL(embedUrl).host;
    if (!/megaplay\.buzz|anikototv\.to|vhscdn\.to|echovideo\.to/i.test(host)) {
      embedReferer = `${new URL(embedUrl).origin}/`;
    }
  } catch {
    /* keep default */
  }
  const embedHtml = await fetchText(embedUrl, { referer: embedReferer });

  // Fast path: some embeds inline the playlist.
  const inline = embedHtml.match(/https?:\\?\/\\?\/[^"'\s\\]+?\.m3u8[^"'\s\\]*/i);
  const ids = parsePlayerIds(embedHtml);
  const settings = parseEmbedSettings(embedHtml);

  const base = settings.base_url ? settings.base_url.replace(/\/+$/, "") : origin;
  const playerId = ids.id ?? ids.realId ?? ids.mediaId;

  const result: ResolvedSource = {
    embedUrl,
    embedOrigin: origin,
    playerId,
    hlsUrl: null,
    referer: PLAYER.cdnReferer,
    posterUrl: null,
    tracks: [],
    intro: null,
    outro: null,
    decrypted: null,
  };

  if (!playerId) {
    if (inline) {
      result.hlsUrl = inline[0].replace(/\\\//g, "/");
      result.referer = `${origin}/`;
    }
    if (!result.hlsUrl) {
      throw new Error("embed page did not expose a player id");
    }
    return result;
  }

  const sourcesUrl = new URL(PLAYER.sourcesPath, `${base}/`);
  sourcesUrl.searchParams.set("id", playerId);
  // The player mirrors the embed's `s` query flag onto the sources request.
  const flag = parsed.searchParams.get("s") ?? settings.s ?? "";
  if (flag) sourcesUrl.searchParams.set("s", flag);

  const body = await fetchJson<SourcesResponse>(sourcesUrl.toString(), {
    referer: embedUrl,
    xhr: true,
  });

  result.raw = body as unknown as Record<string, unknown>;
  result.tracks = normaliseTracks(body.tracks);
  result.intro = normaliseSkip(body.intro);
  result.outro = normaliseSkip(body.outro);
  result.posterUrl = typeof body.image === "string" ? body.image : null;
  // Playlist requests must be sent with the embed host as referer.
  result.referer = `${origin}/`;

  if (typeof body.enc === "string" && body.enc.length) {
    const decrypted = decryptSourcesPayload(body.enc);
    result.decrypted = decrypted;
    const urls = extractHlsUrls(decrypted);
    if (urls.length) result.hlsUrl = urls[0];
  }

  if (!result.hlsUrl) {
    const plain = extractHlsUrls(body as Record<string, unknown>);
    if (plain.length) result.hlsUrl = plain[0];
  }

  if (!result.hlsUrl && inline) {
    result.hlsUrl = inline[0].replace(/\\\//g, "/");
  }

  if (!result.hlsUrl) {
    throw new Error("no HLS playlist found in the sources response");
  }

  return result;
}

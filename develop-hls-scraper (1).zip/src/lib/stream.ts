import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { anilistMappings, animes, sources, type AnilistMappingRow } from "@/db/schema";
import { ANILIST, CACHE, PLAYER, REANIME, SITE } from "./config";
import {
  AnilistError,
  candidateTitles,
  fetchAnilistMedia,
  preferredTitle,
  type AnilistMedia,
} from "./anilist";
import {
  buildHlsProxyUrl,
  computeProxyExpiry,
  sealHlsContext,
} from "./hls-proxy";
import { scoreCandidate, searchKeyword } from "./match";
import { resolveEmbedToHls } from "./player";
import { resolveAniwavesStream } from "./providers/aniwaves";
import { resolveAniPmStream } from "./providers/anipm";
import { resolveKaaStream } from "./providers/kaa";
import { resolveAtvStream } from "./providers/animetvplus";
import { resolveAnizoneStream } from "./providers/anizone";
import { resolveXanimeStream } from "./providers/xanime";
import { resolveAnimeggStream } from "./providers/animegg";
import { resolveAnimotvslashStream, resolveXmarkStream } from "./providers/animotvslash";

import { resolveReanimeStream } from "./providers/reanime";
import { GENERIC_SITES, resolveGenericStream } from "./providers/generic";
import { BROWSER_SITES, resolveBrowserStream } from "./providers/browser";
import { buildRelayUrl } from "./relay";
import {
  errorMessage,
  getAnime,
  isFresh,
  resolveSource,
  ScrapeError,
  searchAnimes,
  withJob,
  type SourceOutcome,
} from "./scraper";
import type {
  AnimeListItem,
  EpisodeItem,
  ResolvedSource,
  ScraperProvider,
  SkipRange,
} from "./types";

export type AudioType = "sub" | "dub";
export type Strategy = "auto" | "site" | "direct";
export type ProviderSelection = ScraperProvider | "auto" | (string & {});

export interface StreamRequest {
  anilistId: number;
  episode: number;
  type: AudioType;
  provider?: ProviderSelection;
  strategy: Strategy;
  force?: boolean;
}

export interface StreamAttempt {
  step: "anilist" | "map" | "site" | "direct" | "reanime" | "aniwaves";
  ok: boolean;
  detail?: string;
}

export interface SiteMatch {
  animeId: string;
  slug: string;
  title: string;
  method: string;
  confidence: number;
  malId: string | null;
  siteUrl: string;
  cached: boolean;
}

export interface AnilistSummary {
  id: number;
  idMal: number | null;
  title: string;
  romaji: string | null;
  english: string | null;
  native: string | null;
  format: string | null;
  status: string | null;
  episodes: number | null;
  seasonYear: number | null;
  season: string | null;
  cover: string | null;
  banner: string | null;
  color: string | null;
  genres: string[];
  averageScore: number | null;
  nextAiringEpisode: { episode: number; airingAt: number } | null;
  url: string;
}

export interface StreamPayload {
  anilistId: number;
  episode: number;
  requestedProvider: ProviderSelection;
  provider: ScraperProvider;
  requestedType: AudioType;
  type: string;
  typeFallback: boolean;
  strategy: "site" | "direct";
  stream: {
    /** Upstream master playlist — requires `referer` (and XOR decode for FlixCloud `_v7`). */
    m3u8: string;
    /** Stateless sealed-context `/proxy/hls?...&ctx=c1...` URL (works directly in any player). */
    proxied: string;
    /** Same `/proxy/hls` URL tagged with `&purpose=probe` for health checks. */
    probe: string;
    /** Sealed AES-256-GCM context token (`c1.<ctxExp>.<iv>.<ct>.<tag>`). */
    proxyCtx: string;
    proxyExp: number;
    /** Optional base64 32-byte XOR manifest key (`window.__pk` for FlixCloud `_v7`). */
    manifestKey: string | null;
    /** Legacy `/api/relay` path for non-encrypted streams. */
    legacyRelay: string;
    referer: string;
    headers: Record<string, string>;
    subtitles: Array<{
      file: string;
      label: string | null;
      format: string | null;
      default: boolean;
      proxied: string;
    }>;
    thumbnails: string | null;
    intro: SkipRange | null;
    outro: SkipRange | null;
    poster: string | null;
    server: { name: string; id: string } | null;
    embed: string;
  };
  anilist: AnilistSummary | null;
  match:
    | (SiteMatch & {
        episodeId: string;
        episodeTitle: string | null;
        availableEpisodes: number;
        firstEpisode: string | null;
        lastEpisode: string | null;
      })
    | null;
  attempts: StreamAttempt[];
  cached: boolean;
  tookMs: number;
}

/* ------------------------------------------------------------- AniList meta */

async function loadMappingRow(anilistId: number): Promise<AnilistMappingRow | null> {
  const rows = await db
    .select()
    .from(anilistMappings)
    .where(eq(anilistMappings.anilistId, anilistId))
    .limit(1);
  return rows[0] ?? null;
}

/** AniList metadata, cached in Postgres to stay well under their rate limit. */
export async function getAnilistMedia(
  anilistId: number,
  force = false,
): Promise<{ media: AnilistMedia; row: AnilistMappingRow | null; cached: boolean }> {
  const row = await loadMappingRow(anilistId);
  if (!force && row?.meta && isFresh(row.metaFetchedAt, ANILIST.metaTtlMs)) {
    return { media: row.meta as unknown as AnilistMedia, row, cached: true };
  }

  try {
    const media = await fetchAnilistMedia(anilistId);
    const values = {
      malId: media.idMal,
      title: preferredTitle(media),
      meta: media as unknown as Record<string, unknown>,
      metaFetchedAt: new Date(),
      updatedAt: new Date(),
    };
    await db
      .insert(anilistMappings)
      .values({ anilistId, ...values })
      .onConflictDoUpdate({ target: anilistMappings.anilistId, set: values });
    return { media, row: await loadMappingRow(anilistId), cached: false };
  } catch (err) {
    if (row?.meta && !(err instanceof AnilistError && err.statusCode === 404)) {
      return { media: row.meta as unknown as AnilistMedia, row, cached: true };
    }
    throw err;
  }
}

export function summarizeAnilist(media: AnilistMedia): AnilistSummary {
  return {
    id: media.id,
    idMal: media.idMal,
    title: preferredTitle(media),
    romaji: media.title.romaji,
    english: media.title.english,
    native: media.title.native,
    format: media.format,
    status: media.status,
    episodes: media.episodes,
    seasonYear: media.seasonYear,
    season: media.season,
    cover: media.coverImage?.extraLarge ?? media.coverImage?.large ?? null,
    banner: media.bannerImage,
    color: media.coverImage?.color ?? null,
    genres: media.genres ?? [],
    averageScore: media.averageScore,
    nextAiringEpisode: media.nextAiringEpisode,
    url: `https://anilist.co/anime/${media.id}`,
  };
}

/* ----------------------------------------------------- anikototv.to mapping */

async function saveMapping(
  media: AnilistMedia,
  target: { animeId: string; slug: string; title: string } | null,
  method: string,
  confidence: number,
) {
  const values = {
    malId: media.idMal,
    animeId: target?.animeId ?? null,
    slug: target?.slug ?? null,
    siteTitle: target?.title ?? null,
    method,
    confidence,
    title: preferredTitle(media),
    mappedAt: new Date(),
    updatedAt: new Date(),
  };
  await db
    .insert(anilistMappings)
    .values({ anilistId: media.id, ...values })
    .onConflictDoUpdate({ target: anilistMappings.anilistId, set: values });

  if (target) {
    await db
      .update(animes)
      .set({ anilistId: String(media.id) })
      .where(eq(animes.id, target.animeId))
      .catch(() => undefined);
  }
}

export async function mapToSite(
  media: AnilistMedia,
  row: AnilistMappingRow | null,
  force = false,
): Promise<SiteMatch> {
  if (!force && row?.animeId && row.slug && row.method !== "unmatched") {
    return {
      animeId: row.animeId,
      slug: row.slug,
      title: row.siteTitle ?? row.slug,
      method: row.method,
      confidence: row.confidence,
      malId: row.malId != null ? String(row.malId) : null,
      siteUrl: `${SITE.baseUrl}/watch/${row.slug}`,
      cached: true,
    };
  }
  if (!force && row?.method === "unmatched" && isFresh(row.mappedAt, ANILIST.unmatchedTtlMs)) {
    throw new ScrapeError(`no site match for AniList ${media.id} (recent miss cached)`, 404);
  }

  return withJob<SiteMatch>("map", `anilist ${media.id} → anikoto`, async () => {
    const malId = media.idMal != null ? String(media.idMal) : null;
    const done = (
      target: { animeId: string; slug: string; title: string },
      method: string,
      confidence: number,
    ) =>
      saveMapping(media, target, method, confidence).then(() => ({
        value: {
          ...target,
          method,
          confidence,
          malId,
          siteUrl: `${SITE.baseUrl}/watch/${target.slug}`,
          cached: false,
        } satisfies SiteMatch,
        items: 1,
      }));

    if (malId) {
      const local = await db.select().from(animes).where(eq(animes.malId, malId)).limit(1);
      if (local[0]) {
        return done({ animeId: local[0].id, slug: local[0].slug, title: local[0].title }, "mal-cache", 1);
      }
    }

    const targets = candidateTitles(media);
    if (!targets.length) throw new ScrapeError("AniList entry has no usable titles", 422);

    const pool = new Map<string, AnimeListItem>();
    for (const title of targets.slice(0, 3)) {
      try {
        const result = await searchAnimes(searchKeyword(title), 1);
        for (const item of result.items) if (!pool.has(item.id)) pool.set(item.id, item);
      } catch {
        continue;
      }
      const nearExact = [...pool.values()].some((c) => scoreCandidate(targets, c, media.format) >= 0.97);
      if (nearExact) break;
    }

    const ranked = [...pool.values()]
      .map((c) => ({ c, score: scoreCandidate(targets, c, media.format) }))
      .sort((a, b) => b.score - a.score);

    const mismatched = new Set<string>();
    if (malId) {
      for (const { c, score } of ranked.slice(0, 5)) {
        if (score < 0.3) break;
        try {
          const outcome = await getAnime(c.slug, false, { requireMal: true });
          const siteMal = outcome.detail.malId ?? null;
          if (siteMal === malId) {
            return done(
              { animeId: outcome.detail.id, slug: outcome.detail.slug, title: outcome.detail.title },
              "mal-verified",
              1,
            );
          }
          if (siteMal) mismatched.add(c.id);
        } catch {
          continue;
        }
      }
    }

    const fallback = ranked.find((r) => r.score >= ANILIST.titleThreshold && !mismatched.has(r.c.id));
    if (fallback) {
      return done(
        { animeId: fallback.c.id, slug: fallback.c.slug, title: fallback.c.title },
        "title-match",
        Number(fallback.score.toFixed(3)),
      );
    }

    await saveMapping(media, null, "unmatched", ranked[0]?.score ?? 0);
    const best = ranked[0] ? ` (closest: “${ranked[0].c.title}” at ${ranked[0].score.toFixed(2)})` : "";
    throw new ScrapeError(`no site match for “${preferredTitle(media)}”${best}`, 404);
  });
}

/* ----------------------------------------------------------------- episode */

function pickEpisode(list: EpisodeItem[], number: number): EpisodeItem | undefined {
  return list.find((e) => Number(e.number) === number) ?? list.find((e) => e.number === String(number));
}

function describeRange(list: EpisodeItem[]): string {
  if (!list.length) return "the site lists no episodes";
  const nums = list.map((e) => Number(e.number)).filter(Number.isFinite);
  if (!nums.length) return `the site lists ${list.length} episode(s)`;
  return `the site has episodes ${Math.min(...nums)}–${Math.max(...nums)}`;
}

export async function findEpisode(slug: string, number: number) {
  let outcome = await getAnime(slug);
  let episode = pickEpisode(outcome.episodes, number);
  if (!episode && outcome.cached) {
    outcome = await getAnime(slug, true);
    episode = pickEpisode(outcome.episodes, number);
  }
  if (!episode) {
    throw new ScrapeError(`episode ${number} is not on the site — ${describeRange(outcome.episodes)}`, 404);
  }
  return { episode, outcome };
}

/* ----------------------------------------------------------- direct player */

interface DirectOutcome {
  resolved: ResolvedSource;
  type: AudioType;
  cached: boolean;
}

function directKey(anilistId: number, episode: number) {
  return `ani:${anilistId}:${episode}`;
}

async function resolveDirectOnce(
  anilistId: number,
  episode: number,
  type: AudioType,
  force: boolean,
): Promise<DirectOutcome> {
  const key = directKey(anilistId, episode);

  if (!force) {
    const rows = await db
      .select()
      .from(sources)
      .where(
        and(
          eq(sources.episodeId, key),
          eq(sources.provider, "anikoto"),
          eq(sources.status, "ok"),
          eq(sources.audioType, type),
        ),
      )
      .orderBy(desc(sources.resolvedAt))
      .limit(1);
    const row = rows[0];
    if (row?.hlsUrl && isFresh(row.resolvedAt, CACHE.sourceTtlMs)) {
      return {
        type,
        cached: true,
        resolved: {
          embedUrl: row.embedUrl ?? "",
          embedOrigin: row.embedUrl ? new URL(row.embedUrl).origin : "",
          playerId: null,
          hlsUrl: row.hlsUrl,
          referer: row.referer ?? PLAYER.cdnReferer,
          posterUrl: row.posterUrl,
          tracks: (row.tracks ?? []) as ResolvedSource["tracks"],
          intro: row.introStart != null ? { start: row.introStart, end: row.introEnd } : null,
          outro: row.outroStart != null ? { start: row.outroStart, end: row.outroEnd } : null,
        },
      };
    }
  }

  const embedUrl = PLAYER.directEmbedTemplate
    .replace("{anilistId}", String(anilistId))
    .replace("{episode}", String(episode))
    .replace("{type}", type);

  return withJob<DirectOutcome>("direct", `anilist ${anilistId} · ep ${episode} · ${type}`, async () => {
    const resolved = await resolveEmbedToHls(embedUrl);
    await db.insert(sources).values({
      episodeId: key,
      animeId: null,
      anilistId: String(anilistId),
      episodeNumber: String(episode),
      provider: "anikoto",
      audioType: type,
      strategy: "direct",
      serverName: "direct",
      embedUrl,
      hlsUrl: resolved.hlsUrl,
      posterUrl: resolved.posterUrl ?? null,
      referer: resolved.referer,
      introStart: resolved.intro?.start ?? null,
      introEnd: resolved.intro?.end ?? null,
      outroStart: resolved.outro?.start ?? null,
      outroEnd: resolved.outro?.end ?? null,
      tracks: resolved.tracks,
      status: "ok",
    });
    return { value: { resolved, type, cached: false }, items: 1 };
  });
}

async function resolveDirect(anilistId: number, episode: number, type: AudioType, force: boolean) {
  try {
    return await resolveDirectOnce(anilistId, episode, type, force);
  } catch (err) {
    if (type === "dub") return resolveDirectOnce(anilistId, episode, "sub", force);
    throw err;
  }
}

/* ----------------------------------------------------------------- payload */

function streamBlock(
  resolved: ResolvedSource,
  server: { name: string; id: string } | null,
  meta: {
    provider: ScraperProvider;
    audio: "sub" | "dub";
    anilistId: number;
    episode: number;
  },
) {
  const hls = resolved.hlsUrl ?? "";
  const referer = resolved.referer || PLAYER.cdnReferer;
  let originHeader = "https://megaplay.buzz";
  try {
    originHeader = new URL(referer).origin;
  } catch {
    /* keep default */
  }

  const exp = computeProxyExpiry();
  const proxyCtx = sealHlsContext({
    p: meta.provider,
    ...(resolved.manifestKey ? { pk: resolved.manifestKey } : {}),
    ref: referer,
    org: originHeader,
    aud: meta.audio,
    aid: meta.anilistId,
    ep: meta.episode,
  });

  const proxied = buildHlsProxyUrl(hls, {
    ref: referer,
    ctx: proxyCtx,
    exp,
    purpose: "playback",
  });
  const probe = buildHlsProxyUrl(hls, {
    ref: referer,
    ctx: proxyCtx,
    exp,
    purpose: "probe",
  });

  // Separate subtitle context converts `.ass`/`.ssa`/`.srt` cues into WebVTT on the fly.
  const subCtx = sealHlsContext({
    p: meta.provider,
    ref: referer,
    org: originHeader,
    sub: "vtt",
    aid: meta.anilistId,
    ep: meta.episode,
  });

  const captions = resolved.tracks.filter((t) => (t.kind ?? "captions") !== "thumbnails");
  return {
    m3u8: hls,
    proxied,
    probe,
    proxyCtx,
    proxyExp: exp,
    manifestKey: resolved.manifestKey ?? null,
    legacyRelay: buildRelayUrl(hls),
    referer,
    headers: { Referer: referer, Origin: originHeader, "User-Agent": SITE.userAgent },
    subtitles: captions.map((t) => ({
      file: t.file,
      label: t.label ?? null,
      format: t.format ?? (t.file.match(/\.(vtt|srt|ass|ssa)(?:$|[?#])/i)?.[1]?.toLowerCase() ?? null),
      default: Boolean(t.default),
      proxied: buildHlsProxyUrl(t.file, { ref: referer, ctx: subCtx, exp }),
    })),
    thumbnails: resolved.tracks.find((t) => t.kind === "thumbnails")?.file ?? null,
    intro: resolved.intro ?? null,
    outro: resolved.outro ?? null,
    poster: resolved.posterUrl ?? null,
    server,
    embed: resolved.embedUrl,
  };
}

function siteStatus(err: unknown): number {
  return err instanceof ScrapeError || err instanceof AnilistError ? err.statusCode : 502;
}

/* -------------------------------------------------------- per-provider run */

async function runAnikotoProvider(params: {
  req: StreamRequest;
  media: AnilistMedia | null;
  row: AnilistMappingRow | null;
  attempts: StreamAttempt[];
  started: number;
  requestedProvider: ProviderSelection;
}): Promise<StreamPayload> {
  const { req, media, row, attempts, started, requestedProvider } = params;
  const force = Boolean(req.force);
  let siteError: unknown = null;

  if (req.strategy !== "direct" && media) {
    try {
      const match = await mapToSite(media, row, force);
      attempts.push({ step: "map", ok: true, detail: `anikoto · ${match.title} (${match.method})` });

      const { episode, outcome } = await findEpisode(match.slug, req.episode);
      const src: SourceOutcome = await resolveSource(episode.id, { type: req.type }, force, {
        anilistId: req.anilistId,
      });
      attempts.push({ step: "site", ok: true, detail: `anikoto · ${src.server.type}/${src.server.name}` });

      const actualAudio: AudioType = src.server.type === "dub" ? "dub" : "sub";
      const nums = outcome.episodes.map((e) => e.number);
      return {
        anilistId: req.anilistId,
        episode: req.episode,
        requestedProvider,
        provider: "anikoto",
        requestedType: req.type,
        type: src.server.type,
        typeFallback: src.typeFallback,
        strategy: "site",
        stream: streamBlock(src.resolved, { name: src.server.name, id: src.server.serverId }, {
          provider: "anikoto",
          audio: actualAudio,
          anilistId: req.anilistId,
          episode: req.episode,
        }),
        anilist: summarizeAnilist(media),
        match: {
          ...match,
          episodeId: episode.id,
          episodeTitle: episode.title ?? null,
          availableEpisodes: outcome.episodes.length,
          firstEpisode: nums[0] ?? null,
          lastEpisode: nums[nums.length - 1] ?? null,
        },
        attempts,
        cached: src.cached,
        tookMs: Date.now() - started,
      };
    } catch (err) {
      siteError = err;
      attempts.push({ step: "site", ok: false, detail: `anikoto · ${errorMessage(err)}` });
      if (req.strategy === "site") {
        throw new ScrapeError(errorMessage(err), siteStatus(err), attempts);
      }
    }
  }

  try {
    const direct = await resolveDirect(req.anilistId, req.episode, req.type, force);
    attempts.push({ step: "direct", ok: true, detail: `anikoto/megaplay · ${direct.type}` });
    return {
      anilistId: req.anilistId,
      episode: req.episode,
      requestedProvider,
      provider: "anikoto",
      requestedType: req.type,
      type: direct.type,
      typeFallback: direct.type !== req.type,
      strategy: "direct",
      stream: streamBlock(direct.resolved, { name: "direct", id: "ani" }, {
        provider: "anikoto",
        audio: direct.type,
        anilistId: req.anilistId,
        episode: req.episode,
      }),
      anilist: media ? summarizeAnilist(media) : null,
      match: null,
      attempts,
      cached: direct.cached,
      tookMs: Date.now() - started,
    };
  } catch (err) {
    attempts.push({ step: "direct", ok: false, detail: `anikoto/megaplay · ${errorMessage(err)}` });
    const status = siteError ? siteStatus(siteError) : 502;
    throw new ScrapeError(
      `anikototv.to could not resolve AniList ${req.anilistId} ep ${req.episode}`,
      status === 404 ? 404 : 502,
      attempts,
    );
  }
}

async function runReanimeProvider(params: {
  req: StreamRequest;
  media: AnilistMedia | null;
  attempts: StreamAttempt[];
  started: number;
  requestedProvider: ProviderSelection;
}): Promise<StreamPayload> {
  const { req, media, attempts, started, requestedProvider } = params;
  const force = Boolean(req.force);

  const out = await resolveReanimeStream({
    anilistId: req.anilistId,
    malId: media?.idMal ?? null,
    episode: req.episode,
    type: req.type,
    media,
    force,
  });

  attempts.push({
    step: "reanime",
    ok: true,
    detail: `reanime.to · ${out.actualType}/${out.server.name}${out.cached ? " (cached)" : ""}`,
  });

  const slug = out.catalog?.slug ?? String(req.anilistId);
  const totalEps = out.catalog?.episodes || media?.episodes || req.episode;

  return {
    anilistId: req.anilistId,
    episode: req.episode,
    requestedProvider,
    provider: "reanime",
    requestedType: req.type,
    type: out.actualType,
    typeFallback: out.typeFallback,
    strategy: "site",
    stream: streamBlock(out.resolved, { name: out.server.name, id: out.server.serverId }, {
      provider: "reanime",
      audio: out.actualType,
      anilistId: req.anilistId,
      episode: req.episode,
    }),
    anilist: media ? summarizeAnilist(media) : null,
    match: {
      animeId: slug,
      slug,
      title: out.catalog?.title ?? (media ? preferredTitle(media) : `AniList #${req.anilistId}`),
      method: "anilist-id",
      confidence: 1,
      malId: media?.idMal != null ? String(media.idMal) : null,
      siteUrl: `${REANIME.baseUrl}/watch/${slug}`,
      cached: out.cached,
      episodeId: `ep-${req.episode}`,
      episodeTitle: null,
      availableEpisodes: totalEps,
      firstEpisode: "1",
      lastEpisode: totalEps ? String(totalEps) : null,
    },
    attempts,
    cached: out.cached,
    tookMs: Date.now() - started,
  };
}

async function runAniwavesProvider(params: {
  req: StreamRequest;
  media: AnilistMedia | null;
  attempts: StreamAttempt[];
  started: number;
  requestedProvider: ProviderSelection;
}): Promise<StreamPayload> {
  const { req, media, attempts, started, requestedProvider } = params;
  if (!media) {
    throw new ScrapeError("AniList metadata is required to search aniwaves.ru", 502, attempts);
  }
  const out = await resolveAniwavesStream({
    anilistId: req.anilistId,
    episode: req.episode,
    type: req.type,
    media,
    force: Boolean(req.force),
  });

  attempts.push({
    step: "aniwaves",
    ok: true,
    detail: `aniwaves.ru · ${out.actualType}/${out.server.name}${out.cached ? " (cached)" : ""}`,
  });

  const actualAudio: AudioType = out.actualType === "dub" ? "dub" : "sub";
  return {
    anilistId: req.anilistId,
    episode: req.episode,
    requestedProvider,
    provider: "aniwaves",
    requestedType: req.type,
    type: out.actualType,
    typeFallback: out.typeFallback,
    strategy: "site",
    stream: streamBlock(out.resolved, { name: out.server.name, id: out.server.serverId }, {
      provider: "aniwaves",
      audio: actualAudio,
      anilistId: req.anilistId,
      episode: req.episode,
    }),
    anilist: summarizeAnilist(media),
    match: {
      animeId: out.match.animeId,
      slug: out.match.slug,
      title: out.match.title,
      method: out.match.method,
      confidence: out.match.confidence,
      malId: media.idMal != null ? String(media.idMal) : null,
      siteUrl: out.match.siteUrl,
      cached: out.cached,
      episodeId: `${out.match.animeId}:${req.episode}`,
      episodeTitle: out.match.episodeTitle,
      availableEpisodes: out.match.availableEpisodes,
      firstEpisode: out.match.firstEpisode,
      lastEpisode: out.match.lastEpisode,
    },
    attempts,
    cached: out.cached,
    tookMs: Date.now() - started,
  };
}

/* ------------------------------------------------------- generic providers */

async function runGenericProvider(params: {
  req: StreamRequest;
  media: AnilistMedia | null;
  siteId: string;
  attempts: StreamAttempt[];
  started: number;
  requestedProvider: ProviderSelection;
}): Promise<StreamPayload> {
  const { req, media, siteId, attempts, started, requestedProvider } = params;
  if (!media) throw new ScrapeError("AniList metadata is required for this provider", 502, attempts);
  const out = await resolveGenericStream({
    siteId, anilistId: req.anilistId, episode: req.episode, type: req.type, media,
    force: Boolean(req.force),
  });
  attempts.push({ step: "site", ok: true, detail: `${out.match.siteLabel} · ${out.match.title}${out.cached ? " (cached)" : ""}` });
  const actualAudio: AudioType = out.server.type === "dub" ? "dub" : "sub";
  return {
    anilistId: req.anilistId, episode: req.episode, requestedProvider,
    provider: "anikoto", requestedType: req.type, type: out.server.type,
    typeFallback: actualAudio !== req.type, strategy: "site",
    stream: streamBlock(out.resolved, { name: out.server.name, id: out.server.serverId }, {
      provider: "anikoto", audio: actualAudio, anilistId: req.anilistId, episode: req.episode,
    }),
    anilist: summarizeAnilist(media),
    match: {
      animeId: out.match.animePath, slug: out.match.animePath, title: out.match.title,
      method: "title-match", confidence: out.match.confidence,
      malId: media.idMal != null ? String(media.idMal) : null,
      siteUrl: out.match.animePath, cached: out.cached,
      episodeId: out.match.episodePath ?? `ep-${req.episode}`,
      episodeTitle: out.match.episodeTitle,
      availableEpisodes: out.match.availableEpisodes,
      firstEpisode: "1", lastEpisode: String(out.match.availableEpisodes),
    },
    attempts, cached: out.cached, tookMs: Date.now() - started,
  };
}

/* -------------------------------------------------------- browser providers */

async function runBrowserProvider(params: {
  req: StreamRequest;
  media: AnilistMedia | null;
  siteId: string;
  attempts: StreamAttempt[];
  started: number;
  requestedProvider: ProviderSelection;
}): Promise<StreamPayload> {
  const { req, media, siteId, attempts, started, requestedProvider } = params;
  if (!media) throw new ScrapeError("AniList metadata is required for this provider", 502, attempts);

  const out = await resolveBrowserStream({
    siteId,
    anilistId: req.anilistId,
    episode: req.episode,
    type: req.type,
    media,
    force: Boolean(req.force),
  });

  attempts.push({
    step: "site",
    ok: true,
    detail: `${out.match.siteLabel} (headless) · ${out.match.title}${out.cached ? " (cached)" : ""}`,
  });

  const actualAudio: AudioType = out.resolved.tracks.length ? req.type : req.type;
  return {
    anilistId: req.anilistId,
    episode: req.episode,
    requestedProvider,
    provider: "anikoto",
    requestedType: req.type,
    type: actualAudio,
    typeFallback: false,
    strategy: "site",
    stream: streamBlock(out.resolved, { name: "browser", id: "1" }, {
      provider: "anikoto",
      audio: actualAudio,
      anilistId: req.anilistId,
      episode: req.episode,
    }),
    anilist: summarizeAnilist(media),
    match: {
      animeId: out.match.animeUrl,
      slug: out.match.animeUrl,
      title: out.match.title,
      method: "title-match",
      confidence: out.match.confidence,
      malId: media.idMal != null ? String(media.idMal) : null,
      siteUrl: out.match.animeUrl,
      cached: out.cached,
      episodeId: out.match.episodeUrl ?? `ep-${req.episode}`,
      episodeTitle: null,
      availableEpisodes: out.match.availableEpisodes,
      firstEpisode: "1",
      lastEpisode: String(out.match.availableEpisodes),
    },
    attempts,
    cached: out.cached,
    tookMs: Date.now() - started,
  };
}

async function runXmarkProvider(params: {
  req: StreamRequest;
  media: AnilistMedia | null;
  attempts: StreamAttempt[];
  started: number;
  requestedProvider: ProviderSelection;
}): Promise<StreamPayload> {
  const { req, media, attempts, started, requestedProvider } = params;
  if (!media) throw new ScrapeError("AniList metadata is required for this provider", 502, attempts);
  const out = await resolveXmarkStream({
    anilistId: req.anilistId,
    episode: req.episode,
    type: req.type,
    media,
    force: Boolean(req.force),
  });
  attempts.push({ step: "site", ok: true, detail: `xmark (watermark-free) · ${out.match.title}` });
  return {
    anilistId: req.anilistId,
    episode: req.episode,
    requestedProvider,
    provider: "xmark",
    requestedType: req.type,
    type: out.actualType,
    typeFallback: out.typeFallback,
    strategy: "site",
    stream: streamBlock(out.resolved, { name: out.server.name, id: out.server.serverId }, {
      provider: "xmark",
      audio: out.actualType,
      anilistId: req.anilistId,
      episode: req.episode,
    }),
    anilist: summarizeAnilist(media),
    match: {
      animeId: out.match.animeId,
      slug: out.match.slug,
      title: out.match.title,
      method: out.match.method,
      confidence: out.match.confidence,
      malId: media.idMal != null ? String(media.idMal) : null,
      siteUrl: out.match.siteUrl,
      cached: out.cached,
      episodeId: out.match.siteUrl,
      episodeTitle: null,
      availableEpisodes: out.match.availableEpisodes,
      firstEpisode: "1",
      lastEpisode: String(out.match.availableEpisodes),
    },
    attempts,
    cached: out.cached,
    tookMs: Date.now() - started,
  };
}

/* -------------------------------------------------------------------- main */


async function runAniPmProvider(params: {
  req: StreamRequest;
  media: AnilistMedia | null;
  attempts: StreamAttempt[];
  started: number;
  requestedProvider: ProviderSelection;
}): Promise<StreamPayload> {
  const { req, media, attempts, started, requestedProvider } = params;
  if (!media) throw new ScrapeError("AniList metadata is required to query ani.pm", 502, attempts);

  const out = await resolveAniPmStream({
    anilistId: req.anilistId,
    episode: req.episode,
    type: req.type,
    media,
    force: Boolean(req.force),
  });

  attempts.push({
    step: "site",
    ok: true,
    detail: `ani.pm · ${out.match.title}${out.cached ? " (cached)" : ""}`,
  });

  return {
    anilistId: req.anilistId,
    episode: req.episode,
    requestedProvider,
    provider: "anipm",
    requestedType: req.type,
    type: out.actualType,
    typeFallback: out.typeFallback,
    strategy: "site",
    stream: streamBlock(out.resolved, { name: out.server.name, id: out.server.serverId }, {
      provider: "anipm",
      audio: out.actualType,
      anilistId: req.anilistId,
      episode: req.episode,
    }),
    anilist: summarizeAnilist(media),
    match: {
      animeId: out.match.animeId,
      slug: out.match.slug,
      title: out.match.title,
      method: out.match.method,
      confidence: out.match.confidence,
      malId: media.idMal != null ? String(media.idMal) : null,
      siteUrl: out.match.siteUrl,
      cached: out.cached,
      episodeId: `ep-${req.episode}`,
      episodeTitle: null,
      availableEpisodes: out.match.availableEpisodes,
      firstEpisode: "1",
      lastEpisode: String(out.match.availableEpisodes),
    },
    attempts,
    cached: out.cached,
    tookMs: Date.now() - started,
  };
}

async function runAnizoneProvider(params: {
  req: StreamRequest;
  media: AnilistMedia | null;
  attempts: StreamAttempt[];
  started: number;
  requestedProvider: ProviderSelection;
}): Promise<StreamPayload> {
  const { req, media, attempts, started, requestedProvider } = params;
  if (!media) throw new ScrapeError("AniList metadata is required to query anizone.to", 502, attempts);

  const out = await resolveAnizoneStream({
    anilistId: req.anilistId,
    episode: req.episode,
    type: req.type,
    media,
    force: Boolean(req.force),
  });

  attempts.push({
    step: "site",
    ok: true,
    detail: `anizone.to · ${out.match.title}${out.cached ? " (cached)" : ""}`,
  });

  return {
    anilistId: req.anilistId,
    episode: req.episode,
    requestedProvider,
    provider: "anizone",
    requestedType: req.type,
    type: out.actualType,
    typeFallback: out.typeFallback,
    strategy: "site",
    stream: streamBlock(out.resolved, { name: out.server.name, id: out.server.serverId }, {
      provider: "anizone",
      audio: out.actualType,
      anilistId: req.anilistId,
      episode: req.episode,
    }),
    anilist: summarizeAnilist(media),
    match: {
      animeId: out.match.animeId,
      slug: out.match.slug,
      title: out.match.title,
      method: out.match.method,
      confidence: out.match.confidence,
      malId: media.idMal != null ? String(media.idMal) : null,
      siteUrl: out.match.siteUrl,
      cached: out.cached,
      episodeId: out.match.siteUrl,
      episodeTitle: null,
      availableEpisodes: out.match.availableEpisodes,
      firstEpisode: "1",
      lastEpisode: String(out.match.availableEpisodes),
    },
    attempts,
    cached: out.cached,
    tookMs: Date.now() - started,
  };
}

async function runXanimeProvider(params: {
  req: StreamRequest;
  media: AnilistMedia | null;
  attempts: StreamAttempt[];
  started: number;
  requestedProvider: ProviderSelection;
}): Promise<StreamPayload> {
  const { req, media, attempts, started, requestedProvider } = params;
  if (!media) throw new ScrapeError("AniList metadata is required to query xanime.me", 502, attempts);

  const out = await resolveXanimeStream({
    anilistId: req.anilistId,
    episode: req.episode,
    type: req.type,
    media,
    force: Boolean(req.force),
  });

  attempts.push({
    step: "site",
    ok: true,
    detail: `xanime.me · ${out.match.title}${out.cached ? " (cached)" : ""}`,
  });

  return {
    anilistId: req.anilistId,
    episode: req.episode,
    requestedProvider,
    provider: "xanime",
    requestedType: req.type,
    type: out.actualType,
    typeFallback: out.typeFallback,
    strategy: "site",
    stream: streamBlock(out.resolved, { name: out.server.name, id: out.server.serverId }, {
      provider: "xanime",
      audio: out.actualType,
      anilistId: req.anilistId,
      episode: req.episode,
    }),
    anilist: summarizeAnilist(media),
    match: {
      animeId: out.match.animeId,
      slug: out.match.slug,
      title: out.match.title,
      method: out.match.method,
      confidence: out.match.confidence,
      malId: media.idMal != null ? String(media.idMal) : null,
      siteUrl: out.match.siteUrl,
      cached: out.cached,
      episodeId: out.match.siteUrl,
      episodeTitle: null,
      availableEpisodes: out.match.availableEpisodes,
      firstEpisode: "1",
      lastEpisode: String(out.match.availableEpisodes),
    },
    attempts,
    cached: out.cached,
    tookMs: Date.now() - started,
  };
}

async function runAnimeggProvider(params: {
  req: StreamRequest;
  media: AnilistMedia | null;
  attempts: StreamAttempt[];
  started: number;
  requestedProvider: ProviderSelection;
}): Promise<StreamPayload> {
  const { req, media, attempts, started, requestedProvider } = params;
  if (!media) throw new ScrapeError("AniList metadata is required to query animegg.org", 502, attempts);

  const out = await resolveAnimeggStream({
    anilistId: req.anilistId,
    episode: req.episode,
    type: req.type,
    media,
    force: Boolean(req.force),
  });

  attempts.push({
    step: "site",
    ok: true,
    detail: `animegg.org · ${out.match.title}${out.cached ? " (cached)" : ""}`,
  });

  return {
    anilistId: req.anilistId,
    episode: req.episode,
    requestedProvider,
    provider: "animegg",
    requestedType: req.type,
    type: out.actualType,
    typeFallback: out.typeFallback,
    strategy: "site",
    stream: streamBlock(out.resolved, { name: out.server.name, id: out.server.serverId }, {
      provider: "animegg",
      audio: out.actualType,
      anilistId: req.anilistId,
      episode: req.episode,
    }),
    anilist: summarizeAnilist(media),
    match: {
      animeId: out.match.animeId,
      slug: out.match.slug,
      title: out.match.title,
      method: out.match.method,
      confidence: out.match.confidence,
      malId: media.idMal != null ? String(media.idMal) : null,
      siteUrl: out.match.siteUrl,
      cached: out.cached,
      episodeId: out.match.siteUrl,
      episodeTitle: null,
      availableEpisodes: out.match.availableEpisodes,
      firstEpisode: "1",
      lastEpisode: String(out.match.availableEpisodes),
    },
    attempts,
    cached: out.cached,
    tookMs: Date.now() - started,
  };
}

async function runAnimotvslashProvider(params: {
  req: StreamRequest;
  media: AnilistMedia | null;
  attempts: StreamAttempt[];
  started: number;
  requestedProvider: ProviderSelection;
}): Promise<StreamPayload> {
  const { req, media, attempts, started, requestedProvider } = params;
  if (!media) throw new ScrapeError("AniList metadata is required to query animotvslash.org", 502, attempts);

  const out = await resolveAnimotvslashStream({
    anilistId: req.anilistId,
    episode: req.episode,
    type: req.type,
    media,
    force: Boolean(req.force),
  });

  attempts.push({
    step: "site",
    ok: true,
    detail: `animotvslash.org · ${out.match.title}${out.cached ? " (cached)" : ""}`,
  });

  return {
    anilistId: req.anilistId,
    episode: req.episode,
    requestedProvider,
    provider: "animotvslash",
    requestedType: req.type,
    type: out.actualType,
    typeFallback: out.typeFallback,
    strategy: "site",
    stream: streamBlock(out.resolved, { name: out.server.name, id: out.server.serverId }, {
      provider: "animotvslash",
      audio: out.actualType,
      anilistId: req.anilistId,
      episode: req.episode,
    }),
    anilist: summarizeAnilist(media),
    match: {
      animeId: out.match.animeId,
      slug: out.match.slug,
      title: out.match.title,
      method: out.match.method,
      confidence: out.match.confidence,
      malId: media.idMal != null ? String(media.idMal) : null,
      siteUrl: out.match.siteUrl,
      cached: out.cached,
      episodeId: out.match.siteUrl,
      episodeTitle: null,
      availableEpisodes: out.match.availableEpisodes,
      firstEpisode: "1",
      lastEpisode: String(out.match.availableEpisodes),
    },
    attempts,
    cached: out.cached,
    tookMs: Date.now() - started,
  };
}


async function runKaaProvider(params: {
  req: StreamRequest;
  media: AnilistMedia | null;
  attempts: StreamAttempt[];
  started: number;
  requestedProvider: ProviderSelection;
}): Promise<StreamPayload> {
  const { req, media, attempts, started, requestedProvider } = params;
  if (!media) throw new ScrapeError("AniList metadata is required to query kaa.lt", 502, attempts);
  const out = await resolveKaaStream({
    anilistId: req.anilistId,
    episode: req.episode,
    type: req.type,
    media,
    force: Boolean(req.force),
  });
  attempts.push({ step: "site", ok: true, detail: `kaa.lt · ${out.match.title}${out.cached ? " (cached)" : ""}` });
  return {
    anilistId: req.anilistId, episode: req.episode, requestedProvider,
    provider: "kaa", requestedType: req.type, type: out.actualType,
    typeFallback: out.typeFallback, strategy: "site",
    stream: streamBlock(out.resolved, { name: out.server.name, id: out.server.serverId }, {
      provider: "kaa", audio: out.actualType, anilistId: req.anilistId, episode: req.episode,
    }),
    anilist: summarizeAnilist(media),
    match: {
      animeId: out.match.animeId, slug: out.match.slug, title: out.match.title,
      method: out.match.method, confidence: out.match.confidence,
      malId: media.idMal != null ? String(media.idMal) : null,
      siteUrl: out.match.siteUrl, cached: out.cached,
      episodeId: out.match.siteUrl,
      episodeTitle: null,
      availableEpisodes: out.match.availableEpisodes,
      firstEpisode: "1", lastEpisode: String(out.match.availableEpisodes),
    },
    attempts, cached: out.cached, tookMs: Date.now() - started,
  };
}


async function runAtvProvider(params: {
  req: StreamRequest;
  media: AnilistMedia | null;
  attempts: StreamAttempt[];
  started: number;
  requestedProvider: ProviderSelection;
}): Promise<StreamPayload> {
  const { req, media, attempts, started, requestedProvider } = params;
  if (!media) throw new ScrapeError("AniList metadata is required to query animetvplus.xyz", 502, attempts);
  const out = await resolveAtvStream({
    anilistId: req.anilistId,
    episode: req.episode,
    type: req.type,
    media,
    force: Boolean(req.force),
  });
  attempts.push({ step: "site", ok: true, detail: `animetvplus.xyz · ${out.match.title}${out.cached ? " (cached)" : ""}` });
  return {
    anilistId: req.anilistId, episode: req.episode, requestedProvider,
    provider: "atv", requestedType: req.type, type: out.actualType,
    typeFallback: out.typeFallback, strategy: "site",
    stream: streamBlock(out.resolved, { name: out.server.name, id: out.server.serverId }, {
      provider: "atv", audio: out.actualType, anilistId: req.anilistId, episode: req.episode,
    }),
    anilist: summarizeAnilist(media),
    match: {
      animeId: out.match.animeId, slug: out.match.slug, title: out.match.title,
      method: out.match.method, confidence: out.match.confidence,
      malId: media.idMal != null ? String(media.idMal) : null,
      siteUrl: out.match.siteUrl, cached: out.cached,
      episodeId: out.match.siteUrl, episodeTitle: null,
      availableEpisodes: out.match.availableEpisodes,
      firstEpisode: "1", lastEpisode: String(out.match.availableEpisodes),
    },
    attempts, cached: out.cached, tookMs: Date.now() - started,
  };
}

const AUTO_ORDER: ScraperProvider[] = ["anipm", "reanime", "anizone", "xanime", "anikoto", "aniwaves", "animegg", "animotvslash", "xmark"];

/**
 * AniList id + episode number (+ provider) -> playable HLS stream.
 *
 * Supports three scrapers:
 *   - `anikoto`  (anikototv.to -> MegaPlay AES-256-CBC)
 *   - `reanime`  (reanime.to -> FlixCloud WASM + PBKDF2 + AES-256-CBC + `_v7` XOR)
 *   - `aniwaves` (aniwaves.ru -> EchoVideo / VhsCDN)
 *   - `auto`     (tries `anikoto` -> `reanime` -> `aniwaves`)
 */
export async function getStream(req: StreamRequest): Promise<StreamPayload> {
  const started = Date.now();
  const attempts: StreamAttempt[] = [];
  const force = Boolean(req.force);
  const requestedProvider: ProviderSelection = req.provider ?? "anikoto";

  return withJob<StreamPayload>(
    "stream",
    `anilist ${req.anilistId} · ep ${req.episode} · ${req.type} · ${requestedProvider}`,
    async () => {
      let media: AnilistMedia | null = null;
      let row: AnilistMappingRow | null = null;

      try {
        const meta = await getAnilistMedia(req.anilistId, force);
        media = meta.media;
        row = meta.row;
        attempts.push({
          step: "anilist",
          ok: true,
          detail: `${preferredTitle(media)}${meta.cached ? " (cached)" : ""}`,
        });
      } catch (err) {
        if (err instanceof AnilistError && err.statusCode === 404) {
          throw new ScrapeError(err.message, 404, [{ step: "anilist", ok: false, detail: err.message }]);
        }
        attempts.push({ step: "anilist", ok: false, detail: errorMessage(err) });
      }

      const browserSite = BROWSER_SITES.find((g) => g.id === requestedProvider);
      if (browserSite) {
        try {
          const payload = await runBrowserProvider({
            req,
            media,
            siteId: browserSite.id,
            attempts,
            started,
            requestedProvider,
          });
          return { value: payload, items: 1 };
        } catch (err) {
          throw new ScrapeError(errorMessage(err), siteStatus(err), attempts);
        }
      }

      const genericSite = GENERIC_SITES.find((g) => g.id === requestedProvider);
      if (genericSite) {
        try {
          const payload = await runGenericProvider({ req, media, siteId: genericSite.id, attempts, started, requestedProvider });
          return { value: payload, items: 1 };
        } catch (err) {
          throw new ScrapeError(errorMessage(err), siteStatus(err), attempts);
        }
      }

      const order: ScraperProvider[] =
        requestedProvider === "auto" ? AUTO_ORDER : [requestedProvider as ScraperProvider];

      let lastErr: unknown = null;
      for (const provider of order) {
        try {
          let payload: StreamPayload;
          if (provider === "reanime") {
            payload = await runReanimeProvider({
              req,
              media,
              attempts,
              started,
              requestedProvider,
            });
          } else if (provider === "aniwaves") {
            payload = await runAniwavesProvider({
              req,
              media,
              attempts,
              started,
              requestedProvider,
            });
          } else if (provider === "anipm") {
            payload = await runAniPmProvider({
              req,
              media,
              attempts,
              started,
              requestedProvider,
            });
          } else if (provider === "anizone") {
            payload = await runAnizoneProvider({
              req,
              media,
              attempts,
              started,
              requestedProvider,
            });
          } else if (provider === "xanime") {
            payload = await runXanimeProvider({
              req,
              media,
              attempts,
              started,
              requestedProvider,
            });
          } else if (provider === "animegg") {
            payload = await runAnimeggProvider({
              req,
              media,
              attempts,
              started,
              requestedProvider,
            });
          } else if (provider === "xmark") {
            payload = await runXmarkProvider({
              req,
              media,
              attempts,
              started,
              requestedProvider,
            });
          } else if (provider === "atv") {
            payload = await runAtvProvider({
              req, media, attempts, started, requestedProvider,
            });
          } else if (provider === "kaa") {
            payload = await runKaaProvider({
              req, media, attempts, started, requestedProvider,
            });
          } else if (provider === "animotvslash") {
            payload = await runAnimotvslashProvider({
              req,
              media,
              attempts,
              started,
              requestedProvider,
            });
          } else {
            payload = await runAnikotoProvider({
              req,
              media,
              row,
              attempts,
              started,
              requestedProvider,
            });
          }
          return { value: payload, items: 1 };
        } catch (err) {
          lastErr = err;
          if (provider === "reanime") {
            attempts.push({ step: "reanime", ok: false, detail: errorMessage(err) });
          } else if (provider === "aniwaves") {
            attempts.push({ step: "aniwaves", ok: false, detail: errorMessage(err) });
          }
        }
      }

      const status = lastErr ? siteStatus(lastErr) : 502;
      throw new ScrapeError(
        lastErr
          ? errorMessage(lastErr)
          : `no stream found for AniList ${req.anilistId} episode ${req.episode} (${req.type})`,
        status === 404 ? 404 : 502,
        attempts,
      );
    },
  );
}

import { SITE } from "./config";

export class HttpError extends Error {
  constructor(
    message: string,
    readonly status: number,
    readonly url: string,
  ) {
    super(message);
    this.name = "HttpError";
  }
}

export interface FetchOptions {
  referer?: string;
  headers?: Record<string, string>;
  /** Send the XMLHttpRequest header the site's own AJAX calls use. */
  xhr?: boolean;
  timeoutMs?: number;
  retries?: number;
  method?: "GET" | "POST";
  body?: string;
}

function sleep(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * Thin fetch wrapper that always presents a real browser fingerprint and
 * retries transient failures. Every outbound scrape request goes through here.
 */
export async function fetchRaw(url: string, options: FetchOptions = {}): Promise<Response> {
  const {
    referer,
    headers = {},
    xhr = false,
    timeoutMs = SITE.timeoutMs,
    retries = SITE.retries,
    method = "GET",
    body,
  } = options;

  let lastError: unknown = null;

  for (let attempt = 0; attempt <= retries; attempt += 1) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);

    const requestHeaders: Record<string, string> = {
      "User-Agent": SITE.userAgent,
      Accept:
        "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
      "Accept-Language": "en-US,en;q=0.9",
      "Cache-Control": "no-cache",
      ...headers,
    };
    if (referer) requestHeaders.Referer = referer;
    if (xhr) requestHeaders["X-Requested-With"] = "XMLHttpRequest";

    try {
      const response = await fetch(url, {
        method,
        headers: requestHeaders,
        body,
        signal: controller.signal,
        redirect: "follow",
      });
      clearTimeout(timer);

      if (response.status >= 500 && attempt < retries) {
        lastError = new HttpError(`upstream ${response.status}`, response.status, url);
        await sleep(400 * (attempt + 1));
        continue;
      }
      return response;
    } catch (err) {
      clearTimeout(timer);
      lastError = err;
      if (attempt < retries) {
        await sleep(400 * (attempt + 1));
        continue;
      }
    }
  }

  const reason = lastError instanceof Error ? lastError.message : String(lastError);
  throw new HttpError(`request to ${url} failed: ${reason}`, 0, url);
}

/** Fetches and returns the body as text, throwing on non-2xx responses. */
export async function fetchText(url: string, options: FetchOptions = {}): Promise<string> {
  const response = await fetchRaw(url, options);
  const text = await response.text();
  if (!response.ok) {
    throw new HttpError(`upstream responded ${response.status} for ${url}`, response.status, url);
  }
  return text;
}

/** Fetches a JSON body, tolerating both real JSON and JSON-in-a-string results. */
export async function fetchJson<T = unknown>(url: string, options: FetchOptions = {}): Promise<T> {
  const text = await fetchText(url, {
    ...options,
    headers: { Accept: "application/json, text/plain, */*", ...options.headers },
  });
  try {
    return JSON.parse(text) as T;
  } catch {
    throw new HttpError(`upstream returned a non-JSON body for ${url}`, 200, url);
  }
}

/** Joins a possibly-relative URL against a base, returning an absolute URL. */
export function absoluteUrl(value: string, base: string): string {
  try {
    return new URL(value, base).toString();
  } catch {
    return value;
  }
}

import { eq } from "drizzle-orm";
import { db } from "@/db";
import { anilistMappings } from "@/db/schema";
import { fetchJson } from "@/lib/http";
import { fetchAnilistMedia } from "@/lib/anilist";
import { getStream, type ProviderSelection, type StreamPayload } from "@/lib/stream";
import { mapToSite } from "@/lib/stream";
import { ScrapeError, withJob } from "@/lib/scraper";
import { buildHlsProxyUrl, computeProxyExpiry } from "@/lib/hls-proxy";

/**
 * Bulk scrape orchestration.
 *
 * Two scopes:
 *   - `ids`:   explicit AniList id range ("1-1000") or list
 *   - `chart`: trending (day|week|month) or all-time popular, top N —
 *              sourced from the AniList GraphQL API (popularity / trending ranks)
 *
 * For each anime we resolve episode 1 (or every episode when `episodes="all"`)
 * through a provider priority chain, scraping metadata from anikototv.to
 * (via mapToSite) for titles and poster data.
 */

export type BulkScope =
  | { kind: "ids"; from: number; to: number; raw?: string }
  | { kind: "chart"; chart: "trending" | "popular"; period?: "day" | "week" | "month"; limit: number };

export interface BulkRequest {
  scope: BulkScope;
  type: "sub" | "dub";
  /** Provider chain to try in order. Defaults to the configured chain. */
  providers?: ProviderSelection[];
  /** "first" = episode 1 only; "all" = every episode. */
  episodes: "first" | "all";
  /** Max anime to process (safety cap). */
  limit: number;
}

export interface BulkItemLink {
  anilistId: number;
  episode: number;
  title: string;
  provider: string;
  /** Absolute /proxy/hls URL with title metadata appended. */
  link: string;
  /** The signed /proxy/hls path only (relative). */
  proxyPath: string;
  quality: string;
  audio: "sub" | "dub";
  cached: boolean;
}

export interface BulkResult {
  scope: BulkScope;
  providers: ProviderSelection[];
  total: number;
  ok: number;
  failed: number;
  links: BulkItemLink[];
  errors: Array<{ anilistId: number; episode: number; error: string }>;
  tookMs: number;
}

/**
 * The provider priority chain used for bulk fetches.
 * animotvslash and ani.pm are intentionally excluded.
 */
export const BULK_PROVIDER_CHAIN: ProviderSelection[] = [
  "reanime",
  "xmark",
  "kaa",
  "aniwaves",
  "xanime",
  "anizone",
  "animegg",
  "anikoto",
];

const ANILIST = "https://graphql.anilist.co";

interface AniListPage<T> {
  data?: { Page?: { media?: T[]; pageInfo?: { hasNextPage?: boolean; currentPage?: number } } };
  errors?: Array<{ message?: string }>;
}

/** Top N anime by trending rank (optionally within a time window) or popularity. */
async function fetchAniListChart(
  chart: "trending" | "popular",
  period: "day" | "week" | "month" | undefined,
  limit: number,
): Promise<number[]> {
  const perPage = 50;
  const pages = Math.max(1, Math.ceil(limit / perPage));
  const ids: number[] = [];
  const dateRangeSec =
    chart === "trending" && period
      ? (() => {
          const now = Math.floor(Date.now() / 1000);
          const days = period === "day" ? 1 : period === "week" ? 7 : 30;
          return { start: now - days * 86400, end: now };
        })()
      : undefined;

  for (let page = 1; page <= pages && ids.length < limit; page += 1) {
    // AniList's Page.media doesn't support airingAt range filters, so for
    // trending we always pull TRENDING_DESC with nextAiringEpisode and filter
    // by time window client-side. Popular (all-time) uses POPULARITY_DESC.
    const query =
      chart === "trending"
        ? `query($page:Int,$perPage:Int){Page(page:$page,perPage:$perPage){pageInfo{hasNextPage}media(type:ANIME,sort:TRENDING_DESC){id nextAiringEpisode{airingAt}}}}`
        : `query($page:Int,$perPage:Int){Page(page:$page,perPage:$perPage){pageInfo{hasNextPage}media(type:ANIME,sort:POPULARITY_DESC){id}}}`;
    const variables: Record<string, unknown> = { page, perPage };

    const res = await fetchJson<
      AniListPage<{ id: number; nextAiringEpisode?: { airingAt?: number } | null }>
    >(ANILIST, {
      method: "POST",
      body: JSON.stringify({ query, variables }),
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      timeoutMs: 20000,
      retries: 2,
    });

    const media = res?.data?.Page?.media ?? [];
    for (const m of media) {
      if (ids.length >= limit) break;
      // For trending within a time window, only keep titles whose next
      // airing episode falls inside the window (AniList has no server-side
      // airingAt filter on Page.media, so we filter here).
      if (chart === "trending" && dateRangeSec) {
        const airingAt = m.nextAiringEpisode?.airingAt ?? 0;
        if (airingAt > 0 && (airingAt < dateRangeSec.start || airingAt > dateRangeSec.end)) {
          continue;
        }
      }
      ids.push(m.id);
    }
    if (!(res?.data?.Page?.pageInfo?.hasNextPage)) break;
  }

  return ids;
}

/** Parses an id scope like "1-1000" or "21,154587,151807". */
export function parseIdScope(raw: string): BulkScope {
  const clean = raw.trim();
  const range = clean.match(/^(\d+)\s*-\s*(\d+)$/);
  if (range) {
    const from = Number(range[1]);
    const to = Number(range[2]);
    if (to < from || to - from > 50_000) {
      throw new ScrapeError("id range too large (max 50,000)", 400);
    }
    return { kind: "ids", from, to, raw: clean };
  }
  const list = clean
    .split(/[,\s]+/)
    .map((v) => Number(v))
    .filter((v) => Number.isInteger(v) && v > 0);
  if (!list.length) throw new ScrapeError("no valid AniList ids in scope", 400);
  return { kind: "ids", from: Math.min(...list), to: Math.max(...list), raw: clean };
}

/** Builds the annotated /proxy/hls link exactly in the requested format. */
export function buildAnnotatedProxyLink(
  payload: StreamPayload,
  origin: string,
  meta: { anilistId: number; episode: number; quality: string; audio: "sub" | "dub"; title: string },
): { link: string; proxyPath: string } {
  const exp = computeProxyExpiry();
  const base = payload.stream.proxied; // "/proxy/hls?url=…&…&purpose=playback"
  const sep = base.includes("?") ? "&" : "?";
  const annotation = `title=${encodeURIComponent(
    `Al=${meta.anilistId} Ep=${meta.episode} Q=${meta.quality} A=${meta.audio} ${meta.title}`,
  )}`;
  const proxyPath = `${base}${sep}${annotation}`;
  return { link: `${origin}${proxyPath}`, proxyPath };
}

/** Quality label for a resolved payload (first level height, else "auto"). */
function qualityLabel(payload: StreamPayload): string {
  const levels = (payload.stream as unknown as { levels?: Array<{ height?: number | null }> });
  // streamBlock doesn't carry levels; approximate from the m3u8 URL or default.
  const m = payload.stream.m3u8.match(/(\d{3,4})p/i);
  if (m) return `${m[1]}p`;
  return "auto";
}

/**
 * Runs a bulk scrape. For each anime it resolves the requested episodes
 * through the provider chain, scraping metadata from anikototv.to.
 */
export async function runBulk(
  req: BulkRequest,
  origin: string,
): Promise<BulkResult> {
  const started = Date.now();
  const providers = req.providers?.length ? req.providers : BULK_PROVIDER_CHAIN;
  const cap = Math.min(Math.max(req.limit || 100, 1), 2000);

  let anilistIds: number[] = [];
  if (req.scope.kind === "ids") {
    const { from, to } = req.scope;
    // A comma/space-separated list ("21,154587") arrives as from=min,to=max;
    // detect that and expand only the listed ids instead of the whole range.
    const explicit = String(req.scope.raw ?? "");
    if (explicit.includes(",") || explicit.includes(" ")) {
      const listed = explicit
        .split(/[,\s]+/)
        .map((v) => Number(v))
        .filter((v) => Number.isInteger(v) && v > 0);
      anilistIds = listed.slice(0, cap);
    } else {
      for (let id = from; id <= to && anilistIds.length < cap; id += 1) anilistIds.push(id);
    }
  } else {
    anilistIds = await fetchAniListChart(
      req.scope.chart,
      req.scope.chart === "trending" ? req.scope.period : undefined,
      cap,
    );
  }

  return withJob<BulkResult>(
    "bulk",
    `${req.scope.kind} · ${anilistIds.length} titles · ${providers.join("→")}`,
    async () => {
      const links: BulkItemLink[] = [];
      const errors: BulkResult["errors"] = [];

      for (const anilistId of anilistIds) {
        let media;
        try {
          media = await fetchAnilistMedia(anilistId);
        } catch {
          errors.push({ anilistId, episode: 0, error: "anilist lookup failed" });
          continue;
        }

        // Scrape metadata from anikototv.to (best effort — used for title/poster).
        let siteTitle = media.title.english ?? media.title.romaji ?? `AniList #${anilistId}`;
        try {
          const row = await db
            .select()
            .from(anilistMappings)
            .where(eq(anilistMappings.anilistId, anilistId))
            .limit(1);
          if (row[0]?.animeId) {
            try {
              const match = await mapToSite(media, row[0]);
              siteTitle = match.title;
            } catch {
              /* keep anilist title */
            }
          }
        } catch {
          /* ignore */
        }

        const totalEps = media.episodes ?? 1;
        const epsToFetch =
          req.episodes === "all"
            ? Array.from({ length: totalEps }, (_, i) => i + 1)
            : [1];

        for (const ep of epsToFetch.slice(0, 50)) {
          let payload: StreamPayload | null = null;
          let usedProvider: ProviderSelection | null = null;
          for (const provider of providers) {
            try {
              payload = await getStream({
                anilistId,
                episode: ep,
                type: req.type,
                provider,
                strategy: "auto",
              });
              usedProvider = payload.provider;
              break;
            } catch {
              continue;
            }
          }

          if (!payload) {
            errors.push({
              anilistId,
              episode: ep,
              error: `all providers failed (${providers.join(", ")})`,
            });
            continue;
          }

          const { link, proxyPath } = buildAnnotatedProxyLink(payload, origin, {
            anilistId,
            episode: ep,
            quality: qualityLabel(payload),
            audio: payload.type === "dub" ? "dub" : "sub",
            title: siteTitle,
          });

          links.push({
            anilistId,
            episode: ep,
            title: siteTitle,
            provider: usedProvider ?? payload.provider,
            link,
            proxyPath,
            quality: qualityLabel(payload),
            audio: payload.type === "dub" ? "dub" : "sub",
            cached: payload.cached,
          });
        }
      }

      return {
        value: {
          scope: req.scope,
          providers,
          total: anilistIds.length,
          ok: links.length,
          failed: errors.length,
          links,
          errors,
          tookMs: Date.now() - started,
        },
        items: links.length,
      };
    },
  );
}

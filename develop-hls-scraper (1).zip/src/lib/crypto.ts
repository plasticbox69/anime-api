import { createDecipheriv } from "node:crypto";
import { PLAYER } from "./config";

/**
 * The embed player derives its AES material by UTF-8 encoding a short secret
 * string and zero-padding it to the cipher's key/iv length. This mirrors that
 * behaviour exactly (the site's `EHem` helper).
 */
function deriveBytes(secret: string, length: number): Buffer {
  const raw = Buffer.from(String(secret), "utf8");
  const out = Buffer.alloc(length); // zero filled
  raw.copy(out, 0, 0, Math.min(length, raw.length));
  return out;
}

/**
 * base64url -> Buffer, restoring the padding the site strips
 * (the player's `QwJl` helper).
 */
function fromBase64Url(value: string): Buffer {
  let b64 = String(value).replace(/-/g, "+").replace(/_/g, "/");
  const pad = b64.length % 4;
  if (pad) b64 += "=".repeat(4 - pad);
  return Buffer.from(b64, "base64");
}

export class DecryptionError extends Error {
  constructor(message: string, readonly cause?: unknown) {
    super(message);
    this.name = "DecryptionError";
  }
}

/**
 * Decrypts the `enc` payload returned by the embed player's sources endpoint.
 *
 * @returns the parsed JSON body, normally `{ file: "https://.../master.m3u8" }`
 *          or `{ sources: [{ file, quality }] }`.
 */
export function decryptSourcesPayload(enc: string): Record<string, unknown> {
  if (!enc || typeof enc !== "string") {
    throw new DecryptionError("empty enc payload");
  }

  const key = deriveBytes(PLAYER.aesKey, 32);
  const iv = deriveBytes(PLAYER.aesIv, 16);

  try {
    const decipher = createDecipheriv("aes-256-cbc", key, iv);
    const plain = Buffer.concat([decipher.update(fromBase64Url(enc)), decipher.final()]);
    const text = plain.toString("utf8").trim();
    const parsed = JSON.parse(text) as Record<string, unknown>;
    if (!parsed || typeof parsed !== "object") {
      throw new DecryptionError("decrypted payload is not an object");
    }
    return parsed;
  } catch (err) {
    throw new DecryptionError(
      "failed to decrypt sources payload (the player key may have rotated — set PLAYER_AES_KEY / PLAYER_AES_IV)",
      err,
    );
  }
}

/** Pulls every m3u8 candidate out of a decrypted payload. */
export function extractHlsUrls(payload: Record<string, unknown>): string[] {
  const found: string[] = [];

  const push = (value: unknown) => {
    if (typeof value !== "string") return;
    if (/\.m3u8($|\?)/i.test(value) || value.startsWith("blob:") === false) {
      if (/^https?:\/\//i.test(value)) found.push(value);
    }
  };

  push(payload.file);
  push(payload.url);

  for (const key of ["sources", "source", "files", "playlist"] as const) {
    const value = payload[key];
    if (Array.isArray(value)) {
      for (const item of value) {
        if (item && typeof item === "object") {
          const rec = item as Record<string, unknown>;
          push(rec.file);
          push(rec.url);
          push(rec.src);
        } else {
          push(item);
        }
      }
    } else if (typeof value === "string") {
      push(value);
    }
  }

  return Array.from(new Set(found));
}

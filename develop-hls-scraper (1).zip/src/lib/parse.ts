import * as cheerio from "cheerio";
import type { CheerioAPI } from "cheerio";
import { absoluteUrl } from "./http";
import { SITE } from "./config";
import type {
  AnimeDetail,
  AnimeListItem,
  EpisodeItem,
  PageMeta,
  ServerItem,
} from "./types";

function clean(value: string | undefined | null): string | null {
  if (!value) return null;
  const trimmed = value.replace(/\s+/g, " ").trim();
  return trimmed.length ? trimmed : null;
}

function toNumber(value: string | undefined | null): number | null {
  const text = clean(value);
  if (!text) return null;
  const match = text.match(/-?\d+(?:\.\d+)?/);
  if (!match) return null;
  const num = Number(match[0]);
  return Number.isFinite(num) ? num : null;
}

/** `/watch/one-piece-odmau/ep-1` -> `one-piece-odmau` */
export function slugFromHref(href: string | undefined): string | null {
  if (!href) return null;
  const match = href.match(/\/watch\/([^/?#]+)/);
  if (match) return match[1];
  const bare = href.match(/^\/?([a-z0-9-]+)$/i);
  return bare ? bare[1] : null;
}

/**
 * Parses the repeated `.item` cards used by both the filter/search page and the
 * AJAX home widgets. The two layouts differ slightly, so every field is probed
 * with a couple of fallbacks.
 */
export function parseAnimeItems(
  html: string,
  base: string = SITE.baseUrl,
  /**
   * Restrict parsing to one container. The filter page renders a "Top rated"
   * sidebar with the same card markup, which must not leak into results.
   */
  scope?: string,
): AnimeListItem[] {
  const $ = cheerio.load(html);
  const items: AnimeListItem[] = [];
  const seen = new Set<string>();

  const root = scope ? $(scope).first() : null;
  const nodes = root && root.length ? root.find(".item") : $(".item, .ani.items .item, div.item");

  nodes.each((_, el) => {
    const $el = $(el);

    const posterWrap = $el.find("[data-tip]").first();
    const id = clean(posterWrap.attr("data-tip")) ?? clean($el.attr("data-tip"));

    const titleAnchor = $el.find("a.name, a.d-title").first();
    const title = clean(titleAnchor.text()) ?? clean($el.find("img").first().attr("alt"));
    if (!title) return;

    const linkHref =
      titleAnchor.attr("href") ??
      $el.find('a[href*="/watch/"]').first().attr("href") ??
      "";
    const slug = slugFromHref(linkHref);
    if (!slug) return;

    const key = id ?? slug;
    if (seen.has(key)) return;
    seen.add(key);

    const poster = clean($el.find("img").first().attr("src"));
    const japaneseTitle = clean(titleAnchor.attr("data-jp"));

    const genres: string[] = [];
    $el.find(".genre a").each((__, g) => {
      const label = clean($(g).text());
      if (label) genres.push(label);
    });

    // `.meta .left` holds sub / dub / total episode badges on poster cards.
    let subCount: number | null = null;
    let dubCount: number | null = null;
    let totalEpisodes: number | null = null;
    $el.find(".ep-status").each((__, s) => {
      const cls = ($(s).attr("class") ?? "").toLowerCase();
      const num = toNumber($(s).text());
      if (cls.includes("sub")) subCount = num;
      else if (cls.includes("dub")) dubCount = num;
      else if (cls.includes("total")) totalEpisodes = num;
    });

    // `.info .meta .m-item` holds sub count, type and the MAL score.
    let type: string | null = null;
    let score: number | null = null;
    $el.find(".m-item").each((__, m) => {
      const $m = $(m);
      const label = clean($m.find("label").text()) ?? "";
      const span = toNumber($m.find("span").first().text());
      const lower = label.toLowerCase();
      if (lower.includes("sub")) {
        if (subCount === null) subCount = span;
      } else if (lower.includes("dub")) {
        if (dubCount === null) dubCount = span;
      } else if ($m.hasClass("rated") || lower.includes("star")) {
        score = span;
      } else if (!type && label) {
        type = label;
      }
    });

    if (!type) type = clean($el.find(".meta .right").first().text());

    items.push({
      id: id ?? slug,
      slug,
      title,
      japaneseTitle,
      poster: poster ? absoluteUrl(poster, base) : null,
      genres,
      type,
      score,
      subCount,
      dubCount,
      totalEpisodes: totalEpisodes ?? subCount,
      url: `${base}/watch/${slug}`,
    });
  });

  return items;
}

/** Reads the pager rendered at the bottom of the filter page. */
export function parsePagination(html: string, current: number): PageMeta {
  const $ = cheerio.load(html);
  const pages = new Set<number>([current]);

  $(".pagination a, .pagination li a").each((_, el) => {
    const href = $(el).attr("href") ?? "";
    const match = href.match(/[?&]page=(\d+)/);
    if (match) pages.add(Number(match[1]));
    const last = clean($(el).text());
    if (last && /^\d+$/.test(last)) pages.add(Number(last));
  });

  const totalPages = pages.size ? Math.max(...Array.from(pages)) : current;
  return { page: current, totalPages, hasNext: current < totalPages };
}

/** Parses the HTML fragment returned by `ajax/episode/list/{animeId}`. */
export function parseEpisodes(fragment: string): EpisodeItem[] {
  const $ = cheerio.load(fragment);
  const out: EpisodeItem[] = [];
  const seen = new Set<string>();

  $("a[data-id][data-num]").each((_, el) => {
    const $a = $(el);
    const id = clean($a.attr("data-id"));
    if (!id || seen.has(id)) return;
    seen.add(id);

    const $li = $a.closest("li");
    const title = clean($li.attr("title")) ?? clean($a.attr("title")) ?? clean($a.text());

    const ts = clean($a.attr("data-timestamp"));
    out.push({
      id,
      number: clean($a.attr("data-num")) ?? id,
      title,
      slug: clean($a.attr("data-slug")),
      hasSub: clean($a.attr("data-sub")) === "1",
      hasDub: clean($a.attr("data-dub")) === "1",
      serverIds: clean($a.attr("data-ids")),
      airedAt: ts,
      malId: clean($a.attr("data-mal")),
    });
  });

  return out;
}

/** Parses the HTML fragment returned by `ajax/server/list?servers=...`. */
export function parseServers(fragment: string): ServerItem[] {
  const $ = cheerio.load(fragment);
  const out: ServerItem[] = [];

  $(".servers .type, div.type[data-type]").each((_, group) => {
    const type = clean($(group).attr("data-type")) ?? "sub";
    $(group)
      .find("li[data-link-id]")
      .each((__, li) => {
        const $li = $(li);
        const linkId = clean($li.attr("data-link-id"));
        if (!linkId) return;
        out.push({
          episodeId: clean($li.attr("data-ep-id")) ?? "",
          name: clean($li.text()) ?? "Server",
          serverId: clean($li.attr("data-sv-id")) ?? "",
          cmid: clean($li.attr("data-cmid")) ?? "",
          linkId,
          type,
        });
      });
  });

  return out;
}

/** Scrapes the full metadata panel from a `/watch/{slug}` page. */
export function parseAnimeDetail(html: string, slug: string, base: string = SITE.baseUrl): AnimeDetail {
  const $ = cheerio.load(html);

  const page = $('[data-id][data-url*="/watch/"]').first();
  const id =
    clean(page.attr("data-id")) ??
    clean($(".layout-page-watchtv").attr("data-id")) ??
    clean($("div[id^='w-rating'][data-id], [data-id]").first().attr("data-id")) ??
    slug;

  const titleAnchor = $("h1.title, h1[itemprop='name'], #w-info .title").first();
  const title = clean(titleAnchor.text()) ?? clean($("title").text()) ?? slug;

  const metaRow = (label: string): string | null => {
    let found: string | null = null;
    $("#w-info .bmeta .meta > div, .bmeta .meta > div").each((_, el) => {
      if (found) return;
      const text = $(el).text().replace(/\s+/g, " ");
      const idx = text.indexOf(label);
      if (idx !== -1) {
        const rest = text.slice(idx + label.length).replace(/^[:\s]+/, "");
        const value = clean(rest);
        if (value) found = value;
      }
    });
    return found;
  };

  const genres: string[] = [];
  $("#w-info a[href*='/genre/']").each((_, el) => {
    const label = clean($(el).text());
    if (label && !genres.includes(label)) genres.push(label);
  });

  const studios: string[] = [];
  $("#w-info a[href*='/studio/']").each((_, el) => {
    const label = clean($(el).find("span").first().text() ?? $(el).text());
    if (label && !studios.includes(label)) studios.push(label);
  });

  const subCount = $("#w-info .meta.icons .sub").length ? toNumber($("#w-info .meta.icons .sub").text()) : null;
  const dubCount = $("#w-info .meta.icons .dub").length ? toNumber($("#w-info .meta.icons .dub").text()) : null;

  return {
    id,
    slug,
    title,
    japaneseTitle: clean(titleAnchor.attr("data-jp")),
    altNames: clean($("#w-info .names").first().text()),
    poster: (() => {
      const src = clean($("#w-info .poster img").first().attr("src"));
      return src ? absoluteUrl(src, base) : null;
    })(),
    synopsis: clean($("#w-info .synopsis .content").first().text()),
    genres,
    studios,
    type: metaRow("Type"),
    status: metaRow("Status"),
    rating: clean($("#w-info .meta.icons .rating").first().text()),
    quality: clean($("#w-info .meta.icons .quality").first().text()),
    score: toNumber(metaRow("MAL")),
    duration: metaRow("Duration"),
    aired: metaRow("Aired"),
    premiered: metaRow("Premiered"),
    subCount: subCount ?? 0,
    dubCount: dubCount ?? 0,
    totalEpisodes: toNumber(metaRow("Episodes")) ?? 0,
    url: `${base}/watch/${slug}`,
  };
}

/** Pulls `data-id` / `data-realid` / `data-mediaid` off the embed player element. */
export function parsePlayerIds(html: string): {
  id: string | null;
  realId: string | null;
  mediaId: string | null;
} {
  const $ = cheerio.load(html);
  const el = $("[id*='player'][data-id], .fix-area[data-id], [data-realid]").first();
  return {
    id: clean(el.attr("data-id")),
    realId: clean(el.attr("data-realid")),
    mediaId: clean(el.attr("data-mediaid")),
  };
}

/** Reads the `window.settings = { ... }` block from an embed page. */
export function parseEmbedSettings(html: string): Record<string, string> {
  const match = html.match(/window\.settings\s*=\s*\{([\s\S]*?)\}\s*;/);
  if (!match) return {};
  const out: Record<string, string> = {};
  const re = /(\w+)\s*:\s*(?:'([^']*)'|"([^"]*)"|([^,\n]+))/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(match[1])) !== null) {
    const value = clean(m[2] ?? m[3] ?? m[4]);
    if (value !== null) out[m[1]] = value;
  }
  return out;
}

export type { CheerioAPI };

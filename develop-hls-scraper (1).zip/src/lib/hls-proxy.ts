import {
  createCipheriv,
  createDecipheriv,
  createHash,
  createHmac,
  randomBytes,
  timingSafeEqual,
} from "node:crypto";
import { HLS_PROXY } from "./config";
import type { ScraperProvider } from "./types";

/**
 * Stateless sealed-context HLS proxy (`GET /proxy/hls`).
 *
 * Replicates the URL and cryptographic structure:
 *   /proxy/hls
 *     ?url=<encoded upstream url>
 *     &exp=<unix expiry seconds>
 *     &sig=<43-char base64url HMAC-SHA256>
 *     &ref=<encoded upstream referer>
 *     &ctx=c1.<ctxExp>.<12B-iv>.<ciphertext>.<16B-gcm-tag>
 *     &purpose=probe|playback|prewarm|manual
 *
 * Why `ctx` exists:
 *   FlixCloud (`reanime.to`) binds its `_v7/.../master.m3u8?token=…` JWT to the
 *   server IP AND XOR-encrypts every `.m3u8` response body with a per-session
 *   32-byte key (`window.__pk`) emitted by an inline WebAssembly module.
 *   Sealing `pk` + upstream `ref` + audio preference inside `ctx` with
 *   AES-256-GCM keeps `/proxy/hls` 100% stateless while allowing any standard
 *   HLS player (`hls.js`, Safari, `mpv`, `VLC`) to play the stream natively.
 */

export type ProxyPurpose = "probe" | "playback" | "prewarm" | "manual" | string;

export interface HlsProxyContext {
  v: 1;
  p: ScraperProvider;
  /** Base64-encoded 32-byte XOR key for FlixCloud `_v7` manifests. */
  pk?: string;
  /** Upstream Referer header. */
  ref?: string;
  /** Upstream Origin header. */
  org?: string;
  /** Requested audio language ("sub" | "dub") for dual-audio manifests. */
  aud?: "sub" | "dub";
  /** Optional subtitle conversion mode. */
  sub?: "vtt";
  aid?: number;
  ep?: number;
}

const CTX_KEY = createHash("sha256").update(`ctx:${HLS_PROXY.secret}`).digest();
const SIG_KEY = createHash("sha256").update(`sig:${HLS_PROXY.secret}`).digest();

/** Rounds unix expiry up to the next hour boundary (deterministic segment URLs). */
export function computeProxyExpiry(ttlSec: number = HLS_PROXY.urlTtlSec, nowSec?: number): number {
  const now = nowSec ?? Math.floor(Date.now() / 1000);
  return Math.ceil((now + ttlSec) / 3600) * 3600;
}

/** Seals an `HlsProxyContext` into `c1.<ctxExp>.<iv>.<ciphertext>.<tag>`. */
export function sealHlsContext(
  payload: Omit<HlsProxyContext, "v">,
  options: { exp?: number; nowSec?: number } = {},
): string {
  const now = options.nowSec ?? Math.floor(Date.now() / 1000);
  const ctxExp =
    options.exp ?? Math.ceil((now + HLS_PROXY.ctxTtlSec) / 3600) * 3600;
  const header = `c1.${ctxExp}`;
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", CTX_KEY, iv);
  cipher.setAAD(Buffer.from(header, "utf8"));

  const body = JSON.stringify({ v: 1, ...payload } satisfies HlsProxyContext);
  const encrypted = Buffer.concat([cipher.update(body, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();

  return `${header}.${iv.toString("base64url")}.${encrypted.toString("base64url")}.${tag.toString("base64url")}`;
}

export function openHlsContext(
  ctx: string,
  nowSec: number = Math.floor(Date.now() / 1000),
): { ok: true; context: HlsProxyContext; exp: number } | { ok: false; reason: "invalid" | "expired" } {
  const parts = ctx.split(".");
  if (parts.length !== 5 || parts[0] !== "c1") {
    return { ok: false, reason: "invalid" };
  }
  const [, expRaw, ivB64, ctB64, tagB64] = parts;
  if (!/^\d{9,12}$/.test(expRaw)) return { ok: false, reason: "invalid" };
  const exp = Number(expRaw);
  if (!Number.isFinite(exp)) return { ok: false, reason: "invalid" };
  if (exp < nowSec) return { ok: false, reason: "expired" };

  try {
    const iv = Buffer.from(ivB64, "base64url");
    const ciphertext = Buffer.from(ctB64, "base64url");
    const tag = Buffer.from(tagB64, "base64url");
    if (iv.length !== 12 || tag.length !== 16 || ciphertext.length === 0) {
      return { ok: false, reason: "invalid" };
    }
    const decipher = createDecipheriv("aes-256-gcm", CTX_KEY, iv);
    decipher.setAAD(Buffer.from(`c1.${expRaw}`, "utf8"));
    decipher.setAuthTag(tag);
    const plain = Buffer.concat([decipher.update(ciphertext), decipher.final()]).toString("utf8");
    const parsed = JSON.parse(plain) as HlsProxyContext;
    if (!parsed || typeof parsed !== "object" || parsed.v !== 1) {
      return { ok: false, reason: "invalid" };
    }
    return { ok: true, context: parsed, exp };
  } catch {
    return { ok: false, reason: "invalid" };
  }
}

/**
 * Computes the 43-char base64url HMAC-SHA256 over `(url, exp, ref, ctx)`.
 * `purpose` is intentionally excluded so clients can mutate `?purpose=probe`
 * vs `?purpose=playback` without invalidating the signature.
 */
export function signHlsProxy(params: {
  url: string;
  exp: number | string;
  ref: string;
  ctx: string;
}): string {
  const canonical = `${params.url}\n${params.exp}\n${params.ref}\n${params.ctx}`;
  return createHmac("sha256", SIG_KEY).update(canonical, "utf8").digest("base64url");
}

export interface BuildHlsProxyOptions {
  ref: string;
  ctx: string;
  exp?: number;
  purpose?: ProxyPurpose | null;
  /** Optional prefix such as `https://example.com` for external players. */
  origin?: string;
  basePath?: string;
}

export function buildHlsProxyUrl(target: string, options: BuildHlsProxyOptions): string {
  const exp = options.exp ?? computeProxyExpiry();
  const ref = options.ref;
  const ctx = options.ctx;
  const sig = signHlsProxy({ url: target, exp, ref, ctx });

  const qs = new URLSearchParams();
  qs.set("url", target);
  qs.set("exp", String(exp));
  qs.set("sig", sig);
  if (ref) qs.set("ref", ref);
  if (ctx) qs.set("ctx", ctx);
  if (options.purpose) qs.set("purpose", options.purpose);

  const path = options.basePath ?? HLS_PROXY.path;
  const prefix = options.origin ? options.origin.replace(/\/+$/, "") : "";
  return `${prefix}${path}?${qs.toString()}`;
}

export type VerifiedHlsProxy =
  | {
      ok: true;
      url: string;
      exp: number;
      ref: string;
      ctx: string;
      context: HlsProxyContext | null;
      purpose: string | null;
    }
  | {
      ok: false;
      error: "invalid_hls_signature" | "expired_hls_signature" | "invalid_target_url";
    };

export function verifyHlsProxyRequest(
  searchParams: URLSearchParams,
  nowSec: number = Math.floor(Date.now() / 1000),
): VerifiedHlsProxy {
  const url = searchParams.get("url") ?? "";
  const expRaw = searchParams.get("exp") ?? "";
  const sig = searchParams.get("sig") ?? "";
  const ref = searchParams.get("ref") ?? "";
  const ctx = searchParams.get("ctx") ?? "";
  const purpose = searchParams.get("purpose");

  if (!url || !expRaw || !sig || !/^\d{9,12}$/.test(expRaw)) {
    return { ok: false, error: "invalid_hls_signature" };
  }

  const expected = Buffer.from(signHlsProxy({ url, exp: expRaw, ref, ctx }));
  const given = Buffer.from(sig);
  if (expected.length !== given.length || !timingSafeEqual(expected, given)) {
    return { ok: false, error: "invalid_hls_signature" };
  }

  const exp = Number(expRaw);
  if (!Number.isFinite(exp) || exp < nowSec) {
    return { ok: false, error: "expired_hls_signature" };
  }

  let parsedUrl: URL;
  try {
    parsedUrl = new URL(url);
  } catch {
    return { ok: false, error: "invalid_target_url" };
  }
  if (parsedUrl.protocol !== "https:" && parsedUrl.protocol !== "http:") {
    return { ok: false, error: "invalid_target_url" };
  }

  let opened: HlsProxyContext | null = null;
  if (ctx) {
    const res = openHlsContext(ctx, nowSec);
    if (!res.ok) {
      return {
        ok: false,
        error: res.reason === "expired" ? "expired_hls_signature" : "invalid_hls_signature",
      };
    }
    opened = res.context;
  }

  return { ok: true, url, exp, ref, ctx, context: opened, purpose };
}

/* --------------------------------------------------- FlixCloud XOR manifest */

/**
 * Decodes a FlixCloud `_v7` base64+XOR-obfuscated `.m3u8` body using the
 * 32-byte WASM `_c()` key (`window.__pk`). Returns `null` if the payload is
 * not an `#EXTM3U` playlist.
 */
export function tryDecodeHlsManifest(rawBuffer: Buffer, pkBase64?: string | null): string | null {
  const head = rawBuffer.subarray(0, 32).toString("utf8").replace(/^\uFEFF/, "").trimStart();
  if (head.startsWith("#EXTM3U")) {
    return rawBuffer.toString("utf8").replace(/^\uFEFF/, "");
  }

  if (!pkBase64) return null;
  const text = rawBuffer.toString("latin1").trim();
  if (!text || text.length < 16 || !/^[A-Za-z0-9+/=\r\n]+$/.test(text.slice(0, 128))) {
    return null;
  }

  try {
    const key = Buffer.from(pkBase64, "base64");
    if (key.length === 0) return null;
    const raw = Buffer.from(text, "base64");
    const out = Buffer.allocUnsafe(raw.length);
    for (let i = 0; i < raw.length; i += 1) {
      out[i] = raw[i] ^ key[i % key.length];
    }
    const decoded = out.toString("utf8");
    if (decoded.trimStart().startsWith("#EXTM3U")) {
      return decoded;
    }
  } catch {
    return null;
  }
  return null;
}

/**
 * Promotes the requested audio language (`dub` = English, `sub` = Japanese/Native)
 * to `DEFAULT=YES` in dual-audio `#EXT-X-MEDIA:TYPE=AUDIO` master playlists so
 * standard HLS players automatically start with the requested track.
 */
export function applyDefaultAudioPreference(
  playlist: string,
  audio?: "sub" | "dub",
): string {
  if (!audio || !/#EXT-X-MEDIA:[^\n]*TYPE=AUDIO/i.test(playlist)) {
    return playlist;
  }

  const lines = playlist.split(/\r?\n/);
  const isEngLine = (line: string) =>
    /LANGUAGE="(?:en|eng|en-[a-z]+)"/i.test(line) ||
    /NAME="[^"]*(?:english|dub)[^"]*"/i.test(line);

  const hasMatchingTrack = lines.some(
    (l) =>
      l.trim().startsWith("#EXT-X-MEDIA:") &&
      /TYPE=AUDIO/i.test(l) &&
      (audio === "dub" ? isEngLine(l) : !isEngLine(l)),
  );
  if (!hasMatchingTrack) return playlist;

  let chosenAssigned = false;
  return lines
    .map((line) => {
      if (!line.trim().startsWith("#EXT-X-MEDIA:") || !/TYPE=AUDIO/i.test(line)) {
        return line;
      }
      const match = audio === "dub" ? isEngLine(line) : !isEngLine(line);
      const makeDefault = match && !chosenAssigned;
      if (makeDefault) chosenAssigned = true;

      let updated = line;
      if (/DEFAULT=(?:YES|NO)/i.test(updated)) {
        updated = updated.replace(/DEFAULT=(?:YES|NO)/i, `DEFAULT=${makeDefault ? "YES" : "NO"}`);
      } else {
        updated += `,DEFAULT=${makeDefault ? "YES" : "NO"}`;
      }
      if (makeDefault && !/AUTOSELECT=YES/i.test(updated)) {
        updated = /AUTOSELECT=NO/i.test(updated)
          ? updated.replace(/AUTOSELECT=NO/i, "AUTOSELECT=YES")
          : `${updated},AUTOSELECT=YES`;
      }
      return updated;
    })
    .join("\n");
}

const URI_ATTR = /(URI=")([^"]+)(")/gi;

/**
 * Rewrites every URI inside an `#EXTM3U` playlist (variant streams,
 * `#EXT-X-MEDIA` audio/subtitle renditions, `#EXT-X-KEY` AES-128 keys,
 * `#EXT-X-MAP` init segments, and media segments) into signed `/proxy/hls` URLs
 * carrying the same `ref` and sealed `ctx`.
 */
export function rewritePlaylistForHlsProxy(
  playlist: string,
  baseUrl: string,
  options: {
    ref: string;
    ctx: string;
    exp: number;
    origin?: string;
    basePath?: string;
    audio?: "sub" | "dub";
  },
): string {
  const normalized = applyDefaultAudioPreference(playlist, options.audio);
  const signNested = (rawUri: string) =>
    buildHlsProxyUrl(new URL(rawUri, baseUrl).toString(), {
      ref: options.ref,
      ctx: options.ctx,
      exp: options.exp,
      origin: options.origin,
      basePath: options.basePath,
    });

  return normalized
    .split(/\r?\n/)
    .map((line) => {
      const trimmed = line.trim();
      if (!trimmed) return line;

      if (trimmed.startsWith("#")) {
        if (!/URI="/i.test(trimmed)) return line;
        return trimmed.replace(URI_ATTR, (_m, open: string, value: string, close: string) => {
          try {
            return `${open}${signNested(value)}${close}`;
          } catch {
            return `${open}${value}${close}`;
          }
        });
      }

      try {
        return signNested(trimmed);
      } catch {
        return line;
      }
    })
    .join("\n");
}

/* --------------------------------------------- SRT / ASS -> WebVTT converter */

function normalizeVttClock(raw: string): string | null {
  const cleaned = raw.trim().replace(",", ".");
  const parts = cleaned.split(":");
  if (parts.length !== 2 && parts.length !== 3) return null;
  const h = parts.length === 3 ? Number(parts[0]) : 0;
  const m = Number(parts[parts.length - 2]);
  const [secRaw, fracRaw = "0"] = parts[parts.length - 1].split(".");
  const s = Number(secRaw);
  if (![h, m, s].every(Number.isFinite) || h < 0 || m < 0 || m > 59 || s < 0 || s > 59) {
    return null;
  }
  // ASS timestamps use centiseconds (.91 -> .910); SRT uses milliseconds (.091).
  const ms = fracRaw.padEnd(3, "0").slice(0, 3);
  return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}.${ms}`;
}

function srtToVtt(input: string): string {
  const blocks = input.replace(/\r\n?/g, "\n").trim().split(/\n[ \t]*\n+/);
  const cues: string[] = [];
  for (const block of blocks) {
    const lines = block.split("\n").map((l) => l.trimEnd());
    const idx = lines.findIndex((l) => l.includes("-->"));
    if (idx < 0) continue;
    const m = lines[idx].match(
      /^\s*((?:\d+:)?\d{1,2}:\d{2}[,.]\d{1,3})\s*-->\s*((?:\d+:)?\d{1,2}:\d{2}[,.]\d{1,3})/,
    );
    if (!m) continue;
    const start = normalizeVttClock(m[1]);
    const end = normalizeVttClock(m[2]);
    if (!start || !end) continue;
    const text = lines
      .slice(idx + 1)
      .join("\n")
      .replace(/\{\\[^}]*\}/g, "")
      .trim();
    if (text) cues.push(`${start} --> ${end}\n${text}`);
  }
  return `WEBVTT\n\n${cues.join("\n\n")}\n`;
}

function assToVtt(input: string): string {
  const lines = input.replace(/\r\n?/g, "\n").split("\n");
  let inEvents = false;
  let formatCols = [
    "layer",
    "start",
    "end",
    "style",
    "name",
    "marginl",
    "marginr",
    "marginv",
    "effect",
    "text",
  ];
  let startIdx = 1;
  let endIdx = 2;
  let effectIdx = 8;
  let textIdx = 9;

  const cues: Array<{ start: string; end: string; text: string }> = [];
  const seen = new Set<string>();

  for (const rawLine of lines) {
    const trimmed = rawLine.trim();
    if (!trimmed) continue;
    if (/^\[events\]$/i.test(trimmed)) {
      inEvents = true;
      continue;
    }
    if (trimmed.startsWith("[") && trimmed.endsWith("]")) {
      inEvents = false;
      continue;
    }
    if (!inEvents) continue;

    if (/^format\s*:/i.test(trimmed)) {
      formatCols = trimmed
        .slice(trimmed.indexOf(":") + 1)
        .split(",")
        .map((c) => c.trim().toLowerCase());
      startIdx = Math.max(0, formatCols.indexOf("start"));
      endIdx = Math.max(1, formatCols.indexOf("end"));
      effectIdx = formatCols.indexOf("effect");
      textIdx = Math.max(formatCols.length - 1, formatCols.indexOf("text"));
      continue;
    }

    if (!/^dialogue\s*:/i.test(trimmed)) continue;
    const rest = rawLine.slice(rawLine.indexOf(":") + 1);
    const parts: string[] = [];
    let cursor = 0;
    for (let c = 0; c < textIdx; c += 1) {
      const comma = rest.indexOf(",", cursor);
      if (comma === -1) break;
      parts.push(rest.slice(cursor, comma).trim());
      cursor = comma + 1;
    }
    if (parts.length < textIdx) continue;
    if (effectIdx >= 0 && /^(?:fx|karaoke)\b/i.test(parts[effectIdx] ?? "")) {
      continue;
    }
    const rawText = rest.slice(cursor);

    // Skip ASS vector drawings ({\p1}...{\p0}) which aren't human-readable text.
    if (/\{\\[^}]*\\p[1-9]\b/i.test(rawText)) continue;

    const start = normalizeVttClock(parts[startIdx] ?? "");
    const end = normalizeVttClock(parts[endIdx] ?? "");
    if (!start || !end || start === end) continue;

    const cleaned = rawText
      .replace(/\{[^}]*\}/g, "")
      .replace(/\\[Nn]/g, "\n")
      .replace(/\\h/g, "\u00A0")
      .split("\n")
      .map((l) => l.trim())
      .filter(Boolean)
      .join("\n");

    if (!cleaned) continue;
    const dedupeKey = `${start}|${end}|${cleaned}`;
    if (seen.has(dedupeKey)) continue;
    seen.add(dedupeKey);
    cues.push({ start, end, text: cleaned });
  }

  cues.sort((a, b) => a.start.localeCompare(b.start));
  return `WEBVTT\n\n${cues.map((c) => `${c.start} --> ${c.end}\n${c.text}`).join("\n\n")}\n`;
}

/** Converts WebVTT, SRT, or ASS/SSA subtitle text into valid WebVTT. */
export function convertSubtitleToVtt(body: string, urlHint = ""): string {
  const clean = body.replace(/^\uFEFF/, "");
  if (/^WEBVTT(?:\s|$)/i.test(clean.trimStart())) {
    return clean;
  }
  const lowerUrl = urlHint.toLowerCase();
  if (
    /\.(?:ass|ssa)(?:$|[?#])/i.test(lowerUrl) ||
    /\[script info\]/i.test(clean.slice(0, 400)) ||
    /\ndialogue\s*:/i.test(clean.slice(0, 4000))
  ) {
    return assToVtt(clean);
  }
  return srtToVtt(clean);
}

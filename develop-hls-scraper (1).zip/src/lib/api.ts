import { NextResponse } from "next/server";
import { ScrapeError } from "./scraper";
import { DecryptionError } from "./crypto";
import { HttpError } from "./http";

export const runtime = "nodejs";

export function ok<T>(data: T, init?: { cached?: boolean; status?: number }) {
  return NextResponse.json(
    {
      ok: true,
      cached: init?.cached ?? false,
      at: new Date().toISOString(),
      data,
    },
    { status: init?.status ?? 200 },
  );
}

export function fail(error: unknown, fallbackMessage = "scrape failed") {
  if (error instanceof ScrapeError) {
    return NextResponse.json(
      {
        ok: false,
        error: error.message,
        statusCode: error.statusCode,
        details: error.details ?? null,
      },
      { status: error.statusCode },
    );
  }

  if (error instanceof DecryptionError) {
    return NextResponse.json(
      {
        ok: false,
        error: error.message,
        statusCode: 502,
        hint: "the embed player rotates its AES key; update PLAYER_AES_KEY / PLAYER_AES_IV",
      },
      { status: 502 },
    );
  }

  if (error instanceof HttpError) {
    return NextResponse.json(
      { ok: false, error: error.message, statusCode: error.status || 502, url: error.url },
      { status: error.status >= 400 && error.status < 600 ? error.status : 502 },
    );
  }

  const message = error instanceof Error ? error.message : String(error);
  return NextResponse.json(
    { ok: false, error: message || fallbackMessage, statusCode: 500 },
    { status: 500 },
  );
}

export function parseIntParam(value: string | null, fallback: number, min: number, max: number) {
  const n = Number(value ?? "");
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, Math.trunc(n)));
}

export function parseBoolParam(value: string | null) {
  return value === "1" || value === "true" || value === "yes";
}

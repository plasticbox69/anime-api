/**
 * Title normalisation + fuzzy scoring used to line AniList entries up with the
 * site's catalogue. MAL ids are the real source of truth; these scores only
 * decide which candidates are worth verifying (and act as a last resort).
 */

export function normalizeTitle(value: string): string {
  return value
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "") // Sōsō -> Soso
    .toLowerCase()
    .replace(/[\u2018\u2019'`´]/g, "") // journey’s / journey's -> journeys
    .replace(/&/g, " and ")
    .replace(/\b(the|a|an)\b/g, " ")
    .replace(/[^a-z0-9]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

/** Makes a keyword safe for the site's search box (ASCII quotes, no noise). */
export function searchKeyword(value: string): string {
  return value
    .replace(/[\u2018\u2019]/g, "'")
    .replace(/[\u201C\u201D]/g, '"')
    .replace(/\s+/g, " ")
    .trim();
}

function bigrams(value: string): Map<string, number> {
  const compact = value.replace(/\s+/g, "");
  const grams = new Map<string, number>();
  for (let i = 0; i < compact.length - 1; i += 1) {
    const g = compact.slice(i, i + 2);
    grams.set(g, (grams.get(g) ?? 0) + 1);
  }
  return grams;
}

/** Sørensen–Dice coefficient over character bigrams, 0..1. */
export function dice(a: string, b: string): number {
  const na = normalizeTitle(a);
  const nb = normalizeTitle(b);
  if (!na || !nb) return 0;
  if (na === nb) return 1;
  const ga = bigrams(na);
  const gb = bigrams(nb);
  let overlap = 0;
  let total = 0;
  for (const n of ga.values()) total += n;
  for (const n of gb.values()) total += n;
  for (const [g, n] of ga) overlap += Math.min(n, gb.get(g) ?? 0);
  return total === 0 ? 0 : (2 * overlap) / total;
}

/** Season / part markers that must agree for two titles to be the same entry. */
export function sequelMarker(value: string): string | null {
  const n = normalizeTitle(value);
  const m =
    n.match(/\b(?:season|s)\s*(\d+)\b/) ??
    n.match(/\b(\d+)(?:st|nd|rd|th)\s+season\b/) ??
    n.match(/\bpart\s*(\d+)\b/) ??
    n.match(/\b(ii|iii|iv|v|vi)\b$/);
  if (!m) return null;
  const roman: Record<string, string> = { ii: "2", iii: "3", iv: "4", v: "5", vi: "6" };
  return roman[m[1]] ?? m[1];
}

const FORMAT_TO_TYPE: Record<string, string[]> = {
  TV: ["tv"],
  TV_SHORT: ["tv", "ona"],
  MOVIE: ["movie"],
  SPECIAL: ["special", "tv special"],
  OVA: ["ova"],
  ONA: ["ona"],
  MUSIC: ["music"],
};

export interface CandidateLike {
  title: string;
  japaneseTitle?: string | null;
  type?: string | null;
}

/**
 * Best similarity between any AniList title and any title the site shows for
 * a candidate, adjusted for format and season agreement.
 */
export function scoreCandidate(
  targets: string[],
  candidate: CandidateLike,
  format?: string | null,
): number {
  const names = [candidate.title, candidate.japaneseTitle].filter(
    (v): v is string => typeof v === "string" && v.length > 0,
  );
  let best = 0;
  for (const t of targets) {
    for (const n of names) {
      let s = dice(t, n);
      const mt = sequelMarker(t);
      const mn = sequelMarker(n);
      if (mt !== mn) s -= 0.12;
      if (s > best) best = s;
    }
  }

  if (format && candidate.type) {
    const allowed = FORMAT_TO_TYPE[format] ?? [];
    if (allowed.includes(candidate.type.toLowerCase())) best += 0.04;
    else best -= 0.06;
  }

  return Math.max(0, Math.min(1, best));
}

/**
 * HLS playlist helpers used by the relay route.
 *
 * The upstream CDN enforces a Referer check that a browser cannot satisfy
 * (a page on our own origin sends its own referer), so playlists and segments
 * are relayed through `/api/relay`. Every URI inside a playlist is rewritten —
 * and signed — so the whole stream stays on this origin.
 */

import { PLAYER } from "./config";
import { fetchRaw, HttpError } from "./http";
import { buildRelayUrl } from "./relay";

const URI_ATTR = /(URI=")([^"]+)(")/gi;

export interface RelayOptions {
  /** Relay endpoint. Use an absolute URL when the playlist leaves the browser (VLC, mpv). */
  basePath?: string;
}

/** Headers that make CDN requests look like they come from the embed player. */
export function upstreamMediaHeaders(): Record<string, string> {
  let origin = "https://megaplay.buzz";
  try {
    origin = new URL(PLAYER.cdnReferer).origin;
  } catch {
    /* keep default */
  }
  return { Accept: "*/*", Origin: origin };
}

export function isPlaylist(contentType: string | null, body: string): boolean {
  if (contentType && contentType.toLowerCase().includes("mpegurl")) return true;
  return body.trimStart().startsWith("#EXTM3U");
}

/**
 * Rewrites an m3u8 document so every nested URI is served through the relay.
 *
 * @param playlist   raw playlist text
 * @param baseUrl    absolute URL the playlist was fetched from (for relative URIs)
 */
export function rewritePlaylist(
  playlist: string,
  baseUrl: string,
  options: RelayOptions = {},
): string {
  const basePath = options.basePath ?? "/api/relay";

  return playlist
    .split(/\r?\n/)
    .map((line) => {
      const trimmed = line.trim();
      if (!trimmed) return line;

      // Tags may embed a URI attribute (EXT-X-KEY, EXT-X-MAP, EXT-X-MEDIA,
      // EXT-X-I-FRAME-STREAM-INF).
      if (trimmed.startsWith("#")) {
        if (!/URI="/i.test(trimmed)) return line;
        return trimmed.replace(URI_ATTR, (_m, open: string, value: string, close: string) => {
          try {
            return `${open}${buildRelayUrl(new URL(value, baseUrl).toString(), basePath)}${close}`;
          } catch {
            return `${open}${value}${close}`;
          }
        });
      }

      // Bare line: a variant playlist, media segment or init segment.
      try {
        return buildRelayUrl(new URL(trimmed, baseUrl).toString(), basePath);
      } catch {
        return line;
      }
    })
    .join("\n");
}

/** Rewrites a WebVTT cue sheet so thumbnail image URIs relay too. */
export function rewriteVtt(vtt: string, baseUrl: string, options: RelayOptions = {}): string {
  const basePath = options.basePath ?? "/api/relay";
  return vtt.replace(/(https?:\/\/[^\s)]+\.(?:jpg|jpeg|png|webp))/gi, (match) => {
    try {
      return buildRelayUrl(new URL(match, baseUrl).toString(), basePath);
    } catch {
      return match;
    }
  });
}

/**
 * Some CDNs smuggle MPEG-TS fragments inside image responses (a real image
 * header followed by the transport stream). Players choke on the prefix, so
 * cut everything before the first run of TS sync bytes (0x47 every 188 bytes).
 */
export function unwrapTransportStream(buf: Buffer): { data: Buffer; isTs: boolean } {
  if (buf.length >= 188 && buf[0] === 0x47) return { data: buf, isTs: true };
  const limit = Math.min(buf.length - 188 * 5, 512 * 1024);
  for (let i = 1; i < limit; i += 1) {
    if (
      buf[i] === 0x47 &&
      buf[i + 188] === 0x47 &&
      buf[i + 376] === 0x47 &&
      buf[i + 564] === 0x47 &&
      buf[i + 752] === 0x47
    ) {
      return { data: buf.subarray(i), isTs: true };
    }
  }
  return { data: buf, isTs: false };
}

/**
 * Fetches a playlist with the CDN's required headers (including FlixCloud `_v7`
 * XOR-manifest decoding when `manifestKey` is supplied) and returns it rewritten
 * against `/proxy/hls` (or `/api/relay`). Used to hand out a self-contained
 * `.m3u8` to any external player (`mpv`, `VLC`, `IINA`).
 */
export async function relayPlaylist(
  target: string,
  basePath: string,
  options?: {
    referer?: string;
    manifestKey?: string | null;
    proxy?: { ref: string; ctx: string; exp: number; origin: string; audio?: "sub" | "dub" };
  },
): Promise<string> {
  const referer = options?.referer || PLAYER.cdnReferer;
  let originHeader = "https://megaplay.buzz";
  try {
    originHeader = new URL(referer).origin;
  } catch {
    /* keep default */
  }

  const upstream = await fetchRaw(target, {
    referer,
    retries: 1,
    headers: { Accept: "*/*", Origin: originHeader },
  });
  const buf = Buffer.from(await upstream.arrayBuffer());
  if (!upstream.ok || buf.length === 0) {
    throw new HttpError(`CDN did not return a playlist (HTTP ${upstream.status})`, 502, target);
  }

  const { rewritePlaylistForHlsProxy, tryDecodeHlsManifest } = await import("./hls-proxy");
  const decoded = tryDecodeHlsManifest(buf, options?.manifestKey);
  if (!decoded) {
    throw new HttpError("upstream response was not a valid #EXTM3U manifest", 502, target);
  }

  if (options?.proxy) {
    return rewritePlaylistForHlsProxy(decoded, target, {
      ref: options.proxy.ref,
      ctx: options.proxy.ctx,
      exp: options.proxy.exp,
      origin: options.proxy.origin,
      audio: options.proxy.audio,
    });
  }

  return rewritePlaylist(decoded, target, { basePath });
}

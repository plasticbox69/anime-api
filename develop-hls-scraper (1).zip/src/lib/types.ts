export interface AnimeListItem {
  /** Numeric site id used by every AJAX endpoint (from `data-tip`). */
  id: string;
  slug: string;
  title: string;
  japaneseTitle?: string | null;
  poster?: string | null;
  genres: string[];
  type?: string | null;
  score?: number | null;
  subCount?: number | null;
  dubCount?: number | null;
  totalEpisodes?: number | null;
  /** `/watch/{slug}/ep-1` style deep link. */
  url: string;
}

export interface EpisodeItem {
  id: string;
  number: string;
  title?: string | null;
  slug?: string | null;
  hasSub: boolean;
  hasDub: boolean;
  serverIds?: string | null;
  airedAt?: string | null;
  malId?: string | null;
}

export interface ServerItem {
  episodeId: string;
  name: string;
  serverId: string;
  cmid: string;
  linkId: string;
  type: "sub" | "dub" | string;
}

export interface AnimeDetail {
  id: string;
  slug: string;
  title: string;
  japaneseTitle?: string | null;
  altNames?: string | null;
  poster?: string | null;
  synopsis?: string | null;
  genres: string[];
  studios: string[];
  type?: string | null;
  status?: string | null;
  rating?: string | null;
  quality?: string | null;
  score?: number | null;
  duration?: string | null;
  aired?: string | null;
  premiered?: string | null;
  subCount: number;
  dubCount: number;
  totalEpisodes: number;
  url: string;
  /** MyAnimeList id advertised by the site's episode list (`data-mal`). */
  malId?: string | null;
  anilistId?: string | null;
}

export interface SkipRange {
  start?: number | null;
  end?: number | null;
}

export type ScraperProvider =
  | "anikoto"
  | "reanime"
  | "aniwaves"
  | "anipm"
  | "anizone"
  | "xanime"
  | "animegg"
  | "animotvslash"
  | "xmark"
  | "kaa"
  | "atv";

export interface ResolvedSource {
  embedUrl: string;
  embedOrigin: string;
  playerId: string | null;
  hlsUrl: string | null;
  /** Optional base64 32-byte XOR key required to decode FlixCloud `_v7` manifests. */
  manifestKey?: string | null;
  referer: string;
  posterUrl?: string | null;
  tracks: Array<{
    file: string;
    label?: string;
    kind?: string;
    format?: string;
    default?: boolean;
  }>;
  intro?: SkipRange | null;
  outro?: SkipRange | null;
  /** Raw (undecrypted) response from the player's sources endpoint. */
  raw?: Record<string, unknown>;
  decrypted?: Record<string, unknown> | null;
}

export interface PageMeta {
  page: number;
  totalPages: number;
  hasNext: boolean;
}

import { ANILIST } from "./config";
import { fetchRaw } from "./http";

export interface AnilistMedia {
  id: number;
  idMal: number | null;
  title: {
    romaji: string | null;
    english: string | null;
    native: string | null;
    userPreferred: string | null;
  };
  synonyms: string[];
  format: string | null;
  status: string | null;
  episodes: number | null;
  duration: number | null;
  season: string | null;
  seasonYear: number | null;
  startDate: { year: number | null; month: number | null; day: number | null } | null;
  coverImage: { extraLarge: string | null; large: string | null; color: string | null } | null;
  bannerImage: string | null;
  genres: string[];
  averageScore: number | null;
  isAdult: boolean;
  nextAiringEpisode: { episode: number; airingAt: number } | null;
}

export class AnilistError extends Error {
  constructor(
    message: string,
    readonly statusCode = 502,
  ) {
    super(message);
    this.name = "AnilistError";
  }
}

const MEDIA_QUERY = /* GraphQL */ `
  query ($id: Int) {
    Media(id: $id, type: ANIME) {
      id
      idMal
      title { romaji english native userPreferred }
      synonyms
      format
      status
      episodes
      duration
      season
      seasonYear
      startDate { year month day }
      coverImage { extraLarge large color }
      bannerImage
      genres
      averageScore
      isAdult
      nextAiringEpisode { episode airingAt }
    }
  }
`;

interface GraphQLResponse {
  data?: { Media?: AnilistMedia | null } | null;
  errors?: Array<{ message?: string; status?: number }>;
}

/** Fetches one anime from the public AniList GraphQL API. */
export async function fetchAnilistMedia(id: number): Promise<AnilistMedia> {
  const response = await fetchRaw(ANILIST.endpoint, {
    method: "POST",
    retries: 1,
    timeoutMs: ANILIST.timeoutMs,
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
    },
    body: JSON.stringify({ query: MEDIA_QUERY, variables: { id } }),
  });

  let json: GraphQLResponse | null = null;
  try {
    json = (await response.json()) as GraphQLResponse;
  } catch {
    json = null;
  }

  const notFound =
    response.status === 404 || (json?.errors ?? []).some((e) => e.status === 404);
  if (notFound) {
    throw new AnilistError(`AniList has no anime with id ${id}`, 404);
  }
  if (response.status === 429) {
    throw new AnilistError("AniList rate limit reached — try again in a minute", 429);
  }

  const media = json?.data?.Media;
  if (!response.ok || !media) {
    const reason = json?.errors?.[0]?.message ?? `HTTP ${response.status}`;
    throw new AnilistError(`AniList lookup failed: ${reason}`, 502);
  }

  return {
    ...media,
    synonyms: Array.isArray(media.synonyms) ? media.synonyms : [],
    genres: Array.isArray(media.genres) ? media.genres : [],
  };
}

/** The display title AniList users expect to see. */
export function preferredTitle(media: Pick<AnilistMedia, "title" | "id">): string {
  return (
    media.title.english ??
    media.title.userPreferred ??
    media.title.romaji ??
    media.title.native ??
    `AniList #${media.id}`
  );
}

/** Every title the site might list the anime under, most reliable first. */
export function candidateTitles(media: AnilistMedia): string[] {
  const out: string[] = [];
  const push = (value: string | null | undefined) => {
    if (!value) return;
    const v = value.trim();
    if (v && !out.includes(v)) out.push(v);
  };
  push(media.title.english);
  push(media.title.romaji);
  push(media.title.userPreferred);
  // Synonyms are often translations; keep only Latin-script ones.
  for (const s of media.synonyms) {
    if (/^[\x20-\x7E\u00C0-\u024F\u2018-\u201D]+$/.test(s)) push(s);
  }
  return out;
}

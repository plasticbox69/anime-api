import { and, desc, eq, sql, type SQL } from "drizzle-orm";
import { db } from "@/db";
import { animes, episodes, scrapeJobs, sources, type SourceRow } from "@/db/schema";
import { CACHE, SITE } from "./config";
import { buildRelayUrl } from "./relay";
import { fetchJson, fetchText } from "./http";
import {
  parseAnimeDetail,
  parseAnimeItems,
  parseEpisodes,
  parsePagination,
  parseServers,
} from "./parse";
import { resolveEmbedToHls } from "./player";
import type {
  AnimeDetail,
  AnimeListItem,
  EpisodeItem,
  PageMeta,
  ResolvedSource,
  ServerItem,
} from "./types";

export class ScrapeError extends Error {
  constructor(
    message: string,
    readonly statusCode = 502,
    readonly details?: unknown,
  ) {
    super(message);
    this.name = "ScrapeError";
  }
}

interface AjaxEnvelope<T = unknown> {
  status?: number;
  message?: string;
  result?: T;
}

function unwrap<T>(envelope: AjaxEnvelope<T>, what: string): T {
  if (envelope && typeof envelope === "object" && envelope.status === 200 && envelope.result !== undefined) {
    return envelope.result as T;
  }
  const message = envelope?.message ? ` (${envelope.message})` : "";
  throw new ScrapeError(`site refused the ${what} request${message}`, 502, envelope);
}

export function isFresh(date: Date | null | undefined, ttlMs: number): boolean {
  if (!date) return false;
  return Date.now() - new Date(date).getTime() < ttlMs;
}

export function errorMessage(err: unknown): string {
  return err instanceof Error ? err.message : String(err);
}

/**
 * Wraps a scrape operation in an audit row so every request the app makes to
 * the upstream site is visible in the Jobs view.
 */
export async function withJob<T>(
  kind: string,
  target: string,
  run: () => Promise<{ value: T; items?: number }>,
): Promise<T> {
  const started = Date.now();
  try {
    const { value, items = 0 } = await run();
    await db
      .insert(scrapeJobs)
      .values({ kind, target, status: "ok", items, durationMs: Date.now() - started })
      .catch(() => undefined);
    return value;
  } catch (err) {
    await db
      .insert(scrapeJobs)
      .values({
        kind,
        target,
        status: "error",
        items: 0,
        durationMs: Date.now() - started,
        error: errorMessage(err).slice(0, 1000),
      })
      .catch(() => undefined);
    throw err;
  }
}

/* ------------------------------------------------------------------ search */

export interface SearchOutcome {
  query: string;
  items: AnimeListItem[];
  pagination: PageMeta;
  cached: boolean;
}

export async function searchAnimes(query: string, page = 1): Promise<SearchOutcome> {
  const keyword = query.trim();
  const url = `${SITE.baseUrl}/filter?keyword=${encodeURIComponent(keyword)}&page=${page}`;

  return withJob("search", `${keyword} (p${page})`, async () => {
    const html = await fetchText(url, { referer: `${SITE.baseUrl}/` });
    // Only the main result grid — the sidebar repeats the card markup.
    const items = parseAnimeItems(html, SITE.baseUrl, "#list-items");
    const pagination = parsePagination(html, page);
    await persistAnimeCards(items).catch(() => undefined);
    return { value: { query: keyword, items, pagination, cached: false }, items: items.length };
  });
}

/** Home widget: what the site is currently promoting. */
export async function getTrending(): Promise<AnimeListItem[]> {
  const url = `${SITE.baseUrl}/ajax/home/widget/trending`;
  return withJob("trending", "home widget", async () => {
    const body = await fetchJson<AjaxEnvelope<string>>(url, {
      referer: `${SITE.baseUrl}/`,
      xhr: true,
    });
    const items = parseAnimeItems(unwrap(body, "trending widget"));
    await persistAnimeCards(items).catch(() => undefined);
    return { value: items, items: items.length };
  });
}

/* --------------------------------------------------------------- anime page */

async function persistAnimeCards(items: AnimeListItem[]) {
  const rows = items
    .filter((i) => i.id && i.title && /^\d+$/.test(String(i.id)))
    .map((i) => ({
      id: String(i.id),
      slug: i.slug,
      title: i.title,
      japaneseTitle: i.japaneseTitle ?? null,
      poster: i.poster ?? null,
      genres: i.genres,
      type: i.type ?? null,
      score: i.score ?? null,
      subCount: i.subCount ?? 0,
      dubCount: i.dubCount ?? 0,
      totalEpisodes: i.totalEpisodes ?? 0,
    }));
  if (!rows.length) return;

  await db
    .insert(animes)
    .values(rows)
    .onConflictDoUpdate({
      target: animes.id,
      set: {
        slug: sql`excluded.slug`,
        title: sql`excluded.title`,
        poster: sql`coalesce(excluded.poster, ${animes.poster})`,
        japaneseTitle: sql`coalesce(excluded.japanese_title, ${animes.japaneseTitle})`,
        type: sql`coalesce(excluded.type, ${animes.type})`,
        score: sql`coalesce(excluded.score, ${animes.score})`,
        subCount: sql`greatest(excluded.sub_count, ${animes.subCount})`,
        dubCount: sql`greatest(excluded.dub_count, ${animes.dubCount})`,
        updatedAt: sql`now()`,
      },
    });
}

export interface AnimeOutcome {
  detail: AnimeDetail;
  episodes: EpisodeItem[];
  cached: boolean;
}

/** Scrapes `/watch/{slug}` plus its episode list and caches both. */
export async function getAnime(
  slug: string,
  force = false,
  opts: { requireMal?: boolean } = {},
): Promise<AnimeOutcome> {
  const cleanSlug = slug.replace(/^\/+|\/+$/g, "");

  const existing = await db.select().from(animes).where(eq(animes.slug, cleanSlug)).limit(1);
  const cachedRow = existing[0];
  const cachedEps = cachedRow ? await getStoredEpisodes(cachedRow.id) : [];

  const usable =
    !force &&
    cachedRow &&
    isFresh(cachedRow.scrapedAt, CACHE.animeTtlMs) &&
    cachedEps.length > 0 &&
    // Rows indexed before MAL ids were captured must be refreshed for mapping.
    (!opts.requireMal || cachedRow.malId !== null);

  if (usable && cachedRow) {
    return { detail: rowToDetail(cachedRow), episodes: cachedEps.map(rowToEpisode), cached: true };
  }

  return withJob("anime", cleanSlug, async () => {
    const watchUrl = `${SITE.baseUrl}/watch/${cleanSlug}`;
    const html = await fetchText(watchUrl, { referer: `${SITE.baseUrl}/` });
    const detail = parseAnimeDetail(html, cleanSlug);

    const listUrl = `${SITE.baseUrl}/ajax/episode/list/${detail.id}`;
    const body = await fetchJson<AjaxEnvelope<string>>(listUrl, { referer: watchUrl, xhr: true });
    const episodeItems = parseEpisodes(unwrap(body, "episode list"));

    detail.malId = episodeItems.find((e) => e.malId && e.malId !== "0")?.malId ?? null;
    const totalEpisodes = detail.totalEpisodes || episodeItems.length;
    const subCount = detail.subCount || episodeItems.filter((e) => e.hasSub).length;
    const dubCount = detail.dubCount || episodeItems.filter((e) => e.hasDub).length;

    const values = {
      slug: detail.slug,
      title: detail.title,
      japaneseTitle: detail.japaneseTitle ?? null,
      altNames: detail.altNames ?? null,
      poster: detail.poster ?? null,
      synopsis: detail.synopsis ?? null,
      genres: detail.genres,
      studios: detail.studios,
      type: detail.type ?? null,
      status: detail.status ?? null,
      rating: detail.rating ?? null,
      quality: detail.quality ?? null,
      score: detail.score ?? null,
      duration: detail.duration ?? null,
      aired: detail.aired ?? null,
      premiered: detail.premiered ?? null,
      subCount,
      dubCount,
      totalEpisodes,
      malId: detail.malId,
      scrapedAt: new Date(),
      updatedAt: new Date(),
    };

    await db
      .insert(animes)
      .values({ id: detail.id, ...values })
      .onConflictDoUpdate({ target: animes.id, set: values });

    // Upsert in chunks: long runners (One Piece) have 1,000+ episodes and
    // concurrent requests must not trip over each other's primary keys.
    for (let i = 0; i < episodeItems.length; i += 400) {
      const chunk = episodeItems.slice(i, i + 400).map((ep) => ({
        id: ep.id,
        animeId: detail.id,
        number: ep.number,
        title: ep.title ?? null,
        slug: ep.slug ?? null,
        hasSub: ep.hasSub,
        hasDub: ep.hasDub,
        serverIds: ep.serverIds ?? null,
        airedAt: ep.airedAt ?? null,
      }));
      await db
        .insert(episodes)
        .values(chunk)
        .onConflictDoUpdate({
          target: episodes.id,
          set: {
            animeId: sql`excluded.anime_id`,
            number: sql`excluded.number`,
            title: sql`excluded.title`,
            slug: sql`excluded.slug`,
            hasSub: sql`excluded.has_sub`,
            hasDub: sql`excluded.has_dub`,
            serverIds: sql`excluded.server_ids`,
            airedAt: sql`excluded.aired_at`,
          },
        });
    }

    return {
      value: {
        detail: { ...detail, subCount, dubCount, totalEpisodes },
        episodes: episodeItems,
        cached: false,
      },
      items: episodeItems.length,
    };
  });
}

/* ----------------------------------------------------------------- servers */

async function animeSlugFor(animeId: string): Promise<string> {
  const rows = await db.select({ slug: animes.slug }).from(animes).where(eq(animes.id, animeId)).limit(1);
  return rows[0]?.slug ?? animeId;
}

async function loadEpisode(episodeId: string) {
  const rows = await db.select().from(episodes).where(eq(episodes.id, episodeId)).limit(1);
  const episode = rows[0];
  if (!episode) {
    throw new ScrapeError("episode is not in the local library yet — scrape the anime first", 404);
  }
  return episode;
}

export async function getServers(episodeId: string): Promise<ServerItem[]> {
  const episode = await loadEpisode(episodeId);
  const serverIds = episode.serverIds;
  if (!serverIds) throw new ScrapeError("episode has no server payload", 422);

  return withJob("servers", `episode ${episodeId}`, async () => {
    const url = `${SITE.baseUrl}/ajax/server/list?servers=${encodeURIComponent(serverIds)}`;
    const referer = `${SITE.baseUrl}/watch/${await animeSlugFor(episode.animeId)}/ep-${episode.number}`;
    const body = await fetchJson<AjaxEnvelope<string>>(url, { referer, xhr: true });
    const servers = parseServers(unwrap(body, "server list"));
    return { value: servers, items: servers.length };
  });
}

/* ------------------------------------------------------------------ source */

export interface SourceAttempt {
  server: string;
  type: string;
  ok: boolean;
  error?: string;
}

export interface SourceOutcome {
  episodeId: string;
  animeId: string | null;
  server: ServerItem;
  resolved: ResolvedSource;
  proxiedUrl: string;
  cached: boolean;
  /** Audio track the caller asked for (null = no preference). */
  requestedType: string | null;
  /** True when the requested audio track did not exist and another was served. */
  typeFallback: boolean;
  attempts: SourceAttempt[];
}

type EpisodeRecord = typeof episodes.$inferSelect;

function rowToOutcome(row: SourceRow, requestedType: string | null): SourceOutcome {
  const hls = row.hlsUrl ?? "";
  const type = row.audioType ?? "sub";
  return {
    episodeId: row.episodeId,
    animeId: row.animeId,
    server: {
      episodeId: row.episodeId,
      name: row.serverName ?? "cached",
      serverId: row.serverId ?? "",
      cmid: row.cmid ?? "",
      linkId: row.linkId ?? "",
      type,
    },
    resolved: {
      embedUrl: row.embedUrl ?? "",
      embedOrigin: row.embedUrl ? new URL(row.embedUrl).origin : "",
      playerId: null,
      hlsUrl: hls || null,
      referer: row.referer ?? "",
      posterUrl: row.posterUrl ?? null,
      tracks: (row.tracks ?? []) as ResolvedSource["tracks"],
      intro:
        row.introStart != null && row.introEnd != null ? { start: row.introStart, end: row.introEnd } : null,
      outro:
        row.outroStart != null && row.outroEnd != null ? { start: row.outroStart, end: row.outroEnd } : null,
    },
    proxiedUrl: buildRelayUrl(hls),
    cached: true,
    requestedType,
    typeFallback: requestedType ? type !== requestedType : false,
    attempts: [],
  };
}

/** Latest fresh, successful playlist cached for an episode key. */
export async function findCachedSource(
  episodeKey: string,
  filters: { type?: string | null; serverId?: string | null; provider?: string | null } = {},
): Promise<SourceRow | null> {
  const conditions: SQL[] = [
    eq(sources.episodeId, episodeKey),
    eq(sources.status, "ok"),
    eq(sources.provider, filters.provider ?? "anikoto"),
  ];
  if (filters.type) conditions.push(eq(sources.audioType, filters.type));
  if (filters.serverId) conditions.push(eq(sources.serverId, filters.serverId));
  const rows = await db
    .select()
    .from(sources)
    .where(and(...conditions))
    .orderBy(desc(sources.resolvedAt))
    .limit(1);
  const row = rows[0];
  return row?.hlsUrl && isFresh(row.resolvedAt, CACHE.sourceTtlMs) ? row : null;
}

/** link-id -> ajax/server?get= -> embed -> sources -> AES -> m3u8, for one server. */
async function resolveWithServer(
  episode: EpisodeRecord,
  server: ServerItem,
  meta: { anilistId?: number | string | null },
): Promise<Omit<SourceOutcome, "requestedType" | "typeFallback" | "attempts">> {
  return withJob("source", `episode ${episode.id} / ${server.type} / ${server.name}`, async () => {
    const slug = await animeSlugFor(episode.animeId);
    const referer = `${SITE.baseUrl}/watch/${slug}/ep-${episode.number}`;
    const base = {
      episodeId: episode.id,
      animeId: episode.animeId,
      anilistId: meta.anilistId != null ? String(meta.anilistId) : null,
      episodeNumber: episode.number,
      audioType: server.type,
      strategy: "site",
      serverName: server.name,
      serverId: server.serverId,
      cmid: server.cmid,
      linkId: server.linkId,
    };

    const linkUrl = `${SITE.baseUrl}/ajax/server?get=${encodeURIComponent(server.linkId)}`;
    const linkBody = await fetchJson<AjaxEnvelope<{ url?: string; skip_data?: unknown }>>(linkUrl, {
      referer,
      xhr: true,
    });
    const link = unwrap(linkBody, "server link");
    if (!link?.url) throw new ScrapeError("server link response had no url", 502);

    let resolved: ResolvedSource;
    try {
      resolved = await resolveEmbedToHls(link.url);
    } catch (err) {
      await db
        .insert(sources)
        .values({ ...base, embedUrl: link.url, status: "error", error: errorMessage(err).slice(0, 1000) })
        .catch(() => undefined);
      throw new ScrapeError(errorMessage(err), 502);
    }

    // Prefer the player's skip markers, fall back to the site's community ones.
    const siteSkip = link.skip_data as { intro?: number[]; outro?: number[] } | undefined;
    const intro =
      resolved.intro ?? (siteSkip?.intro ? { start: siteSkip.intro[0], end: siteSkip.intro[1] } : null);
    const outro =
      resolved.outro ?? (siteSkip?.outro ? { start: siteSkip.outro[0], end: siteSkip.outro[1] } : null);

    await db.insert(sources).values({
      ...base,
      embedUrl: link.url,
      hlsUrl: resolved.hlsUrl,
      posterUrl: resolved.posterUrl ?? null,
      referer: resolved.referer,
      introStart: intro?.start ?? null,
      introEnd: intro?.end ?? null,
      outroStart: outro?.start ?? null,
      outroEnd: outro?.end ?? null,
      tracks: resolved.tracks,
      status: "ok",
    });

    return {
      value: {
        episodeId: episode.id,
        animeId: episode.animeId,
        server,
        resolved: { ...resolved, intro, outro },
        proxiedUrl: resolved.hlsUrl ? buildRelayUrl(resolved.hlsUrl) : "",
        cached: false,
      },
      items: 1,
    };
  });
}

/**
 * Resolves a playable playlist for a site episode.
 *
 * - `type` picks the audio track (sub/dub); if the episode has no such track
 *   another one is served and `typeFallback` is set.
 * - Without an explicit `serverId`, servers of the requested type are tried in
 *   order until one yields a playlist.
 */
export async function resolveSource(
  episodeId: string,
  preferred: { serverId?: string; type?: string; index?: number } = {},
  force = false,
  meta: { anilistId?: number | string | null } = {},
): Promise<SourceOutcome> {
  const episode = await loadEpisode(episodeId);
  const wantType = preferred.type === "sub" || preferred.type === "dub" ? preferred.type : null;

  if (!force) {
    const cached = await findCachedSource(episodeId, {
      type: wantType,
      serverId: preferred.serverId ?? null,
    });
    if (cached) return rowToOutcome(cached, wantType);
  }

  const servers = await getServers(episodeId);
  if (!servers.length) throw new ScrapeError("no streaming servers were advertised", 502);

  const ordered: ServerItem[] = [];
  const add = (s: ServerItem | undefined) => {
    if (s && !ordered.includes(s)) ordered.push(s);
  };

  let typeFallback = false;
  if (preferred.serverId) {
    add(
      servers.find((s) => s.serverId === preferred.serverId && (!wantType || s.type === wantType)) ??
        servers.find((s) => s.serverId === preferred.serverId),
    );
    if (!ordered.length) throw new ScrapeError(`server ${preferred.serverId} is not available`, 404);
  } else {
    if (typeof preferred.index === "number") add(servers[preferred.index]);
    const sameType = wantType ? servers.filter((s) => s.type === wantType) : servers;
    sameType.forEach(add);
    if (wantType && sameType.length === 0) {
      typeFallback = true;
      servers.forEach(add);
    }
  }

  const attempts: SourceAttempt[] = [];
  for (const server of ordered.slice(0, 4)) {
    try {
      const outcome = await resolveWithServer(episode, server, meta);
      attempts.push({ server: server.name, type: server.type, ok: true });
      return {
        ...outcome,
        requestedType: wantType,
        typeFallback: typeFallback || (wantType ? server.type !== wantType : false),
        attempts,
      };
    } catch (err) {
      attempts.push({ server: server.name, type: server.type, ok: false, error: errorMessage(err) });
    }
  }

  throw new ScrapeError(
    `every server failed — ${attempts.map((a) => `${a.type}/${a.server}: ${a.error}`).join("; ")}`,
    502,
    attempts,
  );
}

/* ------------------------------------------------------------------- reads */

export function rowToDetail(row: typeof animes.$inferSelect): AnimeDetail {
  return {
    id: row.id,
    slug: row.slug,
    title: row.title,
    japaneseTitle: row.japaneseTitle,
    altNames: row.altNames,
    poster: row.poster,
    synopsis: row.synopsis,
    genres: row.genres ?? [],
    studios: row.studios ?? [],
    type: row.type,
    status: row.status,
    rating: row.rating,
    quality: row.quality,
    score: row.score,
    duration: row.duration,
    aired: row.aired,
    premiered: row.premiered,
    subCount: row.subCount,
    dubCount: row.dubCount,
    totalEpisodes: row.totalEpisodes,
    url: `${SITE.baseUrl}/watch/${row.slug}`,
    malId: row.malId,
    anilistId: row.anilistId,
  };
}

export function rowToEpisode(row: typeof episodes.$inferSelect): EpisodeItem {
  return {
    id: row.id,
    number: row.number,
    title: row.title,
    slug: row.slug,
    hasSub: row.hasSub,
    hasDub: row.hasDub,
    serverIds: row.serverIds,
    airedAt: row.airedAt,
  };
}

export async function getLibrary(limit = 60) {
  return db.select().from(animes).orderBy(desc(animes.updatedAt)).limit(limit);
}

export async function getStoredEpisodes(animeId: string) {
  const rows = await db.select().from(episodes).where(eq(episodes.animeId, animeId));
  return rows.sort((a, b) => {
    const na = Number(a.number);
    const nb = Number(b.number);
    if (Number.isFinite(na) && Number.isFinite(nb)) return na - nb;
    return a.number.localeCompare(b.number, undefined, { numeric: true });
  });
}

export async function getStoredSources(episodeId: string) {
  return db
    .select()
    .from(sources)
    .where(eq(sources.episodeId, episodeId))
    .orderBy(desc(sources.resolvedAt));
}

export async function getJobs(limit = 60) {
  return db.select().from(scrapeJobs).orderBy(desc(scrapeJobs.id)).limit(limit);
}

export async function getStats() {
  const [row] = await db
    .select({
      animes: sql<number>`(select count(*)::int from animes)`,
      episodes: sql<number>`(select count(*)::int from episodes)`,
      sources: sql<number>`(select count(*)::int from sources)`,
      resolvedSources: sql<number>`(select count(*)::int from sources where status = 'ok')`,
      jobs: sql<number>`(select count(*)::int from scrape_jobs)`,
      avgJobMs: sql<number>`(select coalesce(round(avg(duration_ms))::int, 0) from scrape_jobs)`,
      mappings: sql<number>`(select count(*)::int from anilist_mappings where method <> 'unmatched')`,
    })
    .from(sql`(select 1) as one`);

  return {
    animes: row?.animes ?? 0,
    episodes: row?.episodes ?? 0,
    sources: row?.sources ?? 0,
    resolvedSources: row?.resolvedSources ?? 0,
    jobs: row?.jobs ?? 0,
    avgJobMs: row?.avgJobMs ?? 0,
    mappings: row?.mappings ?? 0,
  };
}

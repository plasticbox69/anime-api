
import { chromium } from 'playwright';
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';

async function probe() {
  const browser = await chromium.launch({ args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const context = await browser.newContext({ userAgent: UA });
  const page = await context.newPage();
  
  const api = [];
  const media = [];
  page.on('response', async (res) => {
    const u = res.url();
    const ct = (res.headers()['content-type'] || '').toLowerCase();
    if (/json/i.test(ct) && (u.includes('animetvplus') || u.includes('vidflow') || u.includes('vidara'))) {
      let b = ''; try { b = (await res.text()).slice(0, 400); } catch {}
      api.push({ status: res.status(), url: u, body: b });
    }
    if (ct.includes('mpegurl') || /\.m3u8/i.test(u) || u.includes('watch.m3u8') || u.includes('manifest')) {
      let b = ''; try { b = (await res.text()).slice(0, 150); } catch {}
      media.push({ status: res.status(), url: u, ct, body: b });
    }
  });
  
  await page.goto('https://animetvplus.xyz/watch/attack-on-titan-16498/episode-1', { waitUntil: 'networkidle', timeout: 45000 });
  await page.waitForTimeout(10000);
  
  // click play button if present
  try {
    const btn = await page.$('button[aria-label*=play i], button:has-text("Play"), .play-button, video');
    if (btn) { await btn.click(); await page.waitForTimeout(5000); }
  } catch {}
  
  console.log('URL:', page.url());
  console.log('\n=== ALL API (animetvplus/vidflow) ===');
  for (const a of api.slice(0, 20)) {
    console.log(`${a.status} ${a.url.slice(0, 150)}`);
    console.log(`   ${a.body.slice(0, 300)}`);
  }
  console.log('\n=== MEDIA ===');
  for (const m of media.slice(0, 8)) {
    console.log(`${m.status} ct=${m.ct} ${m.url.slice(0, 140)}`);
    console.log(`   ${m.body.slice(0, 100)}`);
  }
  const vids = await page.evaluate(() => [...document.querySelectorAll('video')].map(v => v.src || v.currentSrc).filter(Boolean));
  const iframes = await page.evaluate(() => [...document.querySelectorAll('iframe')].map(f => f.src).filter(Boolean));
  console.log('\nvideos:', vids.slice(0, 3));
  console.log('iframes:', iframes.slice(0, 3));
  
  await browser.close();
}
await probe();

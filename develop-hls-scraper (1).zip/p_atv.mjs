
import { chromium } from 'playwright';
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';

async function probe() {
  const browser = await chromium.launch({ args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const context = await browser.newContext({ userAgent: UA });
  const page = await context.newPage();
  
  const api = [];
  const media = [];
  page.on('response', async (res) => {
    const u = res.url();
    const ct = (res.headers()['content-type'] || '').toLowerCase();
    if (/json/i.test(ct) && (u.includes('animetvplus') || u.includes('catalog'))) {
      let b = ''; try { b = (await res.text()).slice(0, 300); } catch {}
      api.push({ status: res.status(), url: u, body: b });
    }
    if (ct.includes('mpegurl') || /\.m3u8/i.test(u)) {
      let b = ''; try { b = (await res.text()).slice(0, 150); } catch {}
      media.push({ status: res.status(), url: u, body: b });
    }
  });
  
  console.log('=== anime page: attack-on-titan-16498 ===');
  await page.goto('https://animetvplus.xyz/anime/attack-on-titan-16498', { waitUntil: 'networkidle', timeout: 40000 });
  await page.waitForTimeout(5000);
  
  const watchLinks = await page.evaluate(() => [...new Set([...document.querySelectorAll('a[href]')].map(a=>a.getAttribute('href')).filter(h=>h&&/watch|play|episode/i.test(h)))].slice(0,10));
  console.log('watch links:', watchLinks);
  
  console.log('\n=== API calls on anime page ===');
  for (const a of api.slice(0, 10)) {
    console.log(`${a.status} ${a.url.slice(0, 130)}`);
    console.log(`   ${a.body.slice(0, 200)}`);
  }
  
  // Try clicking a play/watch button
  if (watchLinks.length) {
    console.log('\n=== clicking watch link:', watchLinks[0], '===');
    api.length = 0; media.length = 0;
    const abs = watchLinks[0].startsWith('http') ? watchLinks[0] : 'https://animetvplus.xyz' + watchLinks[0];
    await page.goto(abs, { waitUntil: 'networkidle', timeout: 40000 });
    await page.waitForTimeout(8000);
    
    console.log('URL now:', page.url());
    console.log('\n=== API calls on watch page ===');
    for (const a of api.slice(0, 12)) {
      console.log(`${a.status} ${a.url.slice(0, 140)}`);
      console.log(`   ${a.body.slice(0, 250)}`);
    }
    console.log('\n=== MEDIA ===');
    for (const m of media.slice(0, 6)) {
      console.log(`${m.status} ${m.url.slice(0, 130)}`);
      console.log(`   ${m.body.slice(0, 100)}`);
    }
    const vids = await page.evaluate(() => [...document.querySelectorAll('video')].map(v => v.src || v.currentSrc).filter(Boolean));
    const iframes = await page.evaluate(() => [...document.querySelectorAll('iframe')].map(f => f.src).filter(Boolean));
    console.log('videos:', vids.slice(0,3), 'iframes:', iframes.slice(0,3));
  }
  
  await browser.close();
}
await probe();

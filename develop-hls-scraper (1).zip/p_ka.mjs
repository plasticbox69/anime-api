
import { chromium } from 'playwright';

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';

async function probe() {
  const browser = await chromium.launch({ args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const context = await browser.newContext({ userAgent: UA });
  const page = await context.newPage();
  
  const apiCalls = [];
  page.on('response', async (res) => {
    const u = res.url();
    const ct = (res.headers()['content-type'] || '');
    if (/json/i.test(ct) && !u.includes('_nuxt') && !u.includes('googletagmanager')) {
      let body = '';
      try { body = (await res.text()).slice(0, 400); } catch {}
      apiCalls.push({ url: u, status: res.status(), body });
    }
  });
  
  console.log('=== kaa.lt anime page ===');
  await page.goto('https://kaa.lt/tensei-kizoku-kantei-skill-de-nariagaru-3rd-season-8f8b', { waitUntil: 'networkidle', timeout: 35000 });
  await page.waitForTimeout(6000);
  
  const eps = await page.evaluate(() => {
    const links = [];
    document.querySelectorAll('a[href]').forEach(a => {
      const h = a.getAttribute('href');
      if (h && h.includes('ep-')) links.push(h);
    });
    return [...new Set(links)];
  });
  console.log('Episode links rendered:', eps.slice(0, 10));
  
  console.log('\n=== API calls ===');
  for (const a of apiCalls.slice(0, 10)) {
    console.log(`${a.status} ${a.url.slice(0, 130)}`);
    console.log(`   ${a.body.slice(0, 250)}`);
  }
  
  await browser.close();
}

await probe();

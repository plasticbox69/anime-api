
import { chromium } from 'playwright';
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';

async function probe() {
  const browser = await chromium.launch({ args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const context = await browser.newContext({ userAgent: UA });
  const page = await context.newPage();
  
  const media = [];
  page.on('request', (req) => {
    const u = req.url();
    const hdrs = req.headers();
    if (/m3u8|urlset|manifest/i.test(u)) {
      media.push({ url: u, referer: hdrs['referer'], origin: hdrs['origin'] });
    }
  });
  page.on('response', async (res) => {
    const u = res.url();
    if (/m3u8|urlset/i.test(u)) {
      let b=''; try{ b=(await res.text()).slice(0,120);}catch{}
      console.log('RESP', res.status(), u.slice(0,130));
      console.log('   ', b);
    }
  });
  
  await page.goto('https://uqload.vc/embed-84rnqblpk5bz.html', { waitUntil: 'networkidle', timeout: 40000 });
  await page.waitForTimeout(8000);
  
  console.log('=== media requests from embed ===');
  for (const m of media.slice(0, 8)) {
    console.log('REQ:', m.url.slice(0, 130));
    console.log('     referer:', m.referer, '| origin:', m.origin);
  }
  
  const vids = await page.evaluate(() => [...document.querySelectorAll('video')].map(v => v.src || v.currentSrc).filter(Boolean));
  console.log('\nvideos:', vids.slice(0, 3));
  
  await browser.close();
}
await probe();

import { chromium } from 'playwright';

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';

async function probeKa() {
  const browser = await chromium.launch({ args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const context = await browser.newContext({ userAgent: UA });
  const page = await ctx.newPage();
  
  // First, let's see what the search results look like for kaa.lt
  console.log('=== ka.lt - Search page ===');
  await page.goto('https://kaa.lt/search?keyword=frieren', { waitUntil: 'domcontentloaded', timeout: 30000 });
  await page.waitForTimeout(5000);
  
  const searchLinks = await page.evaluate(() => {
    const links = [];
    document.querySelectorAll('a[href]').forEach(a => {
      const h = a.getAttribute('href');
      if (h && h.includes('/anime/')) {
        links.push(h);
      }
    });
    return [...new Set(links)];
  });
  console.log('Search result links:', links.slice(0, 10));
  
  if (links.length > 0) {
    const firstLink = links[0];
    console.log(`\n=== ka.lt - Anime page: ${firstLink} ---`);
    await page.goto(`https://kaa.lt${firstLink}`, { waitUntil: 'domcontentloaded', timeout: 30000 });
    await page.waitForTimeout(5000);
    
    const epLinks = await page.evaluate(() => {
      const links = [];
      document.querySelectorAll('a[href]').forEach(a => {
        const h = a.getAttribute('href');
        if (h && (h.includes('/episode') || h.includes('/watch/'))) {
          links.push(h);
        }
      });
      return [...new Set(links)];
    });
    console.log('Episode links:', epLinks.slice(0, 10));
    
    // Check for data attributes on episode links
    const epData = await page.evaluate(() => {
      const results = [];
      document.querySelectorAll('a[href*="episode"]').forEach(a => {
        const obj = {};
        for (const attr of a.attributes) {
          if (attr.name.startsWith('data-')) {
            obj[attr.name] = attr.value;
          }
        }
        results.push({ href: a.getAttribute('href'), attrs: obj });
      });
      return results;
    });
    console.log('Episode link data attributes:', JSON.stringify(epData.slice(0, 3), null, 2));
  }
  
  await browser.close();
}

await probeKa();


import { chromium } from 'playwright';
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';

async function probe() {
  const browser = await chromium.launch({ args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const context = await browser.newContext({ userAgent: UA });
  
  // Set up route interception to rewrite uqload CDN requests through our own proxy
  const captured = [];
  await context.route('**/*', async (route) => {
    const u = route.request().url();
    if (u.includes('strm9.uqload.vc') || u.includes('.uqload.vc')) {
      captured.push(u);
      // Rewrite to go through with the embed page as referer
      await route.continue({
        headers: { ...route.request().headers(), referer: 'https://uqload.vc/embed-84rnqblpk5bz.html' }
      });
    } else {
      await route.continue();
    }
  });
  
  const page = await context.newPage();
  page.on('response', async (res) => {
    const u = res.url();
    if (/m3u8|urlset/i.test(u) && res.status() === 200) {
      let b=''; try{ b=(await res.text()).slice(0,100);}catch{}
      console.log('MEDIA 200:', u.slice(0, 140));
      console.log('   ', b);
    }
  });
  
  await page.goto('https://uqload.vc/embed-84rnqblpk5bz.html', { waitUntil: 'networkidle', timeout: 40000 });
  await page.waitForTimeout(6000);
  
  console.log('\n=== captured uqload URLs ===');
  for (const u of captured.slice(0, 5)) console.log('  ', u.slice(0, 150));
  
  await browser.close();
}
await probe();

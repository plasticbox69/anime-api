
import { chromium } from 'playwright';
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';

async function probe() {
  const browser = await chromium.launch({ args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const context = await browser.newContext({ userAgent: UA });
  const page = await context.newPage();
  const reqs = [];
  page.on('request', r => {
    const u = r.url();
    if (u.includes('do_search') || u.includes('search')) {
      reqs.push({ method: r.method(), url: u, post: r.postData ? String(r.postData).slice(0, 200) : null });
    }
  });
  page.on('response', async (res) => {
    const u = res.url();
    if (u.includes('do_search')) {
      let b = ''; try { b = (await res.text()).slice(0, 400); } catch {}
      console.log('RESP', res.status(), u.slice(0, 120));
      console.log('  ', b.slice(0, 350));
    }
  });
  
  await page.goto('https://kaa.lt/', { waitUntil: 'networkidle', timeout: 35000 });
  await page.waitForTimeout(3000);
  
  // find search input
  const input = await page.$('input[type=search], input[name=q], input[placeholder*=earch i], #main-search-container input');
  console.log('search input found:', !!input);
  if (input) {
    await input.fill('frieren');
    await page.waitForTimeout(500);
    await input.press('Enter');
    await page.waitForTimeout(6000);
  }
  
  console.log('\n=== search requests ===');
  for (const r of reqs.slice(0, 8)) {
    console.log(r.method, r.url.slice(0, 140));
    if (r.post) console.log('   POST:', r.post);
  }
  console.log('\nURL now:', page.url());
  const links = await page.evaluate(() => [...new Set([...document.querySelectorAll('a[href]')].map(a=>a.getAttribute('href')).filter(h=>h&&/ep-|frieren/i.test(h)))].slice(0,8));
  console.log('links:', links);
  
  await browser.close();
}
await probe();

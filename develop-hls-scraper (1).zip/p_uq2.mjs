
import { chromium } from 'playwright';
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';

async function probe() {
  const browser = await chromium.launch({ args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const context = await browser.newContext({ userAgent: UA });
  const page = await context.newPage();
  
  let masterUrl = null;
  let token = null;
  page.on('response', async (res) => {
    const u = res.url();
    if (u.includes('urlset/master.m3u8')) {
      masterUrl = u;
      const m = u.match(/[?&]t=([^&]+)/);
      token = m ? m[1] : null;
    }
  });
  
  await page.goto('https://uqload.vc/embed-84rnqblpk5bz.html', { waitUntil: 'networkidle', timeout: 40000 });
  await page.waitForTimeout(6000);
  
  console.log('master URL captured:', masterUrl ? masterUrl.slice(0, 130) : 'NONE');
  console.log('token:', token);
  
  if (masterUrl) {
    // Now replay that exact URL with page.evaluate fetch from the uqload origin
    const r = await page.evaluate(async (u) => {
      const resp = await fetch(u, { credentials: 'include' });
      return { status: resp.status, ct: resp.headers.get('content-type'), body: (await resp.text()).slice(0, 200) };
    }, masterUrl);
    console.log('\nfetch from page origin:');
    console.log('  status:', r.status, 'ct:', r.ct);
    console.log('  body:', r.body);
    
    // cookies
    const cookies = await context.cookies('https://uqload.vc');
    console.log('\nuqload cookies:', cookies.map(c => `${c.name}=${c.value.slice(0,30)}`));
  }
  
  await browser.close();
}
await probe();

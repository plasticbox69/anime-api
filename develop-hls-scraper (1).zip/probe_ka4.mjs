
import { chromium } from 'playwright';

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';

async function probe() {
  const browser = await chromium.launch({ args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const context = await browser.newContext({ userAgent: UA });
  const page = await context.newPage();
  
  console.log('=== ka.lt - Anime page ===');
  await page.goto('https://kaa.lt/anime/f91d5sxb/1', { waitUntil: 'networkidle', timeout: 30000 });
  await page.waitForTimeout(5000);
  
  const html = await page.content();
  console.log('Page length:', html.length);
  
  // Check for any episode-related content
  const hasEpisode = html.includes('Episode');
  console.log('Has "Episode":', hasEpisode);
  
  // Look for any links with episode in them
  const links = await page.evaluate(() => {
    const links = [];
    document.querySelectorAll('a[href]').forEach(a => {
      const h = a.getAttribute('href');
      if (h && h.includes('episode')) {
        links.push(h);
      }
    });
    return [...new Set(links)];
  });
  console.log('Episode links:', links.slice(0, 10));
  
  await browser.close();
}

await probe();

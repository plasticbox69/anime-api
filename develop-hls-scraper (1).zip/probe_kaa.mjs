import { chromium } from 'playwright';

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';

async function probeKa() {
  const browser = await chromium.launch({ args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const context = await browser.newContext({ userAgent: UA });
  const page = await context.newPage();
  
  console.log('=== ka.lt - Anime page ===');
  await page.goto('https://kaa.lt/anime/f91d5sxb/1', { waitUntil: 'networkidle', timeout: 30000 });
  await page.waitForTimeout(5000);
  
  // Get all links
  const links = await page.evaluate(() => {
    const links = [];
    document.querySelectorAll('a[href]').forEach(a => {
      const h = a.getAttribute('href');
      if (h && (h.includes('/episode') || h.includes('/watch/') || h.includes('/watch/'))) {
        links.push(h);
      }
    });
    return [...new Set(links)];
  });
  console.log('Episode/watch links:', links);
  
  // Look for iframe/player
  const iframes = await page.evaluate(() => {
    const iframes = [];
    document.querySelectorAll('iframe, video, source').forEach(el => {
      if (el.src) iframes.push(el.src);
      if (el.src) iframes.push(el.src);
    });
    return iframes;
  });
  console.log('Iframes/videos:', iframes);
  
  // Look for any data attributes on video/player elements
  const dataAttrs = await page.evaluate(() => {
    const results = [];
    document.querySelectorAll('[data-id], [data-link-id], [data-server-id], [data-ep-id]').forEach(el => {
      const obj = {};
      for (const attr of el.attributes) {
        if (attr.name.startsWith('data-')) {
          obj[attr.name] = attr.value;
        }
      }
      results.push({ tag: el.tagName, attrs: obj });
    });
    return results;
  });
  console.log('Data attributes:', JSON.stringify(dataAttrs, null, 2));
  
  // Check for any network requests to video sources
  const requests = [];
  page.on('request', r => {
    const u = r.url();
    if (u.includes('stream') || u.includes('video') || u.includes('stream') || u.includes('play')) {
      requests.push(u);
    }
  });
  
  console.log('Network requests (video/stream):', requests.slice(0, 20));
  
  await browser.close();
}

await probeKa();
